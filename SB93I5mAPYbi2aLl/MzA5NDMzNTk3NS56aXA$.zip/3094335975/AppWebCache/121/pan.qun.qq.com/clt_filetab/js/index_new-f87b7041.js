(function(e) {
    var t = {};
    function a(i) {
        if (t[i]) return t[i].exports;
        var n = t[i] = {
            exports: {},
            id: i,
            loaded: false
        };
        e[i].call(n.exports, n, n.exports, a);
        n.loaded = true;
        return n.exports;
    }
    a.m = e;
    a.c = t;
    a.p = "//s1.url.cn/qqun/pan/clt_filetab/js/";
    return a(0);
})([ function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    savePoint("start");
    window.G = {};
    G.flagThumb = true;
    G.flagUploadTemp = false;
    G.flagHeightChrome = /chrome\/([2|3]\d)/gi.test(window.navigator.userAgent);
    G.canOpenFolder = window.external && window.external.openFolder;
    G.ifFileExist = window.external && window.external.isFileExist;
    G.flagIsVip = false;
    G.handler = {};
    G.cMap = {};
    G.pList = [];
    G.cList = [];
    G.compList = [];
    G.selectRow = {};
    G.previewCache = {};
    G.activeElement;
    G.oldVersion = false;
    G.folderVersion = 5461;
    G.nowFolder = "/";
    G.folderNum = 0;
    G.appid = 4;
    G.canCreateFolder = true;
    G.mac = false;
    G.tab = {};
    var n = a(15);
    var r = a(16);
    var o = a(17);
    var l = n.getParameter("debug");
    var s = decodeURIComponent(n.getParameter("webParams"));
    var d = window.external && window.external.CallHummerApi && window.external.CallHummerApi("IM.GetVersion");
    if (d) {
        try {
            d = JSON.parse(d);
            if (d.errorCode === 0) {
                d = d.version;
            }
        } catch (f) {
            d = false;
        }
    }
    G.version = d;
    G.webParams = s;
    G.downFast = window.external && window.external.downloadByXF;
    G.fileMap = function() {
        var e = [];
        return function() {
            e[G.module()] = e[G.module()] || {};
            return e[G.module()];
        };
    }();
    G.folderMap = function() {
        var e = [];
        return function() {
            var t = G.module();
            if (t === 1 || t === 2 || t === 3) {
                t = 0;
            }
            e[t] = e[t] || {};
            return e[t];
        };
    }();
    G.module = function() {
        var e = 0;
        var t = {
            0: "首页",
            1: "文件夹内",
            2: "成员文件列表",
            3: "搜索结果页"
        };
        return function(a) {
            if (a === undefined) {
                return e;
            } else if (t[a]) {
                if (a !== 3) {
                    $("#inputSearch").val("");
                }
                return e = a;
            } else {
                console.log("illegal module");
            }
        };
    }();
    G.checkHttps = function() {
        var e = location.href;
        return e.indexOf("https://") >= 0 ? true : false;
    };
    G.scrollHandler = function() {
        var e = [];
        return function(t) {
            var a = G.module();
            if (t) {
                return e[a] = t;
            } else {
                e[a] = e[a] || function() {};
                e[a]();
            }
        };
    }();
    function c() {
        var e = location.href;
        if (e.indexOf("groupShareClientV2.html") > 0) {
            G.newUi = true;
        }
        if (navigator.userAgent.indexOf("Mac OS X") >= 0) {
            G.mac = true;
            $("#inputSearch").attr("placeholder", "");
            $("#navTopFolder").attr("data-action", "menu.filenum");
            $(".refresh-icon").attr("data-action", "menu.refresh").click(function() {
                window.location.reload();
            });
        } else {
            $("#inputSearch").attr("placeholder", "搜索");
        }
    }
    function u() {
        var e = a(18);
        var t = a(19);
        var i = a(20);
        var n = a(21);
        var r = a(22);
        var o = a(23);
        var l = a(24);
        c();
        G.info = e.getInfo();
        l.init();
        t.init();
        n.init();
        i.init();
        r.init();
        o.action(s);
        if (localVersion === "isLocal") {
            report("offlinePage");
        }
        report("expnew");
    }
    function p() {
        if (typeof $ === "function" && (typeof QReport === "undefined" ? "undefined" : i(QReport)) === "object") {
            if (__getParameter("jumphttp") === "1") {
                setTimeout(function() {
                    new Image().src = '//report.url.cn/cgi-bin/data_report_collection?type=1000000&monitor=["2394630"]';
                }, 200);
            }
            u();
        } else {
            requestAnimationFrame(p);
        }
    }
    p();
}, , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    e.exports = function() {
        var e = function x(e) {
            var t = new RegExp("(?:^|;+|\\s+)" + e + "=([^;]*)"), a = document.cookie.match(t);
            return !a ? "" : a[1];
        };
        var t = function k() {
            var t = e("uin");
            if (!t) {
                return 0;
            }
            t += "";
            return t.replace(/^[\D0]+/g, "");
        };
        var a = function F(e, t) {
            t = t || location.href;
            var a = new RegExp("(\\?|#|&)" + e + "=([^&^#]*)(&|#|$)"), i = t.match(a);
            return decodeURIComponent(!i ? "" : i[2]);
        };
        var n = function T(e) {
            e += "";
            return e.replace(/^[ 　]*/gi, "");
        };
        var r = function $(e, t) {
            var a = t || 3;
            e += "";
            e = n(e);
            var i = e.match(/[^\x00-\xff]/g) || [];
            var r = e.replace(/[^\x00-\xff]/g, "");
            return parseInt(i.length * a + r.length);
        };
        function o(e, t) {
            var a = 0;
            for (var i = 0; i < e.length; i++) {
                var n = e.charAt(i);
                encodeURI(n).length > 2 ? a += 1 : a += .5;
                if (a >= t) {
                    var r = a == t ? i + 1 : i;
                    return e.substr(0, r);
                    break;
                }
            }
            return e;
        }
        function l(e) {
            var t = 0;
            for (var a = 0; a < e.length; a++) {
                var i = e.charAt(a);
                encodeURI(i).length > 2 ? t += 1 : t += .5;
            }
            return t;
        }
        var s = function S(e, t, a) {
            var i = r(e, 3);
            if (i < t || i > a) {
                return false;
            }
            return true;
        };
        var d = function _(e, t) {
            var t = t || 10;
            var a = r(e);
            var i = t - a;
            return i >= 0 ? i : 0;
        };
        var f = function C(e, t) {};
        window.onerror = function(e, t, a) {};
        function c(e) {
            if (e && e.length > 0) {
                e.addClass("remove-ease");
                setTimeout(function() {
                    e.remove();
                }, 300);
            }
        }
        var u = function M(e, t) {
            return function(a) {
                var i = arguments.length;
                if (t) a = Object(a);
                if (i < 2 || a == null) return a;
                for (var n = 1; n < i; n++) {
                    var r = arguments[n], o = e(r), l = o.length;
                    for (var s = 0; s < l; s++) {
                        var d = o[s];
                        if (!t || a[d] === void 0) a[d] = r[d];
                    }
                }
                return a;
            };
        };
        var p = function D(e) {
            var t = typeof e === "undefined" ? "undefined" : i(e);
            return t === "function" || t === "object" && !!e;
        };
        var v = function R(e) {
            if (!p(e)) return [];
            var t = [];
            for (var a in e) {
                t.push(a);
            }
            return t;
        };
        var m = u(v);
        function h() {
            var e = {};
            var t = Object.keys(G.folderMap());
            for (var a = t.length - 1; a >= 0; a--) {
                var i = G.folderMap()[t[a]];
                if (i) {
                    e[i.fnameEsc] = i;
                }
            }
            var n = "新建文件夹";
            var r = 1;
            while (e[n] !== undefined) {
                n = "新建文件夹(" + r + ")";
                r++;
            }
            return n;
        }
        var g = function j(e, t) {
            if (e.length <= 1) {
                return e;
            }
            var a = Math.floor(e.length / 2);
            var i = e.splice(a, 1)[0];
            var n = [];
            var r = [];
            for (var o = 0; o < e.length; o++) {
                if (e[o]) {
                    if (e[o][t] > i[t]) {
                        n.push(e[o]);
                    } else {
                        r.push(e[o]);
                    }
                }
            }
            return j(n, t).concat([ i ], j(r, t));
        };
        function w(e, t) {
            var a = t.map(function(e) {
                return e.replace(/([.?*+^$[\]\\(){}|-])/g, "\\$1");
            });
            var i = "(" + a.join("|") + ")";
            var n = e.split(new RegExp(i, "i"));
            return n;
        }
        function b(e, t) {
            for (var a = t.length - 1; a >= 0; a--) {
                t[a] = ("" + t[a]).toUpperCase();
            }
            var i = [];
            for (var a = e.length - 1; a >= 0; a--) {
                if (t.indexOf(e[a].toUpperCase()) !== -1) {
                    i[a] = '<span class="match-word">' + e[a] + "</span>";
                } else {
                    i[a] = e[a];
                }
            }
            return i.join("");
        }
        function y(e, t) {
            var a = w(e, t);
            return b(a, t);
        }
        return {
            getCookie: e,
            getUin: t,
            getParameter: a,
            getLen: r,
            changeLen: d,
            checkLength: s,
            checkLen: f,
            extend: m,
            removeEase: c,
            subString: o,
            quickSortByObjectAttr: g,
            getFolderNameDefault: h,
            heightLight: y
        };
    }();
}, function(e, t, a) {
    "use strict";
    a(77);
}, function(e, t, a) {
    "use strict";
    var i = a(86), n = a(15), r = $(G.handler), o;
    var l = a(50);
    var s = {
        fail: "fail",
        wait: "wait",
        suc: "suc",
        alert: "new-alert"
    }, d, f;
    function c(e, t) {
        var a = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];
        if (G.mac) {
            if (e === "fail") {
                l.alert(2, "提示", t);
            }
        } else {
            if (!o) {
                var n = {
                    cls: s[e],
                    text: t
                };
                var r = i(n);
                $("body").append(r);
                o = $("#toastDom");
                d = o.find(".toast-icon");
                f = o.find(".toast-message");
            } else {
                d.attr("class", "icons-" + s[e] + " toast-icon");
                f.text(t);
            }
            o.addClass("open");
            if (a) {
                setTimeout(function() {
                    u();
                }, 1e3);
            }
        }
    }
    function u() {
        if (o) {
            o.removeClass("open");
        }
    }
    r.bind("toast.show", function(e, t) {
        if (t && t.type && t.text) {
            c(t.type, t.text, t.autoHide);
        }
    });
    r.bind("toast.hide", function(e, t) {
        u();
    });
    e.exports = {
        show: c,
        hide: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(15), n = a(50);
    function r() {
        var e = i.getUin();
        var t = i.getParameter("gid");
        var a = function() {
            var a = "refresh_" + e + "_" + t;
            if (i.getCookie(a) * 1) {
                i.getCookie(a);
                return true;
            }
            return false;
        }();
        if (!/^\d+$/.test(t)) {
            t = parseInt(t, 10);
            if (isNaN(t)) {
                t = "0";
            }
        }
        var r = i.getParameter("visitor");
        var o = r === "1";
        var l = n.getVersion().version;
        var s = {
            uin: parseInt(e),
            gc: parseInt(t),
            isVisitor: o,
            nickName: n.getNickName(e),
            fromRefresh: a,
            version: l
        };
        return s;
    }
    e.exports = {
        getInfo: r
    };
}, function(e, t, a) {
    "use strict";
    var i = undefined;
    var n = undefined;
    var r = undefined;
    var o = [];
    var l = window.localStorage;
    var s = {};
    function d() {
        if (!i) {
            i = "lp" + G.info.gc + "-" + G.info.uin;
        }
        if (!r) {
            r = "tips" + G.info.gc + "-" + G.info.uin;
        }
        if (!n) {
            n = "clist" + G.info.gc + "-" + G.info.uin;
        }
        return i;
    }
    function f(e) {
        try {
            l.setItem(r, e);
        } catch (t) {
            l.clear();
            l.setItem(r, e);
        }
    }
    function c() {
        return l.getItem(r);
    }
    function u(e) {
        s[e.filepath] = e.localpath;
        o.push(e);
        console.log("set local:", e);
        try {
            l.setItem(i, JSON.stringify(s));
            l.setItem(n, JSON.stringify(o));
        } catch (t) {
            l.clear();
            l.setItem(i, JSON.stringify(s));
            l.setItem(n, JSON.stringify(o));
        }
    }
    function p(e) {
        if (e.orcType === 1) {
            delete s[e.filepath];
        } else {
            delete s[e.id];
        }
        try {
            l.setItem(i, JSON.stringify(s));
        } catch (t) {
            l.clear();
            l.setItem(i, JSON.stringify(s));
        }
    }
    function v(e) {
        return s[e] || false;
    }
    function m(e) {
        var t = arguments.length <= 1 || arguments[1] === undefined ? "push" : arguments[1];
        if (t === "push") {
            o.push(e);
        } else if (t === "delete") {
            o = o.filter(function(t) {
                return e.localpath !== t.localpath;
            });
        }
        try {
            l.setItem(n, JSON.stringify(o));
        } catch (a) {
            l.clear();
            l.setItem(n, JSON.stringify(o));
        }
    }
    function h() {
        var e = l.getItem(n);
        if (e === null) {
            return [];
        }
        try {
            return JSON.parse(e);
        } catch (t) {
            return [];
        }
    }
    function g() {
        l.removeItem(n);
    }
    function w() {
        i = d();
        o = h();
        var e = l.getItem(i);
        if (e) {
            s = JSON.parse(e);
        }
    }
    e.exports = {
        set: u,
        remove: p,
        check: v,
        init: w,
        setTips: f,
        getTips: c,
        clearClist: g,
        getClist: h,
        setClist: m
    };
}, function(e, t, a) {
    "use strict";
    var i = a(51);
    var n = a(52);
    var r = a(53);
    var o = a(54);
    var l = a(19);
    var s = a(55);
    var d = a(50);
    var f = $(G.handler);
    window.client = d;
    function c() {
        for (var e in r) {
            if (r.hasOwnProperty(e)) {
                f.bind("box." + e, r[e]);
            }
        }
    }
    function u() {
        var e = d.getTaskListAdv();
        var t = l.getClist();
        G.pList = s.cleanMap(e.map);
        G.compList = t;
        if (G.compList) {
            for (var a = 0, i = G.compList.length; a < i; a++) {
                var n = G.compList[a];
                var r = o.getData(n.filepath);
                if (!r) {
                    n.id = n.filepath;
                    o.addData(n);
                }
            }
        }
        c();
    }
    e.exports = {
        init: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(80);
    var n = l(i);
    var r = a(81);
    var o = l(r);
    function l(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var s = a(82).getHandlerTasks();
    var d = a(83);
    var f = a(84);
    var c = a(85);
    var u = $(G.handler);
    G.tab = f;
    function p(e) {
        var t = $(this).data("keyup");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function v(e) {
        var t = $(this).data("keydown");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function m(e) {
        var t = $(this).data("blur");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this, e);
            }
        }
    }
    function h() {
        this.inputStart = true;
    }
    function g() {
        var e = this;
        setTimeout(function() {
            e.inputStart = false;
        }, 200);
    }
    function w(e) {
        var t = $(e.target);
        if (t.parents("#box").length === 0 && t.data("action") !== "box.toggle") {
            u.trigger("box.hide");
        }
    }
    function b(e) {
        var t = $(this).data("focus");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this);
            }
        }
    }
    function y(e) {
        var t = $(this).data("action");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this);
            }
            if (t === "openGroupInfoCard") {
                e.stopPropagation();
            }
        } else {
            u.trigger("box.hide");
        }
    }
    function x(e) {
        var t = $(this).data("dbaction");
        if (t) {
            var a = s[t];
            if (typeof a === "function") {
                a.call(this);
            }
        } else {
            u.trigger("box.hide");
        }
    }
    function k() {
        o.init();
        $(document).on("click", "[data-action]", y);
        $(document).on("dblclick", "[data-dbaction]", x);
        $("body").on("click", w);
        $(document).on("keyup", "[data-keyup]", p);
        $(document).on("keydown", "[data-keydown]", v);
        $(document).on("focus", "[data-focus]", b);
        $(document).on("blur", "[data-blur]", m);
        $(document).on("compositionstart", "[data-cstart]", h);
        $(document).on("compositionend", "[data-cend]", g);
        $("body").on("click", function(e) {
            d["menu.hide"](e.target);
        });
        $(window).on("load", function() {
            $(".scroll-dom").scroll(function() {
                var e = document.querySelector(".scroll-dom").scrollHeight;
                var t = $(".scroll-dom").scrollTop();
                var a = $(".scroll-dom").height();
                var i = 30;
                if (e - (t + a) <= i) {
                    G.scrollHandler && G.scrollHandler();
                }
            });
        });
    }
    e.exports = {
        init: k
    };
}, function(e, t, a) {
    "use strict";
    var i = a(78);
    var n = a(79);
    var r = $(G.handler);
    var o = function d() {
        i.checkVip().done(function(e) {
            if (e && e.vinfo && e.vinfo.supervip) {
                G.flagIsVip = true;
            } else {
                G.flagIsVip = false;
            }
            n.showQQVip();
        }).fail(function(e) {
            n.showQQVip();
        });
    };
    var l = function f() {
        n.show();
        r.trigger("menu.hide");
    };
    var s = function c() {
        report("openVip");
        if (G.activeElement) {
            G.activeElement.focus();
        }
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    e.exports = {
        init: o,
        "vip.show": l,
        "vip.open": s
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(56);
    var r = a(57);
    var o = a(58);
    var l = a(59);
    G.initInFolder = false;
    var s = function f(e) {
        try {
            G.setHistory({
                action: "fileList",
                params: {
                    folderId: "/",
                    fname: false
                }
            });
        } catch (t) {}
        if (e === "") {
            l.init();
        } else {
            try {
                e = JSON.parse(e);
            } catch (t) {
                l.init();
                return;
            }
        }
        if (e.action === "fileList") {
            var a = e.params;
            a = (typeof a === "undefined" ? "undefined" : i(a)) === "object" ? a : {};
            var s = a.folderId;
            if (s === "/") {
                l.init();
            } else {
                G.initInFolder = s;
                l.getList({})();
                n["folder.open"](s, a.fname);
            }
        } else if (e.action === "search") {
            (function() {
                var t = e.params;
                t = (typeof t === "undefined" ? "undefined" : i(t)) === "object" ? t : {};
                var a = t.keyword;
                $("#inputSearch").val(a);
                var n = t.files[0];
                o.search(undefined, function(e) {
                    var t = true;
                    var i = false;
                    return function() {
                        if (t) {
                            r["file.getAttr"](e, a);
                            t = false;
                        }
                        if (!i) {
                            var n = "#" + ("/" + e["busId"] + e["fileId"]).replace(/\//gi, "-");
                            i = true;
                        }
                    };
                }(n));
            })();
        }
    };
    var d = function c() {
        window.addEventListener("storage", function(e) {
            if (e.key !== "notifyOtherGroup") {
                return;
            }
            var t = {};
            try {
                t = JSON.parse(e.newValue);
            } catch (e) {
                console.log("decode JSON fail");
                return;
            }
            if (t.gc !== G.info.gc) {
                return;
            }
            var a = t.webParams;
            s(a);
        });
    }();
    e.exports = {
        action: s
    };
}, function(e, t, a) {
    "use strict";
    var i = a(60);
    var n = $(G.handler);
    var r = function l(e, t) {
        i.getFileCount(function(a) {
            if (G.file.isFull) {
                $(".icons-upload-1").addClass("disabled");
                $(".icons-new-folder-1").addClass("icons-new-folder-2");
                o();
                try {
                    if (t === "delete") {
                        reportNew("changeHand");
                    } else if (t !== "downloadcomplete") {
                        reportNew("limitOver");
                    }
                } catch (i) {}
            } else {
                $(".icons-upload-1").removeClass("disabled");
                $(".icons-new-folder-1").removeClass("icons-new-folder-2");
                o();
            }
            if (e) {
                location.reload();
            }
        });
    };
    var o = function s(e) {
        if (G.file.isTooMany) {
            var t = undefined;
            try {
                if (G.info.isMaster) {
                    t = 2;
                } else if (G.info.isAdmin) {
                    t = 1;
                } else {
                    t = 0;
                }
                reportNew("showLimit", {
                    ver1: t
                });
            } catch (e) {}
            $("#alertTips").addClass("not-opacity");
            if (typeof G.info.isMaster === "undefined") {
                $("#alertTips").html('<div class="more-file-info"><i class="icons-alert"></i>文件数已超出上限，无法显示文件夹。</div><div class="more-file-tips">请提醒群主或管理员清除</div>');
            } else if (G.info.isMaster) {
                $("#alertTips").html('<div class="more-file-info"><i class="icons-alert"></i>文件数已超出上限，无法显示文件夹。</div><div class="more-file-tips">请自行清理或<a class="auto-delete-file" data-action="file.autoClear">自动删除旧文件</a></div>');
            } else if (G.info.isAdmin) {
                $("#alertTips").html('<div class="more-file-info"><i class="icons-alert"></i>文件数已超出上限，无法显示文件夹。请尽快处理</div>');
            }
        } else {
            $("#alertTips").html('<a href="http://kf.qq.com/faq/120511jiYzIJ140828eimiAR.html" target="_blank" data-action="tips.close">【网络正能量倡议书】腾讯呼吁网友共建绿色QQ群 抵制色情、反动等违法信息。</a><div class="close" data-action="tips.close"></div>').removeClass("not-opacity");
        }
    };
    n.bind("filecount.getrole", o);
    e.exports = {
        init: r
    };
}, , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = top.external;
    function r() {
        var e = undefined;
        if (window.external && n.getTaskList) {
            e = n.getTaskList();
            if (typeof e !== "string") {
                e = "";
            }
        } else {}
        return e;
    }
    function o() {
        var e = {};
        if (window.external && n.getTaskList) {
            var t = n.getTaskList();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if (i(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    function l() {
        var e = undefined;
        if (window.external && n.getCompleteTaskList) {
            e = n.getCompleteTaskList();
            if (e === null) {
                e = "";
            }
        } else {
            console.log("task相关接口不存在 getTaskList");
        }
        return e;
    }
    function s() {
        var e = {};
        if (window.external && n.getCompleteTaskList) {
            var t = n.getCompleteTaskList();
            if (typeof t !== "string") {
                t = "";
            }
            if (t === "") {
                e.map = {};
                e.status = "busy";
            } else if (t === "{}") {
                e.map = {};
                e.status = "ok";
                e.empty = true;
            } else {
                try {
                    e.map = JSON.parse(t);
                } catch (a) {
                    console.error("客户端接口getCompleteTaskList返回的数据有问题?parse出错[" + t + "]");
                }
                if (i(e.map) === "object" && e.map !== null) {
                    e.status = "ok";
                } else {
                    e.map = {};
                    e.status = "parseerror";
                }
            }
        } else {
            e = {
                map: {},
                status: "ok",
                empty: true
            };
        }
        return e;
    }
    function d(e) {
        if (window.external && n.getTaskInfo) {
            var t = n.getTaskInfo(e);
        } else {}
        return ret;
    }
    function f(e, t) {
        var a = undefined;
        if (!e) {
            e = 1;
        }
        if (window.g_flag_upload_temp) {
            e = 2;
        }
        if ("addUploadTask" in n) {
            a = n.addUploadTask(e, t);
        } else {}
        return a;
    }
    function c(e, t, a, i) {
        var r = arguments.length <= 4 || arguments[4] === undefined ? false : arguments[4];
        var o = arguments.length <= 5 || arguments[5] === undefined ? false : arguments[5];
        var l = undefined;
        if (window.external && n.addDownloadTask) {
            a = a + "";
            l = n.addDownloadTask(e, t, a, i, r || false, o);
        } else {
            l = -1;
        }
        return l;
    }
    function u(e) {
        var t = undefined;
        if (window.external && n.downloadFiles) {
            t = n.downloadFiles(JSON.stringify(e));
            console.debug(t);
        } else {
            t = -1;
        }
        return t;
    }
    function p(e, t, a) {
        var i = undefined;
        if (window.external && n.downloadByXF) {
            a = a + "";
            i = n.downloadByXF(e, t, a);
            console.debug(i);
        } else {
            i = -1;
        }
        return i;
    }
    function v(e, t, a) {
        var i = undefined;
        if (window.external && n.forwardFile) {
            i = n.forwardFile(t, e, a);
        } else {
            i = -1;
        }
        return i;
    }
    function m(e, t, a) {
        var i = undefined;
        if (window.external && n.forwardFileToDataLine) {
            i = n.forwardFileToDataLine(t, e, a);
        } else {
            i = -1;
        }
        return i;
    }
    function h(e, t, a, i) {
        var r = undefined;
        console.log("client", e, t, a, i);
        if (window.external && n.addContinueUploadTask) {
            r = n.addContinueUploadTask(e, t, a, i);
            console.log(r);
        } else {
            r = -1;
        }
        return r;
    }
    function g(e) {
        var t = undefined;
        if (window.external && n.removeTask) {
            t = n.removeTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function w(e) {
        var t = undefined;
        if (window.external && n.removeCompleteTask) {
            t = n.removeCompleteTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function b(e) {
        var t = undefined;
        if (window.external && n.pauseTask) {
            t = n.pauseTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function y(e) {
        var t = undefined;
        if (window.external && n.resumeTask) {
            t = n.resumeTask(e);
        } else {
            t = -1;
        }
        return t;
    }
    function x() {
        var e = top.external && top.external.CallHummerApi;
        if (e) {
            var t = undefined;
            try {
                t = e.apply(this, arguments);
                t = JSON.parse(t);
                return t;
            } catch (a) {
                return false;
            }
        }
        return false;
    }
    function k() {
        if (G.mac) {
            try {
                var e = n.getVersion();
                return {
                    errorCode: 0,
                    version: e
                };
            } catch (t) {
                return {
                    errorCode: 1,
                    version: 0
                };
            }
        } else {
            return x("IM.GetVersion");
        }
    }
    function F() {
        if (window["G_DEBUG"]) {
            return true;
        }
        var e = x("Contact.IsOnline");
        if (e) {
            return x("Contact.IsOnline").online;
        } else {
            return false;
        }
    }
    function T(e, t) {
        t = t || 1;
        return x("Contact.OpenContactInfoCard", '{ "uin" : "' + e + '", "tabId" : ' + t + " }");
    }
    function $(e, t) {
        t = t || 1;
        return x("Group.OpenGroupInfoCard", '{ "groupId" : "' + e + '", "tabId" : ' + t + " }");
    }
    function S(e, t) {
        var a = JSON.stringify({
            gc: "" + e,
            webParams: t
        });
        return x("Group.OpenGroupFile", a);
    }
    var _ = null;
    function C(e) {
        if (_) {
            return _;
        }
        var t = {
            uin: e + ""
        };
        t = JSON.stringify(t);
        var a = x("Contact.GetNickName", t);
        if (a && a.errorCode === 0 && a.nickName) {
            _ = a.nickName;
        }
        if (G.mac) {
            try {
                _ = n.getNickName(e);
            } catch (i) {
                _ = e;
            }
        }
        if (!_) {
            return e;
        }
        return _;
    }
    function M() {
        return x("IM.GetClientKey");
    }
    function D(e) {
        e += "&pictype=scaled&size=1024*1024";
        var t = undefined;
        if (G.mac) {
            t = window.external && window.external.previewPicture(e);
        } else {
            t = x("Misc.OpenWebPic", '{"url":"' + e + '"}');
        }
        return t;
    }
    function R(e, t) {
        window.external && window.external.previewFile(e, t);
    }
    function j() {
        var e = s();
        if (e.map) {
            for (var t in e.map) {
                var a = e.map[t];
                if (a.id) {
                    var i = w(a.id);
                    if (i === -1) {
                        console.warn("移除完成任务失败！");
                    }
                }
            }
        }
    }
    function I(e, t, a) {
        if (G.mac) {
            return window.alert(a);
        } else {
            return x("Window.Alert", '{ "iconType" : ' + e + ', "title" : "' + t + '", "text" : "' + a + '" }');
        }
    }
    function N(e, t, a) {
        if (G.mac) {
            var i = window.confirm(a);
            return {
                errorCode: 0,
                ret: i
            };
        } else {
            return x("Window.Confirm", '{ "iconType" : ' + e + ', "title" : "' + t + '", "text" : "' + a + '" }');
        }
    }
    function O() {
        var e = undefined;
        if (window.external && n.getUploadFiles) {
            e = n.getUploadFiles();
        } else {
            e = -1;
        }
        return e;
    }
    function L(e, t, a) {
        if (!a) {
            a = 1;
        }
        var i = undefined;
        if (window.external && n.uploadFiles) {
            i = n.uploadFiles(e, t, a);
        } else {
            i = -1;
        }
        return i;
    }
    function E(e, t, a) {
        console.log(e, t);
        var i = undefined;
        if (!a) {
            a = 1;
        }
        if ("onlineEditFile" in n) {
            i = n.onlineEditFile(e, t, a);
        } else {}
        return i;
    }
    function P(e) {
        var t = undefined;
        if (!remotetype) {
            remotetype = 1;
        }
        if (window.external && n.setUploadFileRemotePath) {
            t = n.setUploadFileRemotePath(e);
        } else {
            t = -1;
        }
        return t;
    }
    function A(e) {
        var t = undefined;
        if (window.external && n.addMultiDownloadTasks) {
            t = n.addMultiDownloadTasks(e);
        } else {
            t = -1;
        }
        return t;
    }
    e.exports = {
        getVersion: k,
        getBatchFiles: O,
        batchUpload: L,
        setUploadFileRemotePath: P,
        getTaskListAdv: o,
        getCompleteTaskListAdv: s,
        addUploadTask: f,
        addDownloadTask: c,
        addDownloadFast: p,
        addContinueUploadTask: h,
        removeTask: g,
        removeCompleteTask: w,
        pauseTask: b,
        resumeTask: y,
        getTaskInfo: d,
        forwardFile: v,
        forwardFileToDataLine: m,
        callHummerApi: x,
        getNickName: C,
        isOnline: F,
        getClientKey: M,
        preview: D,
        previewFile: R,
        clearClist: j,
        alert: I,
        confirm: N,
        openGroupInfoCard: $,
        openGroupFile: S,
        addMultiDownloadTasks: A,
        onlineEditFile: E
    };
}, function(e, t, a) {
    "use strict";
    var i = a(107), n = a(53), r = a(59);
    function o(e, t) {
        var a = t;
        if (!i.check(a)) {
            i.add(a);
        }
        n.addBoxRow(a);
        if (a.type === "download") {
            r.updateDownloadRow(a);
        }
    }
    $(G.handler).bind("client.addTask", o);
}, function(e, t, a) {
    "use strict";
    var i = a(107), n = a(53), r = a(59);
    function o(e, t) {
        var a = t;
        n.updateBoxRow(a);
        if (a.type === "download") {
            r.updateDownloadTimes(a);
            r.updateDownloadRow(a);
        }
    }
    $(G.handler).bind("client.updateTask", o);
}, function(e, t, a) {
    "use strict";
    var i = a(108);
    var n = a(15);
    var r = $("#boxNum");
    var o = $("#boxListDom");
    var l = $(G.handler);
    var s = false;
    var d = 0;
    var f = true;
    var c = false;
    function u(e, t) {
        var a = o.find('[data-path="' + e + '"]').filter('[data-name="' + t + '"]');
        if (a.length > 0 && !a.hasClass("complete")) {
            return a;
        }
        return false;
    }
    function p(e) {
        var t = o.find('[data-id="' + e + '"]');
        if (t.length > 0 && !t.hasClass("complete")) {
            return t;
        }
        return false;
    }
    function v(e) {
        if (e.type === 1 || e.type === "upload") {
            return p(e.taskId);
        } else if (e.orcType === 2) {
            return p(e.taskId);
        } else {
            return u(e.filepath, e.filename);
        }
    }
    function m(e) {
        var t = v(e);
        if (e.status === "remove") {
            d--;
            n.removeEase(t);
            b();
            return;
        }
        var a = i({
            list: [ e ]
        });
        if (t) {
            t.replaceWith(a);
        }
        if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
            $("#boxTitle").attr("class", "box-title tri");
            d--;
            b();
        }
    }
    function h(e) {
        var t = v(e);
        c = true;
        if (t.length > 0) {
            return;
        }
        var a = i({
            list: [ e ]
        });
        s = true;
        d++;
        b();
        o.prepend(a);
        o.removeClass("empty");
    }
    function g(e) {}
    function w(e, t) {}
    function b() {
        if (d < 0) {
            d = 0;
        }
        if (d) {
            r.text(d).addClass("small");
        } else {
            r.text(d).removeClass("small");
        }
    }
    function y() {
        c = false;
    }
    function x(e, t) {
        var a = i(t);
        if (s) {
            o.append(a);
        } else {
            o.html(a);
        }
    }
    var k = function _(e) {
        var t = [];
        var a = [];
        for (var i = 0, n = e.length; i < n; i++) {
            if ($.inArray(e[i].id, t) < 0 && $.inArray(e[i].filepath, t) < 0) {
                if (e[i].id) {
                    t.push(e[i].id);
                }
                if (e[i].filepath) {
                    t.push(e[i].filepath);
                }
                a.push(e[i]);
            }
        }
        return a;
    };
    function F() {
        if (!f) {
            return;
        }
        f = false;
        var e = [];
        var t = G.cList;
        var a = G.pList;
        var i = G.compList;
        t = t.concat(a);
        var n = t.length;
        e = t;
        if (i) {
            e = t.concat(i);
        }
        e = k(e);
        d = n;
        b();
        x(null, {
            list: e
        });
        if (e.length > 0) {
            o.removeClass("empty");
        }
        if (i.length > 0) {
            $("#boxTitle").attr("class", "box-title tri");
        } else {}
    }
    function T() {
        n.removeEase(o.find(".complete"));
        if (G.mac) {
            var e = o.find(".err");
            var t = e.length;
            for (var a = 0; a < t; a++) {
                var i = e.eq(a);
                var r = i.data("id");
                l.trigger("task.removeOne", r);
                n.removeEase(i);
            }
        }
        setTimeout(function() {
            if (o.find(".file2").length === 0) {
                o.addClass("empty");
            }
        }, 500);
        $("#boxTitle").attr("class", "box-title empty");
    }
    function S(e) {
        var t = o.find('[data-path="' + e.filepath + '"]');
        t.find(".go-folder").addClass("disable");
    }
    e.exports = {
        updateBoxRow: m,
        addBoxRow: h,
        removeBoxRow: g,
        cleanBox: w,
        render: x,
        firstRender: F,
        updateBoxNum: b,
        clearComplete: T,
        removePoint: y,
        removeOpenFolder: S
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(109);
    var r = a(112);
    var o = a(153);
    var l = a(107);
    var s = a(154);
    var d = a(15);
    var f = a(55);
    var c = a(19);
    var u = $(G.handler);
    var p = {};
    var v = false;
    var m = $("#groupSize");
    var h = $("#groupSizeBar");
    function g(e) {
        if (e.orcType === 1) {
            var t = G.module() === 1 ? 1 : 0;
            var a = $("#" + e.domid);
            var i = a.attr("idx");
            var n = t;
            if (typeof i !== "undefined") {
                n += "_" + i;
            }
            var r = e.uin === G.info.uin ? 1 : 2;
            return {
                ver1: e.isDown ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: r,
                ver4: encodeURIComponent(e.fname),
                ver5: encodeURIComponent(e.filetype),
                ver6: n
            };
        } else if (e.orcType === 2) {
            var t = 0;
            var a = $("#" + e.domid);
            var i = a.attr("idx");
            var o = t;
            if (typeof i !== "undefined") {
                o += "_" + i;
            }
            var r = G.info.uin === e.uin ? 1 : 2;
            return {
                ver1: e.filenum === e.downNum ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: r,
                ver4: encodeURIComponent(e.name),
                ver5: o
            };
        }
        return false;
    }
    G.getReportInfo = g;
    function w() {
        if (G.nowFolder !== "/") {
            return;
        }
        m.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        h.css("width", e + "%");
        $("#fileNum").removeClass("hide");
    }
    e.exports = p;
    function b(e) {
        e += "";
        return e.replace(/\//gi, "-");
    }
    p.getId = b;
    p.updateFile = function(e, t) {
        if (t === "rename" && e) {
            e.mt = Math.ceil(new Date().getTime() / 1e3);
            e.mtStr = r.getDateStr(e.mt);
            e.mtoStr = r.getorcDateStr(e.mt);
        }
        if (t === "permanent" && e) {
            delete G.fileMap()[e.filepath];
            if (e.id) {
                delete G.fileMap()[e.id];
            }
            G.fileMap()[e.newFilePath] = e;
            e.filepath = e.newFilePath;
        }
    };
    p.updateFolder = function(e) {
        delete G.folderMap()[e.id];
        e.modify_time = Math.ceil(new Date().getTime() / 1e3);
        e.mt = e.modify_time;
        e.mtStr = r.getDateStr(e.modify_time);
        e.mtoStr = r.getorcDateStr(e.modify_time);
        G.folderMap()[e.id] = e;
        return e;
    };
    p.filterFolder = function(e) {
        var t = {
            fname: e.name,
            fnameEsc: o.decode(e.name),
            name: e.name,
            id: e.id,
            icon: "folder",
            ct: e.create_time,
            ctStr: r.getDateStr(e.create_time),
            ctoStr: r.getorcDateStr(e.create_time),
            mt: e.modify_time,
            mtStr: r.getDateStr(e.modify_time),
            mtoStr: r.getorcDateStr(e.modify_time),
            uin: e.owner_uin || G.info.uin,
            filenum: e.size,
            nick: e.owner_name || G.info.nickName,
            mnick: e.modify_name || G.info.nickName,
            muin: e.modify_uin || G.info.uin,
            orcType: e.type || 2,
            domid: b(e.id),
            downNum: 0
        };
        var a = c.check(t.id);
        if (a) {
            t.localpath = a;
            t.succ = true;
        }
        return t;
    };
    p.addData = function(e) {
        if (!e) {
            return;
        }
        if (e.orcType === 2) {
            G.folderMap()[e.id] = e;
        } else {
            G.fileMap()[e.filepath] = e;
        }
    };
    p.getData = function(e) {
        return G.folderMap()[e] || G.fileMap()[e] || false;
    };
    p.remove = function(e) {
        if (G.folderMap()[e]) {
            delete G.folderMap()[e];
        }
        var t = G.fileMap()[e];
        if (t) {
            t.isRemoved = true;
            delete G.fileMap()[e];
            delete G.fileMap()[t.filepath];
        }
    };
    p.getFile = function(e, t) {
        return G.fileMap()[e] || G.fileMap()[t] || false;
    };
    p.getTask = function(e) {
        return G.cMap[e] || false;
    };
    p.setAllNum = function(e) {
        var t = "total_cnt";
        if (!G.file) {
            G.file = {};
        }
        G.file.allnum = e.total || 0;
    };
    p.setFileCount = function(e) {
        if (!G.file) {
            G.file = {};
        }
        G.file.fileCount = e.file_count || 0;
        G.file.isTooMany = e.is_too_many;
        G.file.isFull = e.is_full;
    };
    p.setAllSpace = function M(e) {
        if (!G.file) {
            G.file = {};
        }
        G.file.capacitytotal = n.getSize(e.totalSpace);
        G.file.capacityused = n.getSize(e.usedSpace);
        G.file.ct = e.totalSpace;
        G.file.cu = e.usedSpace;
    };
    p.removeAllNum = function(e) {
        if (G.file.allnum) {
            G.file.allnum--;
        }
        if (e.remoteType === 1) {
            G.file.cu -= e.size;
            G.file.capacityused = n.getSize(G.file.cu);
        }
    };
    p.addAllNum = function(e) {};
    p.updateAllNum = function(e) {
        var t = {
            files: [],
            action: ""
        };
        e = d.extend(t, e);
        var a = e.action;
        var i = e.files;
        var n = 0;
        for (var r = i.length - 1; r >= 0; r--) {
            n += i[r].size;
        }
        if (a === "add") {
            G.file.allnum = G.file.allnum + i.length;
            G.file.cu += n;
        } else if (a === "remove") {
            G.file.allnum = G.file.allnum - i.length;
            G.file.cu -= n;
        } else {
            console.log("illegal action");
        }
        w();
    };
    p.setRole = function(e) {
        if (v) {
            return;
        }
        v = true;
        var t = e.userRole || 0;
        var a = e.openFlag || 0;
        var i = 0;
        var n = 0;
        var r = false;
        var o = e.userRole === 3 ? true : false;
        if (t >= 1 && t !== 4) {
            i = 1;
            t === 1 && (n = 1);
            r = true;
        } else if (t === 3 && a === 1) {
            o = true;
        }
        G.info.isAdmin = i;
        G.info.isMaster = n;
        G.info.isVisitor = o;
        G.info.isPublic = a;
        u.trigger("filecount.getrole");
        G.canCreateFolder = r;
        report("enter", a);
        report("showSearchBtn");
        $("body").addClass("auth" + G.info.isAdmin);
    };
    function y(e) {
        var t = {};
        for (var a in e) {
            t[a] = e[a];
        }
        return t;
    }
    p.task2file = function(e) {
        var t = e;
        var a = t.filepath.substr(1, 3);
        a = parseInt(a);
        var i = parseInt(new Date().getTime() / 1e3, 10);
        var l = n.getFileName(t.filename);
        if (t.status !== "downloadcomplete") {
            t.name = l.filename_name;
            t.fname = t.filename;
            t.fnameEsc = o.decode(t.filename);
            t.nameEsc = o.decode(l.filename_name);
            t.folderid = b(t.folderpath);
            t.down = 0;
            t.filepath = t.filepath;
            t.fp = t.filepath.substr(4);
            t.domid = b(t.filepath);
            t.busid = a;
            t.filetype = n.getType(l.filename_suf);
            t.uin = G.info.uin;
            t.nick = G.info.nickName;
            t.upsize = t.filesize;
            t.temp = a == 102 ? false : true;
            t.ttl = 86400;
            t.ct = i;
            t.ctStr = r.dayStr(i);
            t.ctoStr = r.getorcDateStr(i);
            t.mt = i;
            t.mtStr = r.getDateStr(i);
            t.mtoStr = r.getorcDateStr(i);
            t.type = 1;
            t.succ = true;
            t.admin = true;
            t.isDown = true;
            t.remove = true;
            t.rename = true;
            t.size = t.size;
            t.canEdit = n.canEdit(t.filetype, t.admin);
            t.remoteType = a === 102 ? 1 : 2;
            t.parentId = t.folderpath || "/";
        } else {
            var s = undefined;
            var d = t.id;
            if (t.downloadtasktype === 1) {
                s = y(G.folderMap()[t.filepath]);
            } else {
                s = y(G.fileMap()[t.filepath]);
            }
            t = $.extend(true, s, t);
            t.taskId = d;
            t.isDown = true;
            t.succ = true;
            t.domid = b(t.filepath);
        }
        if (G.cMap[t.id]) {
            delete G.cMap[t.id];
        }
        if (G.cMap[t.filepath]) {
            delete G.cMap[t.filepath];
        }
        if (t.orcType === 2) {
            t.id = t.filepath;
        }
        p.addData(t);
        return t;
    };
    p.setFileList = function(e, t) {
        if (!G.cMap) {
            G.cMap = {};
        }
        var a = [];
        var i = [];
        var f = [];
        var v = [];
        t = d.extend({
            fn: "name",
            t: "bus_id",
            uin: "owner_uin",
            dt: "download_times",
            ut: "create_time",
            mt: "modify_time",
            lp: "local_path",
            ufs: "upload_size",
            fp: "id",
            fs: "size",
            owner_name: "owner_name"
        }, t);
        var m = t.fn;
        var h = t.t;
        var g = t.uin;
        var w = t.dt;
        var y = t.ut;
        var k = t.mt;
        var F = t.lp;
        var T = t.ufs;
        var $ = t.fp;
        var S = t.fs;
        var C = t.owner_name;
        e = e || [];
        for (var M = 0, D = e.length; M < D; M++) {
            var R = e[M];
            if (R.type === undefined) {
                R.type = 1;
            }
            if (R.type === 1) {
                var j = n.getFileName(R[m]);
                var I = {
                    t: R[h],
                    exp: R.exp || 0,
                    lp: R[F],
                    busid: R[h],
                    fname: R[m],
                    fnameEsc: o.decode(R[m]),
                    name: j.filename_name,
                    nameEsc: o.decode(j.filename_name),
                    suf: j.filename_suf,
                    icon: n.getIcon(j.filename_suf),
                    domid: b("/" + R[h] + R[$]),
                    filepath: "/" + R[h] + R[$],
                    fp: R[$],
                    admin: false,
                    filetype: n.getType(j.filename_suf),
                    uin: R[g],
                    nick: R[C],
                    size: R[S],
                    sizeStr: n.getSize(R[S]),
                    upsize: R[T],
                    temp: R[h] === 104 ? true : false,
                    down: R[w],
                    ct: R[y],
                    ctStr: r.dayStr(R[y]),
                    ctoStr: r.getorcDateStr(R[y]),
                    mt: R[k],
                    parentId: R["parent_id"],
                    mtStr: r.dayStr(R[k]),
                    mtoStr: r.getorcDateStr(R[k]),
                    orcType: R.type,
                    md5: R.md5,
                    safeType: R["safe_type"],
                    remove: false,
                    rename: false,
                    isDown: false
                };
                if (R.gc) {
                    I.gc = R.gc;
                }
                if (R.group_name) {
                    I.gname = R.group_name;
                }
                I.admin = x(R[g]);
                if (I.admin) {
                    I.remove = true;
                    I.rename = true;
                }
                I.canEdit = n.canEdit(I.filetype, I.admin);
                I = _(I);
                var N = c.check(I.filepath);
                if (N) {
                    I.isDown = true;
                    I.localpath = N;
                    I.succ = true;
                    report("showOpenFile", G.module(), 1);
                } else {
                    report("showDownloadBtn", G.module(), 1);
                }
                reportNew("newFileShow", {
                    ver1: I.isDown ? 1 : 2,
                    ver2: G.info.isAdmin ? 1 : 2
                });
                if (I.safeType) {
                    var O = G.getReportInfo(I);
                    O.ver3 = O.ver4;
                    O.ver4 = O.ver5;
                    O.ver5 = O.ver6;
                    delete O.ver6;
                    reportNew("blackExp", O);
                }
                if (I.result === 3 && !G.previewCache[I.filepath]) {
                    a.push(I);
                }
                if (G.previewCache[I.filepath]) {
                    I.previewObj = G.previewCache[I.filepath];
                }
                G.fileMap()[I.filepath] = I;
                if (R[S] === R[T]) {
                    i.push(I);
                } else if (R[g] === G.info.uin) {
                    l.add(I);
                    f.push(I);
                }
            } else {
                var I = p.filterFolder(R);
                G.folderNum++;
                p.addData(I);
                v.push(I);
                reportNew("folderShow", {
                    ver1: I.downNum === I.fileNum ? 1 : 2,
                    ver2: G.info.isAdmin ? 1 : 2
                });
                report("showOpenFile", G.module(), 1);
            }
        }
        G.topFolder = {
            fname: "群文件",
            fnameEsc: "群文件",
            id: "/",
            icon: "folder",
            mt: 0,
            mtStr: 0,
            uin: 0,
            filenum: 0,
            nick: 0,
            type: 2
        };
        if (f.length > 0) {
            G.cList = f;
            u.trigger("box.renderNum");
        }
        if (a.length > 0) {
            s.getThumb(a);
        }
        if (v.length > 0) {
            report("folderNum", G.module(), v.length);
        }
        report("showSeeBtn", G.module());
        return {
            file: i,
            folder: v
        };
    };
    function x(e) {
        if (G.info.isAdmin || e === G.info.uin) {
            return true;
        } else {
            return false;
        }
    }
    function k(e) {
        if (G.info.isAdmin || e === G.info.uin) {
            return true;
        } else {
            return false;
        }
    }
    function F() {
        return !G.info.isVisitor;
    }
    var T = 1;
    var S = 2;
    function _(e) {
        var t = 0;
        if (!e || typeof e.name === "undefined") {
            console.log(!e, !e.name);
            return;
        }
        if (e.filepath) {
            e.filepath = e.filepath.replace(/\\\//g, "/");
        }
        if (!e.remoteType) {
            switch (e.busid) {
              case 102:
                e.remoteType = T;
                break;

              case 104:
              case 105:
                e.remoteType = S;
                break;

              default:
                e.remoteType = T;
            }
        }
        if (e.lp) {
            if (G.mac) {
                e.localpath = o.decode(e.lp);
            } else {
                e.localpath = o.decode(e.lp).replace(/\\|\//g, "\\\\");
            }
        }
        if (e.upsize < e.size) {
            if (e.uin === G.info.uin) {
                e.type = "continueupload";
                e.status = "continue";
                e.canContinueUpload = true;
                e.taskStarttime = e.ct;
                e.styles = "upload pause";
                e.csize = e.upsize;
                e.csizeStr = n.getSize(e.upsize);
                e.cPercent = 0;
                if (e.upsize && e.size) {
                    e.cPercent = 100 * e.upsize / e.size;
                }
                e.notComplete = true;
                e.result = 1;
                f.parse(e);
            }
        } else {
            e.result = 2;
            if (e.auditflag > 0) {
                console.warn("auditFlag", e);
            }
            var a = e.name;
            var i = e.size;
            var r = e.ct;
            if (!e.down) {
                e.down = 0;
            }
            if (e.filetype === "图片") {
                e.result = 3;
                if (!G.info.isVisitor) {
                    e.preview = true;
                }
            }
            if (e.remoteType === S && e.isAdmin) {
                e.canForever = true;
            }
            var l = 0;
            if (i < 1024 * 100) {
                l = 5;
            } else if (i < 1024 * 1024) {
                l = 4;
            } else if (i < 1024 * 1024 * 10) {
                l = 3;
            } else if (i < 1024 * 1024 * 50) {
                l = 2;
            } else if (i < 1024 * 1024 * 100) {
                l = 1;
            }
            var s = [];
            if (e.isAdmin) {
                e.canDelete = true;
                e.canRename = true;
                s.push("can_delete=1 ");
                s.push("can_rename=1 ");
            }
            if (e.preview) {
                s.push("can_preview=1 ");
            }
            if (e.canForever) {
                s.push("can_forever=1 ");
            }
            e.canDo = s.join("");
            e.showMore = "";
            if (e.canDo === "") {
                e.showMore = "disable_more";
            }
            e.sizeType = l;
            if (!e.styleTemp) {
                e.styleTemp = "";
            }
            if (!e.styleIssucc) {
                e.styleIssucc = "";
            }
            e.expireStr = "";
            e.fileTitle = e.filename;
            if (e.remotetype === S) {
                e.styleTemp = "temp";
                e.expireStr = d.getExpriesDayNum(e.ttl) + "天后到期";
                e.fileTitle += " (临时文件：剩余" + data.getExpriesDayNum(e.ttl) + "天)";
            }
        }
        return e;
    }
    var C = function() {
        var e = window.external && window.external.getPreviewSuffixConfig && window.external.getPreviewSuffixConfig();
        if (e === null) {
            e = {
                content: []
            };
        }
        if (typeof e === "string") {
            try {
                e = JSON.parse(e);
            } catch (t) {}
        }
        if ((typeof e === "undefined" ? "undefined" : i(e)) !== "object") {
            e = {
                content: []
            };
        }
        var a = {};
        if (e = e.content) {
            var n = function l(t, i) {
                var n = e[t].suffix, r = e[t].maxsize;
                var o = n.split(".");
                o.forEach(function(e, t, i) {
                    if (e) {
                        a[e] = r;
                    }
                });
            };
            for (var r = 0, o = e.length; r < o; r++) {
                n(r, o);
            }
        }
        return function(e, t) {
            var i = undefined;
            if ((i = a[e]) && t <= i) {
                return true;
            }
        };
    }();
    p.clearComplete = function() {
        l.clearComplete();
    };
}, function(e, t, a) {
    "use strict";
    var i = a(109);
    var n = a(110);
    var r = a(111);
    var o = a(112);
    var l = {};
    var s = {};
    function d(e) {
        try {
            if (!e) {
                return;
            }
            if (!G.cMap) {
                G.cMap = {};
            }
            e.taskId = e.id;
            if (e.taskId) {
                G.cMap[e.taskId] = e;
            }
            if (e.filepath) {
                G.cMap[e.filepath] = e;
            }
            var t = n.getType(e.type);
            n.check(t, e.status);
            var a = n.getWord(t, e.status);
            var i = n.getClass(t, e.status);
            if (i === "scan") {
                if (e.cPercent) {
                    a += e.cPercent + "%";
                }
                e.cPercent = 0;
                i = "pre";
            } else if (i === "pre") {
                e.cPercent = 0;
            } else if (i === "pause" || i === "continue") {
                if (e.csizeStr) {
                    a += e.csizeStr;
                }
                if (e.sizeStr) {
                    a += "/" + e.sizeStr;
                }
            } else if (i === "err") {
                e.cPercent = 0;
                if (e.status.indexOf("securityfail") >= 0) {
                    a = "<i class='warn'></i>" + getErrorWording(e);
                    if (e.securityattri >= 1 && e.securityattri <= 5) {
                        a += "<i class='security'></i>";
                    }
                } else {
                    if (e.errorcode == -1e3) {
                        a = "该文件已被删除";
                    }
                    a = "<i class='warn'></i>" + a;
                }
            } else if (i === "progress") {
                if (e.speedStr) {
                    a += e.speedStr;
                }
                var r = undefined;
                if (e.speed) {
                    var s = Math.ceil((e.filesize - e.completesize) / e.speed);
                    var d = Math.floor(s / 3600);
                    var f = Math.floor(s % 3600 / 60);
                    s = Math.floor(s % 60);
                    if (d < 10) {
                        d = "0" + d;
                    }
                    if (f < 10) {
                        f = "0" + f;
                    }
                    if (s < 10) {
                        s = "0" + s;
                    }
                    r = "<span class='lefttime'>" + d + ":" + f + ":" + s + "</span>";
                } else {}
                if (l[e.filepath]) {
                    var c = new Date() - l[e.filepath];
                    if (c > 3e3 && r) {
                        a += r;
                    }
                } else if (e.filepath) {
                    l[e.filepath] = new Date();
                }
            } else if (i === "complete") {
                e.cPercent = 100;
                a += e.sizeStr;
            } else {
                e.c_percent = 0;
            }
            var u = parseInt(new Date().getTime() / 1e3, 10);
            if (t !== "download") {
                e.ctStr = o.dayStr(u);
            }
            e.wording = a;
            e.styleType = t;
            if (t === "continueupload") {
                e.styleType = "upload";
            }
            e.styleStatus = i;
            if (e.failedFileList && e.failedFileList.length > 0) {
                e.styles = e.styleType;
            } else {
                e.styles = e.styleType + " " + e.styleStatus;
            }
        } catch (p) {
            console.warn("parse", p, e);
        }
    }
    function f(e) {
        e.taskId = e.id;
        if (e.downloadtasktype === 1) {
            e.filepath = e.folderpath;
            e.orcType = 2;
            e.icon = "folder";
            if (G.mac) {
                e.name = e.filename;
            } else {
                e.name = i.getFolderName(e.localpath);
            }
            e.filename = e.name;
            e.filelist = [];
            if (!e.status) {
                e.status = "downloadprogress";
            }
            e.filesize = e.foldersize;
        } else {
            e.orcType = 1;
        }
        e.speedStr = "";
        e.wording = "";
        e.csizeStr = "";
        e.updateFlag = true;
        var t = e.filename;
        var a = e.filesize;
        var n = e.createtime;
        e.speedStr = i.getSize(e.speed);
        if (e.speedStr === 0) {
            e.speedStr = "";
        } else {
            e.speedStr += "/S";
        }
        if (e.size === undefined) {
            e.size = e.completesize;
        }
        e.sizeStr = i.getSize(a);
        e.csizeStr = i.getSize(e.completesize);
        var r = 0;
        if (e.completesize > 0 && e.filesize > 0) {
            r = Math.round(e.completesize * 100 / e.filesize);
        }
        e.cPercent = r;
        var o = t.lastIndexOf(".");
        if (o >= 0) {
            e.name = t.substr(0, o);
            e.suf = t.substr(o);
        } else {
            e.name = t;
            e.suf = "";
        }
        if (!e.icon) {
            e.icon = i.getIcon(e.suf);
        }
        d(e);
        return e;
    }
    function c(e) {
        var t = [];
        for (var a in e) {
            var i = e[a];
            i = f(i);
            if (i.downloadtasktype !== 2) {
                t.push(i);
            } else {
                var n = p(i.fordertaskid);
                if (n) {
                    if (!n.fileTaskList) {
                        n.fileTaskList = [];
                    }
                    n.fileTaskList.push(i.id);
                }
            }
        }
        return t;
    }
    function u(e) {
        var t = [];
        for (var a in G.cMap) {
            var i = G.cMap[a];
            if (i.foldertaskid === e || i.folderpath === e) {
                t.push(i);
            }
        }
        return t;
    }
    function p(e) {
        return G.cMap[e] || false;
    }
    e.exports = {
        get: f,
        getFolderTask: u,
        getOneTask: p,
        parse: d,
        cleanMap: c
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPanel");
    var n = a(133);
    var r = a(134);
    var o = a(135);
    var l = a(136);
    var s = a(137);
    var d = a(138);
    var f = a(139);
    var c = a(140);
    var u = a(15);
    var p = a(115);
    var v = $(G.handler);
    var m = a(141);
    var h = a(17);
    function g() {}
    function w() {
        report("clkCreateFolder");
        if (G.file.isFull) {
            reportNew("limitTip", {
                ver1: 1
            });
            return h.show("alert", "文件数已达到上限");
        }
        if (this.nodeName === "LI") {
            reportNew("blankRightMenuClick", {
                ver1: G.customMenuLength ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: 2
            });
        }
        if (!G.canCreateFolder) {
            v.trigger("toast.show", {
                type: "new-alert",
                text: "文件夹个数已达上限"
            });
            return;
        }
        n.show(i, {
            title: "新建文件夹",
            tips: "请输入文件夹名称",
            showValue: u.getFolderNameDefault(),
            action: "folder.createFolder"
        });
        $(".new-name").focus();
    }
    function b(e) {
        report("renameFolder");
        if (G.selectRow) {
            var t = G.getReportInfo(G.selectRow);
            t.ver3 = 4;
            reportNew("folderRightMenuClick", t);
        }
        n.show(i, {
            title: "重命名",
            tips: "请输入文件夹的新名称",
            action: "folder.renameFolder",
            showValue: G.selectRow.fnameEsc
        });
    }
    function y() {
        n.hide(i);
        if (G.activeElement) {
            G.activeElement.focus();
        }
    }
    function x() {}
    function k() {}
    function k() {
        i.find(".btn-ok").attr("data-action", "folder.createOK");
    }
    function F() {
        if (event && event.keyCode !== 13) {
            m["input.keyup"].call(this, event);
            return;
        }
        var e = $('[data-keyup="folderTree.create"]');
        if (!e.length) {
            callback && callback();
            return;
        }
        var t = e.val();
        var a = m.folderName(t);
        if (!a) {
            return;
        }
        r.createFolder();
    }
    e.exports = {
        "folder.openfolder": p.openByFolder,
        "folder.property": d.show,
        "folder.create": w,
        "folder.panelhide": y,
        "folder.show": x,
        "folder.showmove": k,
        "folder.toDelete": k,
        "folder.createFolder": r.createFolder,
        "folder.deleteFolder": o.deleteFolder,
        "folder.renameFolder": l.renameFolder,
        "folder.showDeleteFolder": o.showDeleteFolder,
        "folder.showRenameFolder": b,
        "folder.open": f.renderFolder,
        "folder.openroot": f.renderRootFolder,
        "folder.download": s.download,
        "folder.downloadByBtn": s.downloadByBtn,
        "input.createFolder": F
    };
}, function(e, t, a) {
    "use strict";
    var i = a(113);
    var n = a(114);
    var r = a(115);
    var o = a(116);
    var l = a(117);
    var s = a(118);
    var d = a(119);
    var f = a(120);
    var c = a(121);
    var u = a(122);
    var p = a(123);
    var v = a(124);
    var m = a(125);
    var h = a(126);
    var g = a(127);
    var w = a(128);
    var b = a(54);
    function y() {
        var e = $(this).parents(".list-item");
        var t = e.data("path");
        var a = undefined;
        var i = e.attr("idx");
        G.nowIdx = parseInt(i);
        var n = b.getData(t);
        if (n.orcType === 2) {
            a = "fold";
        } else if (n.orcType == 1) {
            a = "file";
        }
        G.selectRow = n || {};
        G.selectRow.path = t;
        G.selectRow.type = a;
        G.selectRows = [ G.selectRow ];
    }
    e.exports = {
        "file.batchDelete": v.remove,
        "batch.removeAction": v.removeAction,
        "file.batchMove": v.move,
        "file.batchDownload": v.down,
        "file.batchSaveAs": v.save,
        "file.selectAll": p.selectAll,
        "file.select": p.select,
        "file.check": p.check,
        "file.exitBatch": p.exit,
        "file.upload": n.upload,
        "file.batchUpload": n.bupload,
        "file.openFolder": r.openByPath,
        "file.openFolderInBox": r.openByMenu,
        "file.showRename": o.showFileRename,
        "file.renameFile": o.renameFile,
        "file.saveAs": m.save,
        "file.download": l.download,
        "file.downloadByDom": l.downloadByDom,
        "file.downloadByMenu": l.downloadByMenu,
        "file.downloadByBtn": l.downloadByBtn,
        "file.downloadBatch": l.downloadBatch,
        "file.preview": f.preview,
        "file.menupreview": f.menupreview,
        "file.jubao": u,
        "file.permanent": g,
        "file.delete": d.removeOne,
        "file.deleteBatch": d.removeBatch,
        "file.forward": s.forward,
        "file.forwardMobile": s.toMobile,
        "file.showUpload": n.showUpload,
        "file.showMove": c.showMove,
        "file.move": c.move,
        "upload.noTips": n.noTips,
        "upload.cUpload": n.cupload,
        "file.getByUin": h.byUin,
        "file.getAttr": w,
        "qq.update": n.update,
        "file.aria": y,
        "file.autoClear": i.clickClearFile,
        "file.doClearFile": i.doClearFile
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(129);
    var r = a(78);
    var o = a(130);
    var l = a(54);
    var s = a(15);
    var d = a(59);
    G.renderOtherGroupResultFuncSingtons = {};
    function f() {
        var e = [ '<div class="search-empty"><div class="search-icon-dom">', '<div class="icons-search-empty"></div>', '<span class="empty-desc">很遗憾，', '没有找到与"', G.searchKeyword, '"相关的文件</span></div></div>' ];
        var t = e.join("");
        return t;
    }
    function c(e) {
        var t = $(".other-group-result-desc");
        t.prev().find("dl").css("border-bottom-width", e);
        t.prev().find("div").css("border-bottom-width", e);
    }
    function u() {
        var e = true, t = true;
        var a = {
            dataSelfGroupLen: 0,
            dataOtherGroupLen: 0
        };
        return function(a) {
            var i = G.getDomPanel();
            var n = a.selfGroupResult;
            var r = a.otherGroupResult;
            var l = a.owner;
            var s = a.total - a.owner;
            var d = false;
            var c = false;
            if (l === 0 && s === 0) {
                var u = f();
                i.html(u);
                $(".search-empty").css("height", "100%");
                return;
            }
            console.log(n, r);
            if (n.length > 0) {
                d = o({
                    data: {
                        self: true,
                        first: e,
                        list: n,
                        total: l,
                        name: "本群搜索结果",
                        gc: "0000"
                    },
                    renderParams: {
                        actionHide: false,
                        getByUinHide: false,
                        searchModule: true
                    },
                    batchMode: false
                });
            } else {
                if (e) {
                    d = '<div class="search-no-result">本群没有搜索到相关的文件</div>';
                }
            }
            if (r.length > 0) {
                c = o({
                    data: {
                        self: false,
                        first: t,
                        list: r,
                        total: s,
                        name: "其他群的搜索结果",
                        gc: "1111"
                    },
                    renderParams: {
                        actionHide: false,
                        getByUinHide: false,
                        searchModule: true
                    },
                    batchMode: false
                });
            }
            if (e) {
                report("showSearchRes");
                i.html("");
                e = false;
                $("body").trigger("searchResult", true);
            }
            if (d) {
                i.append(d);
            }
            if (r.length > 0 && t) {
                t = false;
            }
            if (c) {
                i.append(c);
            }
            $("#createFolder").hide();
        };
    }
    function p() {
        var e = false;
        var t = undefined;
        return function(a, r) {
            var o = G.module();
            var c = G.searchKeyword = $.trim($("#inputSearch").val()) || "";
            if (!(a && a.keyCode == 13 || a == undefined) || c === "") {
                return;
            }
            report("doSearch");
            G.module(3);
            var p = true;
            G.scrollHandler(function() {
                var a = G.searchKeyword = $("#inputSearch").val() || "";
                var c = {
                    key_word: a
                };
                e = o !== G.module() || G.module() !== 3 || JSON.stringify(t) != JSON.stringify(c);
                o = G.module();
                t = c;
                var v = function g(t, a) {
                    if (e && !G.isHistory) {
                        G.setHistory(c);
                    }
                    G.isHistory = false;
                    G.nowFolder = false;
                    $("body").attr("data-mode", "search");
                    if (e || G.renderListFuncSingtons[a] == undefined) {
                        G.renderListFuncSingtons[a] = u();
                        G.tab.resetTab();
                    }
                    function i(e) {
                        e = e || [];
                        function t(e) {
                            return e.gc === G.info.gc;
                        }
                        function a(e) {
                            return e.gc !== G.info.gc;
                        }
                        var i = {
                            ut: "upload_time",
                            owner_name: "uin_name"
                        };
                        var n = function r(e) {
                            var t = arguments.length <= 1 || arguments[1] === undefined ? {
                                filters: {
                                    selfGroupFilter: function r() {},
                                    otherGroupFilter: function o() {}
                                }
                            } : arguments[1];
                            function a(e, t, a) {
                                e = e.filter(t);
                                var n = {};
                                for (var r = e.length - 1; r >= 0; r--) {
                                    var o = e[r];
                                    n[o.id] = o;
                                }
                                var d = l.setFileList(e, i);
                                var f = d.file;
                                for (var r = f.length - 1; r >= 0; r--) {
                                    var c = f[r].fp;
                                    var o = G.fileMap()["/" + f[r].busid + c];
                                    var u = n[c].match_word;
                                    f[r].name = s.heightLight(o.name.replace(/&nbsp;/gi, " "), u);
                                    f[r].suf = s.heightLight(o.suf, u);
                                    if (a) {
                                        f[r].otherGroupName = n[c]["group_name"];
                                        f[r].gc = n[c]["gc"];
                                    }
                                }
                                return f;
                            }
                            var n = {
                                selfGroupResult: a(e, t.filters.selfGroupFilter),
                                otherGroupResult: a(e, t.filters.otherGroupFilter, true)
                            };
                            return n;
                        };
                        return n(e, {
                            filters: {
                                selfGroupFilter: t,
                                otherGroupFilter: a
                            }
                        });
                    }
                    var n = i(t.file_list);
                    n.owner = t.owner_total;
                    n.total = t.total;
                    G.renderListFuncSingtons[a](n);
                    r && r();
                    if (p) {
                        $(".scroll-dom")[0].scrollTop = 0;
                        p = false;
                    }
                    d.showLoad(true);
                    console.debug("reset history in search!");
                };
                var m = {
                    succ: function w(e, t) {
                        v(e, t);
                    },
                    fail: function b() {
                        if (e) {
                            var t = "100%";
                            var a = G.getDomPanel();
                            a.html(f());
                            $(".search-empty").css("height", t || "160px");
                        }
                        d.showLoad(true);
                    },
                    beforeRequest: function(e) {
                        return function() {
                            e();
                        };
                    }(d.showLoad),
                    searchParams: c,
                    isNew: e
                };
                if ((typeof nodeData === "undefined" ? "undefined" : i(nodeData)) === "object") {
                    var h = {
                        key_word: nodeData.key_word,
                        search_type: 0,
                        app_id: 4
                    };
                    v(nodeData, h);
                    nodeData = false;
                } else {
                    n.search(m);
                }
            });
            G.scrollHandler();
        };
    }
    e.exports = {
        search: p()
    };
}, function(e, t, a) {
    "use strict";
    var i = a(155);
    var n = a(88);
    var r = a(129);
    var o = a(54);
    var l = a(15);
    var s = a(53);
    var d = a(156);
    var f = $("#fileListDom");
    var c = $("#fileNumText");
    var u = $("#groupSize");
    var p = $("#groupSizeBar");
    var v = a(157);
    var m = $(G.handler);
    var h = location.href;
    var g = undefined;
    g = a(158);
    var w = true;
    var b = undefined;
    G.renderListFuncSingtons = {};
    G.getListFuncSingtons = {};
    G.searchFuncSingtons = {};
    m.bind("file.thumbUpdate", function(e, t) {
        var a = $("#" + t.domid);
        if (a.length && t.previewObj && t.previewObj.url) {
            (function() {
                var e = t.previewObj.url + "&pictype=scaled&size=50*50";
                if (G.checkHttps()) {
                    e = e.replace("http://", "");
                    e = "https://proxy.qun.qq.com/tx_tls_gate=" + e;
                }
                var i = new Image();
                i.onload = function() {
                    a.find(".filesmall-pic").css("background-image", "url(" + e + ")").addClass("thumb");
                };
                i.onerror = function() {
                    console.log("缩略图加载失败!", e);
                };
                i.src = e;
                report("imgurl");
            })();
        }
    });
    m.bind("file.dataUpdate", function(e, t) {
        var a = $("#" + t.domid);
        if (t.remoteType === 1) {
            a.removeClass("temp");
            a.find(".item-tags").hide();
            a.find(".tmp").remove();
        }
        if (t.newFilePath) {
            a.attr("data-path", t.newFilePath);
        }
        a.find(".file-info .name").text(t.fnameEsc);
    });
    var y = function Y() {
        var e = G.module();
        var t = function r(e) {
            return '<section class="file-list" id="' + e + '"></section>';
        };
        var a = function l() {
            var e = o.getData(G.nowFolder);
            var a = e.domid;
            if (!e && G.nowFolder) {
                a = G.nowFolder.replace(/\//g, "-");
            }
            if (a === "-") {
                a = false;
            }
            if (a) {
                var i = $("#list" + a);
                if (i.length > 0) {
                    return i;
                } else {
                    f.after(t("list" + a));
                    i = $("#list" + a);
                    return i;
                }
            } else {
                return $("#fileListDom");
            }
        };
        var i = function s() {
            var e = $("#searchFileDom");
            if (e.length > 0) {
                return e;
            } else {
                f.after(t("searchFileDom"));
                e = $("#searchFileDom");
                return e;
            }
        };
        var n = function d() {
            var e = $("#userFileDom");
            if (e.length > 0) {
                return e;
            } else {
                f.after(t("userFileDom"));
                e = $("#userFileDom");
                return e;
            }
        };
        $(".file-list").hide();
        switch (e) {
          case 0:
            if (e === 0) {
                f.show();
            }
            return f;
            break;

          case 1:
            return a().show();
            break;

          case 3:
            return i().show();
            break;

          case 2:
            return n().show();
            break;
        }
    };
    var x = function X() {
        var e = G.module();
        var t = function r(e) {
            return '<section class="file-list" id="' + e + '"></section>';
        };
        var a = function l() {
            var e = o.getData(G.nowFolder);
            var a = e.domid;
            if (!e && G.nowFolder) {
                a = G.nowFolder.replace(/\//g, "-");
            }
            if (a === "-") {
                a = false;
            }
            if (a) {
                var i = $("#list" + a);
                if (i.length > 0) {
                    return i;
                } else {
                    f.after(t("list" + a));
                    i = $("#list" + a);
                    return i;
                }
            } else {
                return $("#fileListDom");
            }
        };
        var i = function s() {
            var e = $("#searchFileDom");
            if (e.length > 0) {
                return e;
            } else {
                f.after(t("searchFileDom"));
                e = $("#searchFileDom");
                return e;
            }
        };
        var n = function d() {
            var e = $("#userFileDom");
            if (e.length > 0) {
                return e;
            } else {
                f.after(t("userFileDom"));
                e = $("#userFileDom");
                return e;
            }
        };
        switch (e) {
          case 0:
            return f;
            break;

          case 1:
            return a();
            break;

          case 3:
            return i();
            break;

          case 2:
            return n();
            break;
        }
    };
    G.onlyGetDom = x;
    G.getDomPanel = y;
    function k() {
        L();
        c.text(G.file.allnum).attr("aria-label", "共" + G.file.allnum + "个文件");
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        p.css("width", e + "%");
        if (G.file.capacityused) {
            u.text(G.file.capacityused + "/" + G.file.capacitytotal);
        } else {
            u.text("未知/未知");
        }
        if (G.nowFolder === "/") {
            $("#fileNum").removeClass("hide");
        }
        if (G.info.isAdmin) {
            $("#createFolder").show();
        }
    }
    var F = 0;
    function T(e) {
        var t = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
        var a = true;
        return function(e) {
            V(true);
            var i = y();
            if (G.initInFolder) {
                F++;
                $("#fileListDom").hide();
            } else {
                $("body").trigger("newbie");
            }
            if (F === 2) {
                F++;
                G.nowFolder = G.initInFolder;
                var n = G.nowFolder.replace(/\//i, "-");
                $("#list" + n).show();
                G.initInFolder = false;
            }
            if (!e || e.file.length === 0 && e.folder.length === 0) {
                S();
                k();
                a = false;
                return;
            }
            w = false;
            if (G.info.isVisitor) {
                t.actionHide = true;
            }
            var r = g({
                list: e.file,
                renderParams: t
            });
            var o = g({
                list: e.folder,
                renderParams: t
            });
            if (a) {
                k();
                a = false;
                i.html(o);
                i.append(r);
            } else {
                var l = $(".fold").last();
                if (l.length > 0) {
                    l.after(o);
                } else {
                    i.append(o);
                }
                i.append(r);
            }
            i.find(".list-item").each(function(e) {
                this.setAttribute("idx", e);
            });
            if ($(".scroll-dom")[0].scrollHeight > $(".scroll-dom").height()) {
                $(".file-header").addClass("padding");
            } else {
                $(".file-header").removeClass("padding");
            }
            if (!window._timePoints["show"]) {
                savePoint("show");
                var s = {
                    20: window._timePoints["css"],
                    21: window._timePoints["zepto"],
                    22: window._timePoints["js"],
                    23: window._timePoints["start"]
                };
                if (localVersion === "isLocal") {
                    s[25] = window._timePoints["show"];
                } else if (typeof nodeCost !== "undefined") {
                    s[26] = window._timePoints["show"];
                } else {
                    s[24] = window._timePoints["show"];
                }
                QReport.huatuo({
                    appid: 10016,
                    flag1: 1772,
                    flag2: 1,
                    flag3: 1,
                    speedTime: s
                });
            }
        };
    }
    function S() {
        var e = G.getDomPanel();
        if (!e.find(".list-item").length) {
            var t = n();
            e.html(t);
        }
    }
    function _(e) {
        if (G.nowFolder !== "/") {
            return;
        }
        var t = g({
            list: [ e ]
        });
        if (f.find(".icons-empty").length === 0) {
            f.prepend(t);
        } else {
            f.html(t);
        }
    }
    function C(e) {
        if (e) {
            if (e.domid) {
                var t = e.domid;
                $("#" + t).remove();
            } else if (e.id) {
                var t = e.id;
                $("[data-path=" + t + "]").remove();
            }
        }
        setTimeout(S, 500);
    }
    function M(e) {
        var t = G.getDomPanel();
        var a = t.find(".fold").last();
        var i = g({
            list: [ e ]
        });
        if (G.info.version < G.folderVersion) {
            if (e.parentId === "/" && G.nowFolder === "/") {
                if (a.length) {
                    a.after(i);
                } else {
                    t.prepend(i);
                }
            }
        } else {
            if (a.length) {
                a.after(i);
            } else if (G.folder !== "/" && t.find(".icons-empty").length === 0) {
                t.prepend(i);
            } else {
                t.html(i);
            }
        }
        v.renderSpace();
    }
    function D(e) {
        var t = e.parentId;
        if (t === "/") {
            var a = "#fileListDom";
            var i = $(a);
            var n = g({
                list: [ e ]
            });
            $("#" + e.domid).remove();
            if (i.find(".fold").length > 0) {
                i.find(".fold").last().after(n);
            } else {
                i.prepend(n);
            }
        }
    }
    function R(e) {
        if (e) {
            var t = e.domid;
            $("#" + t).remove();
            $("#search" + t).remove();
            l.removeEase($("#" + t));
        }
    }
    function j(e) {
        if (e.orcType === 2) {
            C(e);
        } else {
            R(e);
        }
        var t = G.getDomPanel();
        if (t.find(".list-item").length === 0) {
            console.log("set empty");
            S();
        }
    }
    var I = function K() {
        var e = {
            filterUin: G.info.uin,
            filterCode: 4
        };
        var t = i.getList(e);
        t(function(e) {
            s.firstRender();
        }, function(e) {});
    };
    var N = 0;
    var O = 0;
    var L = function Z() {
        var e = arguments.length <= 0 || arguments[0] === undefined ? -1 : arguments[0];
        N++;
        if (e !== -1) {
            O = e;
        }
        if (N < 2) {
            return;
        }
        if (!G.info.isAdmin && !O) {
            G.info.canCreateFolder = false;
            $("#createFolder").hide();
        } else {
            G.info.canCreateFolder = true;
        }
    };
    function E(e, t) {
        i.setAllSpace(function(t) {
            P();
            L(t.all_upload);
            e && e(t);
        }, t);
    }
    function P() {
        if (G.nowFolder !== "/") {
            return;
        }
        u.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        if (G.file.capacitytotal) {
            $("#ariaSpace").attr("aril-label", "已用容量" + G.file.capacityused + "共" + G.file.capacitytotal);
        } else {
            $("#ariaSpace").attr("aril-label", "已用容量未知G,共未知G");
        }
        var e = parseInt(G.file.cu / G.file.ct * 100);
        p.css("width", e + "%");
        $("#fileNum").removeClass("hide");
    }
    function A(e) {
        var t = e || {};
        var a = t.container || "#folderOrSearchResult";
        var i = t.succ;
        var n = t.searchParams || {};
        var o = JSON.stringify(n);
        if (G.searchFuncSingtons[o] == undefined) {
            G.searchFuncSingtons[o] = r.search(n);
        }
        G.searchFuncSingtons[o](function(e) {
            if (G.renderListFuncSingtons[folderId] == undefined) {
                G.renderListFuncSingtons[folderId] = T(a);
            }
            G.renderListFuncSingtons[folderId](e);
            i && i(e);
        }, function() {});
    }
    var B = function et() {
        var e = false;
        var t = undefined;
        return function(a) {
            var n = a || {};
            var r = n.paramsFilter || {};
            var o = n.container || "#fileListDom";
            var l = n.succ;
            var s = n.fail;
            e = JSON.stringify(t) !== JSON.stringify(r);
            var f = t = r;
            $("body").attr("data-mode", "folder");
            if (G.isHistory) {
                var c = r.folderId;
                var u = "#list" + c.replace("/", "-");
                if (c === "/") {
                    u = "#fileListDom";
                }
                $(".file-list").hide();
                $(u).show();
                d.updataFolderHeader(a.paramsFilter.folder);
                l && l();
                return function() {};
            }
            if (G.nowFolder !== "/") {
                $("body").addClass("folder-module");
            } else {
                $("body").removeClass("folder-module");
            }
            return G.scrollHandler(function() {
                if (e || G.getListFuncSingtons[f] == undefined) {
                    G.getListFuncSingtons[f] = i.getList(r);
                }
                G.getListFuncSingtons[f](function(t) {
                    if (e || G.renderListFuncSingtons[f] == undefined) {
                        e = false;
                        G.renderListFuncSingtons[f] = T(o, n.renderParams);
                    }
                    if (r.filterCode === 3) {
                        var a = t.file;
                        for (var i = a.length - 1; i >= 0; i--) {
                            var s = a[i];
                            if (s.parentId && G.folderMap()[s.parentId]) {
                                t.file[i].folderName = G.folderMap()[s.parentId].fnameEsc;
                            }
                        }
                    }
                    G.renderListFuncSingtons[f](t);
                    V(true);
                    l && l(t);
                }, function(e) {
                    V(true);
                    e && console.log(e);
                    if (e.ec !== 1e3) {
                        var t = "拉取文件列表失败";
                        if (w) {
                            if (G.mac) {
                                t += "，请稍后重试";
                            } else {
                                t += '，请稍后<a onclick="window.location.reload();">重试</a>';
                            }
                        }
                        m.trigger("toast.show", {
                            type: "fail",
                            text: t,
                            autoHide: !w
                        });
                    }
                    if (e && e.fc && e.fc === 1) {
                        return;
                    }
                }, function(e) {
                    return function() {
                        e();
                    };
                }(V));
            });
        };
    }();
    var q = function tt() {
        var e = {};
        var t = {};
        var a = "#fileListDom";
        i.getList(t)();
    };
    function z(e) {
        B(e)();
        I();
        if (!G.file || !G.file.ct) {
            E();
        }
    }
    function U(e) {
        var t = function r(t) {
            if (t.length === 0) {
                return;
            }
            var a = t.find(".file-aria-btn");
            if (a.length > 0) {
                if (e.status === "downloadcomplete") {
                    a.attr("aria-label", "打开文件" + e.name + e.suf).attr("data-action", "file.openFolder");
                } else if (e.status === "downloadprogress") {
                    a.attr("aria-label", "文件" + e.name + e.suf + "下载中").removeAttr("data-action");
                } else if (e.status === "downloadready") {
                    a.attr("aria-label", "准备下载文件" + e.name + e.suf).removeAttr("data-action");
                }
            }
            if (t.find(".file-status").length > 0) {
                t.find(".width").css("width", e.cPercent + "%");
                if (e.cPercent >= 100 || e.status === "remove") {
                    t.find(".item-time .drag-dom").show();
                    t.find(".item-time .file-status").hide();
                } else {
                    t.find(".item-time .drag-dom").hide();
                    t.find(".item-time .file-status").show();
                }
            } else {
                var i = "正在打开";
                if (G.saveasList[e.filepath]) {
                    i = "正在下载";
                }
                var n = [ '<div class="file-download file-status">', "" + i, '<div class="file-parents">', '<div class="width" style="width:' + e.cPercent + '%"></div>', "</div>", '<div class="miss-close" onclick="G.removeTaskInDownLoad(' + e.taskId + ",'" + e.filepath + "')\"></div>", "</div>" ];
                t.find(".item-time .drag-dom").hide();
                t.find(".item-time").append(n.join(""));
            }
        };
        if (e.orcType === 1) {
            var a = e.filepath.replace(/\//gi, "-");
            var i = $("#" + a);
            var n = $("#search" + a);
            t(i);
            t(n);
        }
    }
    function H(e, t) {
        var a = e.domid;
        if (!a) {
            a = o.getId(e.oldfilepath);
        }
        var i = $("#" + a);
        var n = undefined;
        i.find(".item-time .drag-dom").hide();
        n = '<div class="file-status">正在更新中</div>';
        i.find(".item-time").append(n);
        i.find(".file-icons").addClass("editing");
    }
    function J(e) {
        var t = o.getData(e.oldfilepath);
        var a = $("#" + t.domid);
        if (a) {
            a.attr("id", e.domid);
            a.attr("data-path", e.filepath);
            a.find(".item-time .drag-dom").attr("title", "更新时间：" + e.mtoStr).show();
            a.find(".item-time .drag-dom span").text(e.mtStr);
            a.find(".file-icons").removeClass("editing");
            a.find(".item-time .file-status").hide();
            if (!e.preview) {
                a.attr("data-dbaction", "file.downloadByDom");
            }
        }
        delete G.editFileList[t.filepath];
        o.remove(e.oldfilepath);
    }
    function Q(e, t) {
        var a = undefined;
        if (e.orcType === 1) {
            a = $('.list-item[data-path="' + e.filepath + '"]');
            if (t === "rename") {
                a.find(".item-name-wrap").attr("title", "" + e.nameEsc + e.suf + "\n创建时间：" + e.ctoStr);
                a.find(".item-name .name").text(e.nameEsc + e.suf);
            }
            a.find(".item-time").attr("title", "更新时间：" + e.mtoStr);
            a.find(".item-time span").text(e.mtStr);
            a.find(".item-download-times").text(e.down + "次");
        } else {
            a = $("#" + e.domid);
            if (e.toFirst) {
                a.remove();
                _(e);
                return;
            } else {
                a = $("#" + e.domid);
                if (e.filenum) {
                    a.find(".file-size").text(e.filenum + "个文件").attr("title", e.filenum + "个文件");
                }
            }
            a.find(".item-name").attr("title", e.fnameEsc + "\n文件个数：" + e.filenum + "\n创建时间：" + e.ctoStr + "\n创建人：" + e.nick);
            a.find(".item-time").attr("title", "更新时间：" + e.mtoStr);
            a.find(".item-time span").text(e.mtStr);
        }
        console.debug("update row", e);
        if (e.status === "uploadcomplete" || e.status === "downloadcomplete") {
            a.addClass("succ");
            var i = "打开";
            if (G.mac) {
                i = "";
            }
            a.find(".file-status").attr("tabindex", "3").attr("aria-label", "打开文件" + e.nameEsc + e.suf).attr("data-actioin", "file.openFolder");
        } else if (!e.isDown && !e.isDowning) {
            if (e.orcType === 1) {
                var i = "下载";
                if (G.mac) {
                    i = "";
                }
                a.find(".file-status").attr("tabindex", "3").attr("aria-label", "下载文件" + e.nameEsc + e.suf).attr("data-action", "file.download");
            }
            a.removeClass("succ");
        } else if (e.isDowning) {
            a.find(".file-status").attr("tabindex", "3").attr("aria-label", "文件" + e.nameEsc + e.suf + "下载中").removeAttr("data-actioin");
        }
    }
    function V(e) {
        if (!b) {
            $("body").append('<div class="loader" id="loaderDom"><div class="loading"></div></div>');
            b = $("#loaderDom");
        }
        if (e) {
            b.removeClass("open");
        } else {
            b.addClass("open");
        }
    }
    function W(e) {
        if (!e || e.status !== "downloadgeturl" && e.status !== "downloadprogress" && e.status !== "downloadcomplete") {
            return;
        }
        var t = o.getData(e.filepath);
        if (e.status === "downloadcomplete") {
            return t.hasCountDownloadTime = false;
        }
        if (!t.hasCountDownloadTime && (e.status === "downloadgeturl" || e.status === "downloadprogress")) {
            if (G.pList.some(function(e) {
                return e.filepath === t.filepath;
            })) {
                return;
            }
            t.hasCountDownloadTime = true;
            t.down++;
            var a = $('.list-item[data-path="' + t.filepath + '"]');
            a.find(".item-download-times").attr("title", "下载次数：" + t.down + "次");
            a.find(".item-download-times span").text(t.down + "次");
        }
    }
    e.exports = {
        init: z,
        appendFold: _,
        removeFold: C,
        appendFile: M,
        appendFileToFolder: D,
        updateRow: Q,
        search: A,
        renderSpace: P,
        removeRow: j,
        getList: B,
        getRoot: q,
        renderList: T,
        showLoad: V,
        updateDownloadRow: U,
        updateEditFileRow: J,
        fileInEditRow: H,
        getDomPanel: y,
        updateDownloadTimes: W
    };
}, function(e, t, a) {
    "use strict";
    var i = a(78);
    var n = a(54);
    var r = {};
    e.exports = r;
    r.getFileCount = function(e, t) {
        i.getFileCount().done(function(t) {
            n.setFileCount(t);
            e(t);
        }).fail(function(e) {
            console.log(e);
        });
    };
}, , , , , , , , , , , , , , , , , function(e, t, a) {
    (function(e) {
        "use strict";
        var t = a(15);
        var i = a(160);
        var n = {
            enter: {
                monitor: 2057388,
                mac: 2162523,
                tdw: [ "home", "exp" ]
            },
            clkGroupFile: {
                monitor: 2057389,
                tdw: [ "home", "Clk_grpfiles" ]
            },
            clkFiles: {
                monitor: 2057390,
                tdw: [ "home", "Clk_files" ]
            },
            openVip: {
                monitor: 2057391,
                tdw: [ "home", "Clk_open" ]
            },
            clkFeed: {
                monitor: 2057392,
                tdw: [ "home", "Clk_feed" ]
            },
            clkRefresh: {
                monitor: 2057393,
                tdw: [ "home", "Clk_refresh" ]
            },
            forward: {
                monitor: 0,
                tdw: [ "home", "Clk_towards_mac" ]
            },
            back: {
                monitor: 0,
                tdw: [ "home", "Clk_back" ]
            },
            folder: {
                monitor: 2057394,
                tdw: [ "file", "exp" ]
            },
            propFolder: {
                monitor: 2057401,
                tdw: [ "file", "Clk_property" ]
            },
            folderBtnShow: {
                monitor: 2057396,
                tdw: [ "file", "exp_create" ]
            },
            clkCreateFolder: {
                monitor: 2057397,
                tdw: [ "file", "Clk_create" ]
            },
            createFolderSuc: {
                monitor: 2057398,
                tdw: [ "file", "create_suc" ]
            },
            renameFolder: {
                monitor: 2057400,
                tdw: [ "file", "Clk_rename" ]
            },
            clkFolderMore: {
                monitor: 2057399,
                tdw: [ "file", "Clk_more" ]
            },
            downloadFolder: {
                monitor: 2057399,
                tdw: [ "file", "Clk_down" ]
            },
            deleteFolder: {
                monitor: 2057402,
                tdw: [ "file", "Clk_delete" ]
            },
            returnHome: {
                monitor: 2057395,
                tdw: [ "file", "Clk_home" ]
            },
            folderTree: {
                monitor: 2057403,
                tdw: [ "file", "exp_select" ]
            },
            createFolderInTree: {
                monitor: 2057404,
                tdw: [ "file", "select_create" ]
            },
            createFolderInTreeSuc: {
                monitor: 2057405,
                tdw: [ "file", "select_suc" ]
            },
            memberFileShow: {
                monitor: 2057406,
                tdw: [ "mber_file", "exp" ]
            },
            memberClkFolder: {
                monitor: 2057407,
                tdw: [ "mber_file", "Clk_name" ]
            },
            memberReturnHome: {
                monitor: 2057408,
                tdw: [ "mber_file", "Clk_home" ]
            },
            uploadShow: {
                monitor: 2057409,
                tdw: [ "oper_file", "exp_button" ]
            },
            clkUpload: {
                monitor: 2057410,
                tdw: [ "oper_file", "Clk_button" ]
            },
            clkFolder: {
                monitor: 2057411,
                tdw: [ "oper_file", "Clk_category" ]
            },
            showOpenFile: {
                monitor: 2057412,
                tdw: [ "oper_file", "exp_open" ]
            },
            clkOpenFile: {
                monitor: 2057413,
                tdw: [ "oper_file", "Clk_open" ]
            },
            showDownloadBtn: {
                monitor: 2057414,
                tdw: [ "oper_file", "exp_download" ]
            },
            clkDownloadBtn: {
                monitor: 2057415,
                tdw: [ "oper_file", "Clk_download" ]
            },
            showSeeBtn: {
                monitor: 2057416,
                tdw: [ "oper_file", "exp_see" ]
            },
            clkShowBtn: {
                monitor: 2057417,
                tdw: [ "oper_file", "Clk_see" ]
            },
            clkMore: {
                monitor: 2057418,
                tdw: [ "oper_file", "Clk_more" ]
            },
            clkUnMore: {
                monitor: 2057419,
                tdw: [ "oper_file", "Clk_un_more" ]
            },
            clkSaveAs: {
                monitor: 2057420,
                tdw: [ "oper_file", "Clk_save" ]
            },
            clkRepost: {
                monitor: 2057421,
                tdw: [ "oper_file", "Clk_repost" ]
            },
            clkPhone: {
                monitor: 2057422,
                tdw: [ "oper_file", "Clk_phone" ]
            },
            clkRenameFile: {
                monitor: 2057423,
                tdw: [ "oper_file", "Clk_rename" ]
            },
            clkForever: {
                monitor: 2057424,
                tdw: [ "oper_file", "Clk_forever" ]
            },
            clkJubao: {
                monitor: 2057425,
                tdw: [ "oper_file", "Clk_report" ]
            },
            clkDeleteFile: {
                monitor: 2057426,
                tdw: [ "oper_file", "Clk_delete" ]
            },
            clkShowInFolder: {
                monitor: 2057427,
                tdw: [ "oper_file", "Clk_show" ]
            },
            showSelectAll: {
                monitor: 2057428,
                tdw: [ "all_oper", "exp_box" ]
            },
            clkSelectAll: {
                monitor: 2057429,
                tdw: [ "all_oper", "Clk_select" ]
            },
            showBatch: {
                monitor: 2057430,
                tdw: [ "all_oper", "exp_mode" ]
            },
            clkBatch: {
                monitor: 2057431,
                tdw: [ "all_oper", "Clk_all" ]
            },
            batchSaveAs: {
                monitor: 2057432,
                tdw: [ "all_oper", "Clk_save" ]
            },
            batchDownload: {
                monitor: 2057433,
                tdw: [ "all_oper", "Clk_download" ]
            },
            batchDelete: {
                monitor: 2057434,
                tdw: [ "all_oper", "Clk_delete" ]
            },
            batchDeleteSuc: {
                monitor: 2057435,
                tdw: [ "all_oper", "suc_delete" ]
            },
            batchMove: {
                monitor: 2057436,
                tdw: [ "all_oper", "Clk_move" ]
            },
            batchMoveSuc: {
                monitor: 2057437,
                tdw: [ "all_oper", "suc_move" ]
            },
            showTask: {
                monitor: 2057438,
                tdw: [ "task", "exp" ]
            },
            clkTask: {
                monitor: 2057439,
                tdw: [ "task", "Clk_task" ]
            },
            showOneTask: {
                monitor: 2057440,
                tdw: [ "task", "exp_category" ]
            },
            clkTaskName: {
                monitor: 2057441,
                tdw: [ "task", "Clk_name" ]
            },
            showTaskShow: {
                monitor: 2057442,
                tdw: [ "task", "exp_see" ]
            },
            clkTaskShow: {
                monitor: 2057443,
                tdw: [ "task", "Clk_see" ]
            },
            showTaskPause: {
                monitor: 2057444,
                tdw: [ "task", "exp_start" ]
            },
            clkTaskPause: {
                monitor: 2057445,
                tdw: [ "task", "Clk_stop" ]
            },
            showTaskDelete: {
                monitor: 2057446,
                tdw: [ "task", "exp_delete" ]
            },
            clkTaskDelete: {
                monitor: 2057447,
                tdw: [ "task", "Clk_delete" ]
            },
            taskExp: {
                monitor: 2057448,
                tdw: [ "task", "exp_tips" ]
            },
            clkTaskExp: {
                monitor: 2057449,
                tdw: [ "task", "Clk_tips" ]
            },
            showSearchBtn: {
                monitor: 2057450,
                tdw: [ "search", "exp_button" ]
            },
            clkSearchBtn: {
                monitor: 2057451,
                tdw: [ "search", "Clk_button" ]
            },
            doSearch: {
                monitor: 2057452,
                tdw: [ "search", "Clk_search" ]
            },
            showSearchRes: {
                monitor: 2057453,
                tdw: [ "search", "exp_result" ]
            },
            clkSearchRes: {
                monitor: 2057454,
                tdw: [ "search", "Clk_result" ]
            },
            clkSearchName: {
                monitor: 2057455,
                tdw: [ "search", "Clk_name" ]
            },
            showFolderMove: {
                monitor: 2057456,
                tdw: [ "oper_file", "exp_move" ]
            },
            clkFolderMove: {
                monitor: 2057457,
                tdw: [ "oper_file", "Clk_move" ]
            },
            moveFileSuc: {
                monitor: 2057458,
                tdw: [ "oper_file", "move_suc" ]
            },
            showOldVersion: {
                monitor: 2057459,
                tdw: [ "oper_file", "exp_upgradetips" ]
            },
            clkUpdateQQ: {
                monitor: 2057460,
                tdw: [ "oper_file", "Clk_upgrade" ]
            },
            clkNotRemind: {
                monitor: 2057461,
                tdw: [ "oper_file", "Clk_nomoreremind" ]
            },
            showMoveFail: {
                monitor: 2057462,
                tdw: [ "oper_file", "exp_movefail" ]
            },
            delFolderSuc: {
                monitor: 2057463,
                tdw: [ "oper_file", "delete_suc" ]
            },
            jsError: {
                monitor: 2069233
            },
            getListError: {
                monitor: 2069234
            },
            delFileError: {
                monitor: 2069235
            },
            moveFileError: {
                monitor: 2069236
            },
            renameFileError: {
                monitor: 2069237
            },
            newFolderError: {
                monitor: 2069238
            },
            renameFolderError: {
                monitor: 2069239
            },
            delFolderError: {
                monitor: 2069240
            },
            cgiTimeout: {
                monitor: 2069241
            },
            offlinePage: {
                monitor: 2069242
            },
            nodePage: {
                monitor: 2069243
            },
            folderNum: {
                tdw: [ "file", "exp_folder" ]
            },
            imgurl: {
                monitor: 2200307
            },
            expnew: {
                monitor: 2227445
            },
            newFileShow: {
                tdw: [ "file_single", "exp" ],
                monitor: 2227391
            },
            doubleClickFile: {
                tdw: [ "file_single", "Clk_open" ],
                monitor: 2227392
            },
            fileRightMenuShow: {
                tdw: [ "file_single", "exp_right" ],
                monitor: 2227393
            },
            fileRightMenuClick: {
                tdw: [ "file_single", "Clk_option" ],
                monitor: 2227394
            },
            folderShow: {
                tdw: [ "file_pack", "exp" ],
                monitor: 2227395
            },
            doubleClickFolder: {
                tdw: [ "file_pack", "Clk_open" ],
                monitor: 2227396
            },
            folderRightMenuShow: {
                tdw: [ "file_pack", "exp_right" ],
                monitor: 2227397
            },
            folderRightMenuClick: {
                tdw: [ "file_pack", "Clk_option" ],
                monitor: 2227398
            },
            blankRightMenuShow: {
                tdw: [ "blank", "exp_right" ],
                monitor: 2227399
            },
            blankRightMenuClick: {
                tdw: [ "blank", "Clk_option" ],
                monitor: 2227400
            },
            chooseRightMenuShow: {
                tdw: [ "choose", "exp_right" ],
                monitor: 2227401
            },
            chooseRightMenuClick: {
                tdw: [ "choose", "Clk_option" ],
                monitor: 2227402
            },
            chooseDrag: {
                tdw: [ "choose", "Clk_drag" ],
                monitor: 2227403
            },
            chooseDragSinge: {
                tdw: [ "drag", "Clk_drag" ],
                monitor: 2227404
            },
            wayNext: {
                tdw: [ "way", "next" ],
                monitor: 2227405
            },
            wayPrev: {
                tdw: [ "way", "previous" ],
                monitor: 2227406
            },
            wayRoot: {
                tdw: [ "way", "Clk_root" ],
                monitor: 2227407
            },
            fileDownload: {
                monitor: 2366515,
                tdw: [ "oper_file", "down_in" ]
            },
            blackExp: {
                monitor: 2370085,
                tdw: [ "black", "exp_foul" ]
            },
            blackTips: {
                monitor: 2370086,
                tdw: [ "black", "exp_tip" ]
            },
            blackDelete: {
                monitor: 2370087,
                tdw: [ "black", "delete" ]
            },
            adjustTab: {
                tdw: [ "home", "oper_title" ],
                monitor: 2374983
            },
            guideExp: {
                tdw: [ "new_guide", "exp" ],
                monitor: 2387418
            },
            guideRemove: {
                tdw: [ "new_guide", "remove" ],
                monitor: 2387419
            },
            limitOver: {
                tdw: [ "multi", "limit_over" ]
            },
            limitTip: {
                tdw: [ "multi", "limit_tip" ]
            },
            showLimit: {
                tdw: [ "multi", "show_limit" ]
            },
            cleanEntry: {
                tdw: [ "multi", "clean_entry" ]
            },
            clickClean: {
                tdw: [ "multi", "clear_but" ]
            },
            changeHand: {
                tdw: [ "multi", "grp_hand" ]
            }
        };
        var r = "Grp_pcfiles";
        window.badjsReport = i.createReport({
            id: 1033
        });
        function o() {
            var e = window.webkitPerformance ? window.webkitPerformance : window.performance, t = [ "navigationStart", "unloadEventStart", "unloadEventEnd", "redirectStart", "redirectEnd", "fetchStart", "domainLookupStart", "domainLookupEnd", "connectStart", "connectEnd", "requestStart", "responseStart", "responseEnd", "domLoading", "domInteractive", "domContentLoadedEventStart", "domContentLoadedEventEnd", "domComplete", "loadEventStart", "loadEventEnd" ], a, i, n;
            if (e && (a = e.timing)) {
                if (!a.domContentLoadedEventStart) {
                    t.splice(15, 2, "domContentLoadedStart", "domContentLoadedEnd");
                }
                var r = [];
                for (n = 0, i = t.length; n < i; n++) {
                    r[n] = a[t[n]];
                }
                QReport.huatuo({
                    appid: 10016,
                    flag1: 1772,
                    flag2: 1,
                    flag3: 1,
                    speedTime: r
                });
            }
        }
        function l() {
            var e = /\/\/(s[\d]*\.url\.cn|[\w\.\d]*\.qq.com|report\.url\.cn)/i;
            if (window.performance && window.performance.getEntries()) {
                var t = window.performance.getEntries();
                for (var a = 0, i = t.length; a < i; a++) {
                    var n = t[a].name;
                    if (!e.test(n)) {
                        QReport.monitor(2154095);
                        badjsReport.info(JSON.stringify({
                            "被劫持": n
                        }));
                    }
                }
            }
        }
        window.addEventListener("load", function() {
            o();
            l();
        });
        window.addEventListener("error", function() {
            report("jsError");
        });
        var s = t.getParameter("gid");
        window.reportNew = function(t) {
            var a = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
            if (n[t]) {
                var i = n[t];
                if (i.monitor) {
                    QReport.monitor(i.monitor);
                }
                if (i.mac) {
                    QReport.monitor(i.mac);
                }
                if (G.module) {
                    e = G.module();
                }
                if (i.tdw) {
                    var o = {
                        obj1: s,
                        opername: r,
                        module: i.tdw[0],
                        action: i.tdw[1]
                    };
                    if (G.mac) {
                        o.action = i.tdw[1] + "_mac";
                    }
                    o = $.extend(o, a);
                    QReport.tdw(o);
                }
            }
        };
        window.report = function(t) {
            var a = arguments.length <= 1 || arguments[1] === undefined ? -1 : arguments[1];
            var i = arguments.length <= 2 || arguments[2] === undefined ? 0 : arguments[2];
            var o = arguments.length <= 3 || arguments[3] === undefined ? 0 : arguments[3];
            var l = arguments.length <= 4 || arguments[4] === undefined ? 0 : arguments[4];
            var d = arguments.length <= 5 || arguments[5] === undefined ? 0 : arguments[5];
            var f = arguments.length <= 6 || arguments[6] === undefined ? 0 : arguments[6];
            var c = arguments.length <= 7 || arguments[7] === undefined ? 0 : arguments[7];
            if (n[t]) {
                var u = n[t];
                if (u.monitor) {
                    QReport.monitor(u.monitor);
                }
                if (u.mac) {
                    QReport.monitor(u.mac);
                }
                if (G.module) {
                    e = G.module();
                }
                if (u.tdw) {
                    var p = {
                        obj1: s,
                        opername: r,
                        module: u.tdw[0],
                        action: u.tdw[1]
                    };
                    if (G.mac) {
                        p.action = u.tdw[1] + "_mac";
                    }
                    if (a >= 0) {
                        p.ver1 = a;
                    }
                    if (i) {
                        p.ver2 = i;
                    }
                    QReport.tdw(p);
                }
            }
        };
    }).call(t, a(165)(e));
}, function(e, t, a) {
    "use strict";
    var i = a(144);
    var n = {};
    e.exports = n;
    var r = "//pan.qun.qq.com/cgi-bin/group_file/";
    var o = {
        checkVip: "//pan.qun.qq.com/cgi-bin/get_vip_id",
        checkOneFile: "//pan.qun.qq.com/cgi-bin/checkAuditFlag",
        rename: "//pan.qun.qq.com/cgi-bin/rename",
        list: "//pan.qun.qq.com/cgi-bin/filelist",
        path: "//pan.qun.qq.com/cgi-bin/thumbnail",
        del: "//pan.qun.qq.com/cgi-bin/del_bat",
        permanent: "//pan.qun.qq.com/cgi-bin/permanent"
    };
    var l = {
        getFileList: r + "get_file_list",
        renameFolder: r + "rename_folder",
        getFileInfo: r + "get_file_info",
        createFolder: r + "create_folder",
        deleteFolder: r + "delete_folder",
        renameFile: r + "rename_file",
        deleteFile: r + "delete_file",
        moveFile: r + "move_file",
        fileSearch: r + "search_file",
        getSpace: r + "get_group_space",
        getUserFlag: r + "get_user_flag",
        setUserFlag: r + "set_user_flag",
        previewFile: "//pan.qun.qq.com/cgi-bin/thumbnail",
        permanent: r + "permanent",
        checkOneFile: "//pan.qun.qq.com/cgi-bin/checkAuditFlag",
        getFileAttr: r + "get_file_attr",
        checkVip: "//pan.qun.qq.com/cgi-bin/get_vip_info",
        checkWhite: r + "white_list",
        getFileCount: r + "get_file_count",
        cleanFile: r + "clean_file"
    };
    n.getEditFlag = function() {
        var e = {
            bus_id: 3
        };
        return i.ajax({
            url: l.checkWhite,
            type: "GET",
            data: e
        });
    };
    n.setPermanent = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.permanent,
            type: "POST",
            data: e
        });
    };
    n.getFileList = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.getFileList,
            type: "GET",
            data: e
        });
    };
    n.deleteFile = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        if (e.bus_id) {
            e.file_list = JSON.stringify({
                file_list: [ {
                    gc: G.info.gc,
                    app_id: G.appid,
                    bus_id: e.bus_id,
                    file_id: e.file_id,
                    parent_folder_id: e.parent_folder_id
                } ]
            });
        }
        return i.ajax({
            url: l.deleteFile,
            type: "POST",
            data: e
        });
    };
    n.renameFile = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.renameFile,
            type: "POST",
            data: e
        });
    };
    n.moveFile = function(e) {
        var t = {};
        t.file_list = JSON.stringify({
            file_list: e
        });
        if (!t.gc) {
            t.gc = G.info.gc;
        }
        return i.ajax({
            url: l.moveFile,
            type: "POST",
            data: t
        });
    };
    n.createFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.createFolder,
            type: "POST",
            data: e
        });
    };
    n.deleteFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.createFolder,
            type: "POST",
            data: e
        });
    };
    n.renameFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.renameFolder,
            type: "POST",
            data: e
        });
    };
    n.deleteFolder = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.deleteFolder,
            type: "POST",
            data: e
        });
    };
    n.getPreview = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.previewFile,
            type: "POST",
            data: e
        });
    };
    n.checkOneFile = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.checkOneFile + "?_=" + new Date().getTime(),
            type: "POST",
            data: e
        });
    };
    n.search = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.fileSearch,
            type: "GET",
            data: e
        });
    };
    n.getSpace = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.getSpace,
            type: "GET",
            data: e
        });
    };
    n.getFileAttr = function(e) {
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.getFileAttr,
            type: "GET",
            data: e
        });
    };
    n.checkVip = function() {
        var e = {
            gc: G.info.gc
        };
        return i.ajax({
            type: "GET",
            data: e,
            url: l.checkVip + "?_=" + new Date().getTime()
        });
    };
    n.getUserFlag = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.getUserFlag,
            type: "GET",
            data: e
        });
    };
    n.setUserFlag = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.setUserFlag,
            type: "POST",
            data: e
        });
    };
    n.getFileCount = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        if (!e.bus_id) {
            e.bus_id = 0;
        }
        return i.ajax({
            url: l.getFileCount,
            type: "GET",
            data: e
        });
    };
    n.cleanFile = function(e) {
        e = e || {};
        if (!e.gc) {
            e.gc = G.info.gc;
        }
        return i.ajax({
            url: l.cleanFile,
            type: "POST",
            data: e
        });
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#qqVip");
    var n = $("#openVip");
    function r() {
        if (G.flagIsVip) {
            i.html('<i class="icons-vip"></i>极速下载特权</a>').addClass("is-vip");
        }
    }
    function o() {
        if (G.flagIsVip) {
            n.find(".tips-msg").text("尊贵的QQ超级会员，您已获得群文件极速下载特权，快去下载文件体验吧！");
            n.find(".btn-ok").remove();
        }
        n.addClass("open");
        n.find(".btn-ok").focus();
    }
    e.exports = {
        showQQVip: r,
        show: o
    };
}, function(e, t, a) {
    "use strict";
    var i = a(15);
    var n = a(78);
    var r = window.localStorage;
    var o = "newbie" + i.getUin();
    var l = function u() {
        var e = $("#fileListDom");
        var t = e.find(".file").eq(0);
        console.log("getfileidx", G.nowFolder);
        if (t.length > 0 && G.nowFolder === "/") {
            var a = t[0].offsetTop;
            var i = $(".scroll-dom").height();
            var n = t.height();
            if (a < i) {
                var r = (Number(t.attr("idx")) || 0) + 1;
                if (a + 76 > i) {
                    return {
                        t: a - 76,
                        u: 0,
                        idx: r
                    };
                } else {
                    return {
                        t: a + n,
                        u: 1,
                        idx: r
                    };
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    };
    var s = function p() {
        try {
            r.setItem(o, 1);
        } catch (e) {
            r.clear();
            r.setItem(o, 1);
        }
        n.setUserFlag({
            position: 0
        }).done(function(e) {}).fail(function(e) {});
    };
    var d = function v() {
        $("#newBie").bind("click", function() {
            $("#newBie").hide();
            s();
            reportNew("guideRemove");
        });
    };
    var f = function m() {
        if (G.nowFolder === "/") {
            var e = l();
            if (e) {
                $("#newBie").show();
                $("#newBieTips").css("top", e.t + 78 + "px");
                if (!e.u) {
                    $("#newBieTips").addClass("bottom");
                }
                d();
                reportNew("guideExp", {
                    ver1: e.idx
                });
            } else {
                $("#newBie").hide();
            }
        } else {
            $("#newBie").hide();
        }
    };
    var c = function h() {
        $("#newBie").remove();
    };
    $("body").bind("newbie", function(e) {
        var t = undefined;
        try {
            t = r.getItem(o);
        } catch (e) {
            console.info(e);
        }
        n.getUserFlag({
            position: 0
        }).done(function(e) {
            if (e.ec !== 0) {
                if (t) {
                    c();
                } else {
                    f();
                }
                return;
            }
            if (e.flag === 1) {
                c();
            }
            if (e.flag === 0 && t) {
                c();
                s();
            }
            if (e.flag === 0 && !t) {
                f();
            }
        }).fail(function(e) {
            if (t) {
                c();
                s();
            } else {
                f();
            }
        });
    });
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.init = nt;
    t.listClick = rt;
    var i = a(123);
    var n = a(54);
    var r = a(152);
    var o = a(121);
    var l = $("#customMenu");
    var s = $(".scroll-dom");
    var d = $("#headerNormal").height() + $(".file-header").height();
    var f = 500;
    var c = {};
    var u = 0;
    var p = 46;
    var v = "dragDiv";
    var m = "w";
    var h = 0;
    var g = 0;
    var w = 0, b = 0;
    var y = 0;
    var x = false;
    var k = false;
    var F = false;
    var T = 0;
    var S = 0;
    var _ = "0px", C = "0px", M = "0px", D = "0px";
    var R = false;
    var j = undefined;
    var I = undefined;
    var N = undefined;
    var O = undefined;
    var L = 0;
    var E = 0;
    var P = 0;
    var A = 0;
    var B = document.body.clientWidth;
    var q = document.body.clientHeight;
    var z = function ot() {
        var e = G.onlyGetDom().find(".selected");
        var t = e.length;
        var a = [];
        var i = false;
        G.selectRows = [];
        for (var r = 0; r < t; r++) {
            var o = e[r];
            if (o.classList.contains("fold")) {
                i = o;
            } else {
                var l = o.getAttribute("data-path");
                var s = n.getData(l);
                if (s) {
                    G.selectRows.push(s);
                    a.push(s);
                }
            }
        }
        return {
            list: a,
            fold: i
        };
    };
    var U = function lt() {
        l.addClass("hide");
    };
    var H = function st(e) {
        x = false;
        if ($(".selected").length === 0) {
            return;
        }
        k = true;
    };
    var J = function dt(e) {
        k = false;
        var t = function f() {
            $(".hover").removeClass("hover");
            $(".selected").removeClass("selected");
            Y();
        };
        if ($("#dragItem .status").hasClass("disable")) {
            t();
            return;
        }
        var a = e.clientY;
        var i = z();
        var r = i.list;
        var l = $(e.target);
        if (!l.hasClass("fold")) {
            l = l.parents(".fold");
        }
        var s = l.data("path");
        var d = n.getData(s);
        if (d) {
            o.movelist(r, s, true);
        }
        F = false;
        t();
    };
    var Q = function ft(e) {
        var t = $(e.target);
        var a = e.clientX;
        var o = e.clientY;
        if (!t.hasClass("list-item")) {
            t = t.parents(".list-item");
        }
        var s = z();
        var d = s.list;
        var f = {};
        var c = undefined;
        var u = function g(e) {
            var a = false;
            if (t.hasClass("file") || t.hasClass("fold")) {
                a = true;
                return a;
            }
            var i = t.data("path");
            if (!e) {
                a = false;
            } else if (e && e.filepath === i) {
                a = true;
            } else {
                a = false;
            }
            return a;
        };
        if (d.length > 1 && t.hasClass("selected")) {
            r.renderCustomMenu(l, d);
            c = "chooseMenuShow";
            f.ver1 = t.length > 0 ? 1 : 2;
            f.ver2 = G.info.isAdmin ? 1 : 2;
            f.ver3 = G.module() === 1 ? 0 : 1;
        } else {
            $(".selected").removeClass("selected");
            k = false;
            if (u(d[0])) {
                t.addClass("selected");
                var p = t.data("path");
                var v = n.getData(p);
                G.selectRow = v;
                G.selectRows = [ v ];
                f = G.getReportInfo(v);
                if (v.orcType === 2) {
                    c = "folderRightMenuShow";
                } else {
                    c = "fileRightMenuShow";
                }
                if ($(e.target).parents(".group1111").length > 0) {
                    v.othergroup = true;
                }
                if (at()) {
                    v.issearch = true;
                }
                r.renderCustomMenu(l, v);
            } else {
                c = "blankRightMenuShow";
                f.ver1 = t.length > 0 ? 1 : 2;
                f.ver2 = G.info.isAdmin ? 1 : 2;
                f.ver3 = G.module() === 1 ? 0 : 1;
                r.renderCustomMenu(l);
                i.changeDownLoadBtn(false);
            }
        }
        reportNew(c, f);
        l.removeClass("hide");
        var m = l.width();
        var h = l.height();
        if (o + h > q) {
            o += q - (o + h) - 10;
        }
        if (a + m > B) {
            a += B - (a + m) - 10;
        }
        l.css({
            top: o + "px",
            left: a + "px"
        });
    };
    var V = function ct(e) {
        if (!c.x) {
            c.x = e.clientX;
            c.y = e.clientY;
        }
        if (Math.abs(e.clientX - c.x) < 10 && Math.abs(e.clientY - c.y) < 10) {
            return false;
        } else {
            c.x = e.clientX;
            c.y = e.clientY;
        }
        var t = +new Date();
        var a = t - u < f;
        u = t;
        if (a) {
            k = false;
            x = false;
        }
        return a;
    };
    var W = function ut(e) {
        try {
            var t = e.clientY - d + y;
            var a = Math.ceil(t / p) - 1;
            return G.onlyGetDom().find(".list-item").eq(a);
        } catch (i) {
            return $("body");
        }
    };
    var Y = function pt() {
        $("#dragItem").remove();
    };
    var X = function vt(e) {
        var t = e.clientX;
        var a = e.clientY;
        if (t > 10 && a > 88 && t < B - 10 && a < q - 10) {
            return true;
        }
        x = false;
        k = false;
        return false;
    };
    var K = function mt() {
        if ($("#dragDiv").length) {
            $("#dragDiv").remove();
        }
    };
    var Z = function ht(e) {
        K();
        if (k) {
            J(e);
        }
        if (x) {
            H(e);
        }
        R = false;
        F = false;
    };
    var et = function gt(e) {
        if (!F || at()) {
            return;
        }
        if (!X(e) || e.button === 2) {
            Y();
            return;
        }
        var t = e.clientX;
        var a = e.clientY;
        var i = t - N.x - 32;
        var r = a - N.y - 50;
        var o = $("#dragItem");
        if (Math.abs(i) > 5 || Math.abs(a - N.y) > 5) {
            o.show();
        }
        o.css({
            top: N.y + r + "px",
            left: N.x + i + "px"
        });
        var l = W(e);
        if (l.hasClass("fold")) {
            var s = l.data("path");
            var d = n.getData(s);
            $(".fold").removeClass("selected");
            l.addClass("selected");
            if ($("#folderNameWidth").length === 0) {
                $("body").append('<div id="folderNameWidth" style="opacity:0;display:inline-block;">' + d.fnameEsc + "</div>");
            } else {
                $("#folderNameWidth").text(d.fnameEsc);
            }
            var f = $("#folderNameWidth").width();
            o.addClass("can");
            o.find(".move-folder-name").text(d.fnameEsc);
            o.find(".move-info").css("width", f + 66 + "px");
        } else {
            $(".fold").removeClass("selected");
            o.removeClass("can");
        }
    };
    var tt = function wt(e) {
        Y();
        if (!X(e) || at()) {
            return;
        }
        k = true;
        F = true;
        var t = e.clientX - 32;
        var a = e.clientY - 50;
        var i = $(".selected").find(".file-icons").eq(0).html();
        var r = $(".selected").eq(0).data("path");
        var o = 0;
        $(".selected").each(function() {
            if ($(this).hasClass("file")) {
                o++;
            }
        });
        var l = n.getFile(r);
        var s = $('<div class="drag-item" id="dragItem"><div class="item"><div class="filesbig-' + l.icon + '_big"></div><span class="file-num">' + o + '</span></div><div class="status icon-cannot"></div><div class="bgs"></div><div class="move-info"> 移动到 <span class="move-folder-name"></span></div></div>');
        s.css({
            top: a + "px",
            left: t + "px"
        });
        s.hide();
        N = {
            x: t,
            y: e.clientY
        };
        $("body").append(s);
        if (l.previewObj) {
            (function() {
                var e = l.previewObj.url + "&pictype=scaled&size=50*50";
                var t = new Image();
                t.onload = function() {
                    s.find(".filesmall-pic").css("background-image", "url(" + e + ")").addClass("thumb");
                };
                t.onerror = function() {
                    console.log("缩略图加载失败!", e);
                };
                t.src = e;
            })();
        }
    };
    var at = function bt() {
        return G.module() === 3;
    };
    var it = function yt() {
        if (G.module() === 3) {
            T = 58;
            S = 58;
        } else {
            T = 0;
            S = 0;
        }
    };
    function nt() {
        var e = function r(e) {
            if (typeof j.x !== "undefined" && R) {
                var t = e - j.x;
                var a = Math.abs(t);
                R.width(a);
                if (t < 0) {
                    R.css("margin-left", t + "px");
                } else {
                    R.css("margin-left", 0);
                }
            }
        };
        var t = function o(e) {
            if (typeof j.y !== "undefined" && R) {
                var t = e - j.y;
                var a = Math.abs(t);
                R.height(a);
                if (t < 0) {
                    R.css("margin-top", t + "px");
                } else {
                    R.css("margin-top", 0);
                }
            }
        };
        var a = function f(e) {
            if (!X(e)) {
                Z(e);
                return;
            }
            $(".selected").removeClass("selected");
            var t = j.y - T;
            var a = I.y - T;
            if ($(e.target).parents(".group1111").length > 0) {
                a -= S;
            }
            var n = Math.floor(t / p);
            var r = Math.floor(a / p);
            n < 0 ? n = 0 : n;
            var o = G.onlyGetDom().find(".list-item");
            var l = undefined;
            if (n < r) {
                l = o.slice(n, r + 1);
            } else if (n === r) {
                l = [ o.eq(r) ];
            } else {
                l = o.slice(r, n + 1);
            }
            if (l.length > 1) {
                $("body").addClass("drag-module");
            }
            var s = false;
            l.each(function() {
                if (this.classList.contains("file")) {
                    this.classList.add("selected");
                    s = true;
                }
            });
            i.changeDownLoadBtn(s);
        };
        $(document).on("mousedown", ".scroll-dom", function(e) {
            it();
            K();
            var t = V(e);
            if (t) {
                e.stopPropagation();
                return;
            }
            var a = function l() {
                if (at()) {
                    return;
                }
                $(".selected").removeClass("selected");
                var e = i.clientX;
                var t = i.clientY + y - d;
                R = $('<div id="' + v + '" class="drag-div"></div>');
                R.css({
                    top: t + "px",
                    left: e + "px"
                });
                j = {
                    x: e,
                    y: t
                };
                s.append(R);
                x = true;
                k = false;
            };
            var i = window.event || e;
            var n = i.button;
            try {
                if (n === 0) {
                    if (at()) {
                        return;
                    }
                    U(e);
                    var r = $(e.target);
                    var o = r.hasClass("drag-dom");
                    if (r.parents(".fold").length > 0) {
                        k = false;
                        o = false;
                    }
                    if (!r.hasClass("selected")) {
                        r = r.parents(".selected");
                    }
                    if (k || r.hasClass("selected")) {
                        if (r.hasClass("selected") && r.hasClass("file") || o) {
                            $(e.target).parents(".file").addClass("selected");
                            tt.call(this, e);
                        } else {
                            a();
                        }
                    } else {
                        a();
                    }
                } else if (n === 2) {
                    Q.call(this, i);
                }
            } catch (e) {
                console.log(e);
            }
        });
        $(document).on("mousemove", ".scroll-dom", function(i) {
            try {
                var n = window.event || i;
                var r = n.button;
                if (r === 0) {
                    var o = n.clientY + y - d;
                    if (k) {
                        et(i);
                    } else if (x) {
                        e(n.clientX);
                        t(o);
                        I = {
                            x: n.clientX,
                            y: o
                        };
                        a(i);
                    }
                } else {
                    x = false;
                }
            } catch (i) {}
        });
        $(document).on("mouseup", ".scroll-dom", function(e) {
            Z(e);
            $("body").removeClass("drag-module");
        });
        $(document).on("click", function() {
            l.addClass("hide");
        });
        $(document).bind("contextmenu", function(e) {
            return false;
        });
        s.on("scroll", function() {
            y = this.scrollTop;
        });
        var n = function c() {
            if (B <= 800) {
                $("body").removeClass("mid-width");
                $("body").removeClass("max-width");
                $("body").addClass("min-width");
            } else if (B <= 1200) {
                $("body").removeClass("mid-width");
                $("body").removeClass("min-width");
                $("body").addClass("mid-width");
            } else {
                $("body").removeClass("min-width");
                $("body").removeClass("mid-width");
                $("body").addClass("max-width");
            }
        };
        $(window).on("resize", function() {
            B = document.body.clientWidth;
            q = document.body.clientHeight;
            $(".scroll-dom").height(q - 76);
            n();
        });
        q = document.body.clientHeight;
        $(".scroll-dom").height(q - 76);
        n();
    }
    function rt(e) {
        $(".list-item").removeClass("selected");
        this.classList.add("selected");
        i.changeDownLoadBtn(this.classList.contains("file"));
    }
}, function(e, t, a) {
    "use strict";
    var i = a(145);
    var n = l(i);
    var r = a(81);
    var o = l(r);
    function l(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var s = [ a(56), a(57), a(83), a(146), a(147), a(148), a(149), a(58), a(141), a(150), a(22), a(151) ];
    var d = {
        "history.next": n.next,
        "history.pref": n.pref
    };
    var f = {
        "list.select": o.listClick
    };
    s.push(d);
    s.push(f);
    function c() {
        var e = {};
        for (var t = 0; t < s.length; t++) {
            var a = s[t];
            var i = undefined;
            for (i in a) {
                if (a.hasOwnProperty(i)) {
                    e[i] = a[i];
                }
            }
        }
        e["tips.close"] = function() {
            $("#alertTips").remove();
        };
        return e;
    }
    e.exports = {
        getHandlerTasks: c
    };
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    var n = $("#fileNum");
    var r = $("#fileNumMenu");
    var o = $(".file-more");
    var l = $("#fileMoreMenu");
    var s = a(152);
    var d = a(54);
    var f = null;
    var c = undefined;
    var u = $("#fileFoward");
    var p = $("#fileFowardTo");
    var v = $("#fileOpenFolder");
    var m = $("#filePreview");
    var h = $("#renameFile");
    var g = $("#foreverFile");
    var w = $("#fileDelete");
    var b = $("#fileMove");
    function y(e, t) {
        report("clkFiles");
        var a = $(".hover-border.file-num-toggle");
        if (r.is(":hidden")) {
            r.show();
            a.addClass("active");
        } else {
            r.hide();
            a.removeClass("active");
        }
    }
    function x() {
        var e = G.selectRow.path;
        var t = d.getData(e);
        if (t.icon === "pic" && t.preview) {
            m.removeClass("disable");
        } else {
            m.addClass("disable");
        }
        if (!t.isDown) {
            v.attr("title", "另存为").attr("data-action", "file.saveAs");
            v.find(".menu-item-label").text("另存为");
        } else {
            v.attr("title", "在文件夹中显示").attr("data-action", "file.openFolderInBox");
            v.find(".menu-item-label").text("在文件夹中显示");
        }
        if (t.temp && t.admin) {
            g.removeClass("disable");
        } else {
            g.addClass("disable");
        }
        if (t.admin) {
            h.removeClass("disable");
            w.removeClass("disable");
            report("showFolderMove");
        } else {
            h.addClass("disable");
            w.addClass("disable");
        }
        if (G.info.isAdmin) {
            b.removeClass("disable");
        } else {
            b.addClass("disable");
        }
        if (G.module() !== 3) {
            b.show();
        } else {
            b.hide();
        }
    }
    function k() {
        var e = G.selectRow.path;
        var t = d.getData(e);
        if (t) {
            if (t.succ) {
                l.find(".open-in-folder").removeClass("disable");
                l.find(".download-item").removeClass("disable");
            } else {
                l.find(".open-in-folder").addClass("disable");
                if (t.filenum === 0) {
                    l.find(".download-item").addClass("disable").removeAttr("data-action");
                } else {
                    l.find(".download-item").removeClass("disable").attr("data-action", "folder.download");
                    report("showDownloadBtn", G.module());
                }
            }
        }
        if (G.oldVersion) {
            l.find(".download-item").addClass("disable").removeAttr("data-action");
        }
    }
    function F(e) {
        $(".list-item").removeClass("active");
        e.addClass("active");
    }
    function T() {
        var e = this;
        var t = $(this).parents(".list-item");
        var a = t.data("path");
        var i = undefined;
        var n = undefined;
        F(t);
        report("clkShowBtn", G.module());
        n = d.getData(a);
        if (n.orcType === 2) {
            i = "fold";
            report("clkFolderMore", G.info.isAdmin ? 0 : 1);
        } else if (n.orcType == 1) {
            i = "file";
            if (n.succ) {
                report("clkUnMore");
            } else {
                report("clkMore");
            }
        }
        G.selectRow = n || {};
        G.selectRow.path = a;
        G.selectRow.type = i;
        G.selectRows = [ G.selectRow ];
        if (i === "fold") {
            if (c !== i) {
                s.renderFolder();
            }
            k();
        } else if (i === "file") {
            if (c === i) {
                x();
            } else {
                s.renderFile();
                u = $("#fileFoward");
                p = $("#fileFowardTo");
                v = $("#fileOpenFolder");
                m = $("#filePreview");
                h = $("#renameFile");
                g = $("#foreverFile");
                w = $("#fileDelete");
                b = $("#fileMove");
                var r = $("#menuPreview");
                x();
            }
        }
        c = i;
        if (e == f && l[0].style.display === "block") {
            l.css("display", "none");
        } else {
            var o = e.getBoundingClientRect();
            var y = $(e).parents(".scroll-dom")[0];
            var T = y.getBoundingClientRect();
            var S = T.right - o.right;
            var _ = document.querySelector(".scroll-dom");
            var C = _.scrollTop;
            var M = _.scrollHeight;
            var D = o.bottom + C - 52;
            l.css("display", "block");
            var R = l.get(0).offsetHeight;
            if (D + R > C + window.innerHeight) {
                D = D - R - 28;
            }
            l.css({
                right: S + "px",
                top: D + "px"
            });
            f = e;
        }
    }
    function S(e) {
        return $(e).closest("#fileNumMenu").length == 0;
    }
    function _(e) {
        return $(e).closest("#fileMoreMenu").length == 0 && $(e).closest(".file-more").length == 0;
    }
    function C(e) {
        if (S(e)) {
            r.hide();
            var t = $(".hover-border.file-num-toggle");
            t.removeClass("active");
        }
        if (_(e)) {
            l.hide();
        }
    }
    function M() {
        if (this.nodeName === "LI") {
            reportNew("blankRightMenuClick", {
                ver1: G.customMenuLength ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: 3
            });
        }
        report("clkRefresh");
    }
    function D() {
        C();
        report("clkFeed");
    }
    i.bind("menu.hide", C);
    e.exports = {
        "menu.filenum": y,
        "menu.filemore": T,
        "menu.foldmore": T,
        "menu.hide": C,
        "menu.refresh": M,
        "menu.feedback": D
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        name: {
            initWidth: "auto",
            minWidth: 80,
            fileRow: ".item-name-adjust"
        },
        update: {
            initWidth: 140,
            minWidth: 96,
            fileRow: ".item-time",
            related: "name"
        },
        size: {
            initWidth: 72,
            minWidth: 68,
            fileRow: ".item-size",
            related: "update"
        },
        "upload-user": {
            initWidth: 82,
            minWidth: 82,
            fileRow: ".item-user",
            related: "size"
        },
        "download-times": {
            initWidth: 96,
            minWidth: 82,
            fileRow: ".item-download-times",
            related: "upload-user"
        },
        source: {
            initWidth: 100,
            minWidth: 68,
            fileRow: ".item-source",
            related: "upload-user"
        }
    };
    var n = false;
    var r = {};
    var o = $("body"), l = $(".file-name-wrap"), s = $(".item-name-adjust");
    var d = $("<style></style>"), f = "", c = $("<style></style>"), u = "";
    $("head").append(d);
    $("head").append(c);
    function p(e, t) {
        if (!~f.indexOf(e)) {
            f += ".file-list .list-item " + e + " {" + t + "}";
            return d[0].innerHTML = f;
        }
        f = f.replace(new RegExp(e + "\\s{.*}", "g"), e + " {" + t + "}");
        d[0].innerHTML = f;
    }
    function v(e, t) {
        if (!~u.indexOf(e)) {
            u += ".file-list .list-item " + e + " {width: " + t + "px;}";
            return c[0].innerHTML = u;
        }
        u = u.replace(new RegExp(e + "\\s{width:\\s\\d*px;}", "g"), e + " {width: " + t + "px;}");
        c[0].innerHTML = u;
    }
    function m(e) {
        var t = $(this), a = t.data("resize-aim"), s = $("[data-resize-id=" + a + "]"), d = i[a].related, c = $("[data-resize-id=" + d + "]"), u = [];
        var m = e.clientX, h = e.clientY;
        var g = i[a].minWidth, w = i[d].minWidth;
        f = "";
        for (var b in i) {
            if (b === a || b === d || b === "name") {
                continue;
            }
            var y = $("[data-resize-id=" + b + "]"), G = y.width();
            v(i[b].fileRow, G);
            p(i[b].fileRow, "max-width: " + G + "px; min-width: " + G + "px;");
            y.width(G).css({
                "max-width": G,
                "min-width": G
            });
            u.push({
                $tab: y,
                aim: b
            });
        }
        var x = l.width();
        l.width(x).css("flex", "initial");
        v(".item-name-adjust", x);
        p(".item-name-adjust", "flex: initial;");
        o.addClass("ondrag");
        r = {
            x: m,
            y: h,
            aim: a,
            aimWidth: s.width(),
            related: d,
            relatedWidth: c.width(),
            aimMinWidth: g,
            relatedMinWidth: w,
            $drag: t,
            $aim: s,
            $related: c,
            aimRow: i[a].fileRow,
            $aimRow: $(i[a].fileRow),
            relatedRow: i[d].fileRow,
            $relatedRow: $(i[d].fileRow),
            dontMoveTabs: u,
            isDragToMin: s.width() <= g,
            isDragToRelatedMin: c.width() <= w
        };
        n = true;
    }
    function h(e) {
        if (!n || e.button !== 0) {
            return;
        }
        if (!e.clientX) {
            return;
        }
        if (r.isDragToMin && e.clientX > r.$drag.offset().left + 5) {
            return;
        } else if (r.isDragToMin) {
            r.isDragToMin = false;
        }
        if (r.isDragToRelatedMin && e.clientX < r.$drag.offset().left - 5) {
            return;
        } else if (r.isDragToRelatedMin) {
            r.isDragToRelatedMin = false;
        }
        var t = r.x - e.clientX, a = t + r.aimWidth, i = r.relatedWidth - t, o = t <= 0, l = undefined, s = undefined;
        if (o) {
            l = Math.max(a, r.aimMinWidth);
            s = i;
            if (l <= r.aimMinWidth) {
                s = i - (r.aimMinWidth - a);
            }
        } else {
            l = a;
            s = Math.max(i, r.relatedMinWidth);
            if (s <= r.relatedMinWidth) {
                l = a - (r.relatedMinWidth - i);
            }
        }
        r.aimWidth = l;
        r.relatedWidth = s;
        r.x = e.clientX;
        r.$aim.width(l);
        r.$related.width(s);
        v(r.aimRow, l);
        v(r.relatedRow, s);
        if (l <= r.aimMinWidth) {
            r.isDragToMin = true;
            r.x = r.$drag.offset().left + 5;
        }
        if (s <= r.relatedMinWidth) {
            r.isDragToRelatedMin = true;
            r.x = r.$drag.offset().left + 5;
        }
    }
    function g(e) {
        if (!n) {
            return;
        }
        n = false;
        l.css("flex", 1);
        p(".item-name-adjust", "flex: 1;");
        o.removeClass("ondrag");
        r.dontMoveTabs.forEach(function(e) {
            var t = i[e.aim].minWidth;
            e.$tab.css({
                "max-width": "none",
                "min-width": t
            });
            p("" + i[e.aim].fileRow, "max-width: none; min-width: " + t + "px;");
        });
        reportNew("adjustTab", {
            ver1: G.info.isAdmin ? G.info.isMaster ? 1 : 2 : 3
        });
    }
    function w() {
        for (var e in i) {
            var t = $("[data-resize-id=" + e + "]");
            t.css({
                width: i[e].initWidth,
                "max-width": "none",
                "min-width": "none"
            });
        }
        f = "";
        u = "";
        d[0].innerHTML = f;
        c[0].innerHTML = u;
    }
    $(document).on("mousedown", ".tab-resize", m);
    $(document).on("mousemove", h);
    $(document).on("mouseup.adjustTab", g);
    $(window).on("resize", g);
    e.exports = {
        resetTab: w
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(161).fileEvent;
    var r = a(150).groupEvent;
    var o = a(162).uploadEvent;
    var l = a(162).dropEvent;
    var s = a(163);
    var d = top;
    var f = top.external;
    window.addEventListener("message", u);
    d["PostMessage"] = d["onClientEvent"] = c;
    function c(e) {
        console.log("收到客户端通知:", e);
        var t = undefined;
        if (!e) {
            console.error("[Client] msg is not exist!");
            return;
        }
        if (typeof e === "string") {
            try {
                t = JSON.parse(e);
            } catch (a) {
                console.error("[Client|init()]msg is string, but parse to object catch e!");
            }
        }
        if ((typeof t === "undefined" ? "undefined" : i(t)) !== "object") {
            console.error("[Client|init()]after parse, got no object!");
            return;
        }
        u(t);
    }
    function u(e) {
        var t = e;
        if (t && (typeof t === "undefined" ? "undefined" : i(t)) === "object") {
            if (t.from === "Client") {
                var a = t.data;
                if (typeof a === "string") {
                    a = JSON.parse(t.data) || {};
                }
                var d = a.cmd || "";
                switch (d) {
                  case "OnFiletransporterEvent":
                    n(a.param);
                    break;

                  case "OnGroupShareTabChangedEvent":
                    r(a.param);
                    break;

                  case "OnGroupUploadFileListsEvent":
                    o(param);
                    break;

                  case "OnGroupDropInGroupFolderUpload":
                    o(param);
                    break;

                  default:
                    console.warn("warn:预期外的message.cmd:" + d);
                    break;
                }
            } else if (t.cmd && t.cmd === "OnGroupUploadFileListsEvent") {
                o(t.param);
            } else if (t.cmd && t.cmd === "OnGroupDropInGroupFolderUpload") {
                l(t.param);
            } else {
                var a = t.data;
                if (!a) {
                    return;
                }
                if (typeof a === "string") {
                    a = JSON.parse(a);
                }
                var d = a.cmd || "";
                switch (d) {
                  case "jubao_close":
                    s.hide();
                    break;

                  default:
                    console.warn("warn:预期外的message.cmd:" + d);
                    break;
                }
            }
        }
    }
    window.onClientEvent = c;
    e.exports = {};
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '	<div class="toast-overlay" id="toastDom">\r\n		<div class="toast">\r\n			<div class="icons-<%-locals.cls%> toast-icon"></div>\r\n			<div class="toast-message"><%-locals.text%></div>\r\n		</div>\r\n	</div>', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\toast.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('	<div class="toast-overlay" id="toastDom">\r\n		<div class="toast">\r\n			<div class="icons-');
            s = 3;
            u(e.cls);
            u(' toast-icon"></div>\r\n			<div class="toast-message">');
            s = 4;
            u(e.text);
            u("</div>\r\n		</div>\r\n	</div>");
            s = 6;
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, , function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '<div class="files-empty"><div><div class="icons-empty"></div><div class="empty-desc">在这里，你可以把各种有趣的东西分享给大家</div></div></div>\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\errormsg.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('<div class="files-empty"><div><div class="icons-empty"></div><div class="empty-desc">在这里，你可以把各种有趣的东西分享给大家</div></div></div>\n');
            s = 2;
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, , , , , , , , , , , , , , , , , , , function(e, t, a) {
    "use strict";
    function i(e) {
        if (!G.cMap) {
            G.cMap = {};
        }
        var t = G.cMap[e.id];
        if (!t) {
            t = G.cMap[e.filepath];
            if (t) {
                if (t && t.type.indexOf("upload") >= 0 && e.type.indexOf("upload") >= 0 && t.status != e.status) {
                    if (e.id) {
                        plistMap[e.id] = t;
                    }
                    console.warn("new task 发现续传 id[" + t.id + "] status[" + t.status + "]");
                } else if (e.type == "download") {
                    console.log(e);
                } else {}
            }
        }
        if (!t) {
            if (e.id) {
                G.cMap[e.id] = e;
            }
            if (e.filepath) {
                G.cMap[e.filepath] = e;
            }
            return e;
        } else {}
    }
    function n(e) {
        if (G.cMap[e.id] || G.cMap[e.filepath]) {
            return true;
        } else {
            return false;
        }
    }
    function r(e) {
        if (G.cMap[e.id]) {
            delete G.cMap[e.id];
        }
        if (G.cMap[e.filepath]) {
            delete G.cMap[e.filepath];
        }
    }
    function o(e) {}
    function l() {
        for (var e in G.cMap) {
            var t = G.cMap[e];
            if (t && t.status === "uploadcomplete") {
                delete G.cMap[t.id];
                delete G.cMap[t.filepath];
            }
        }
    }
    e.exports = {
        check: n,
        add: i,
        del: r,
        update: o,
        clearComplete: l
    };
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function b(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '<%\r\n	for(var i = 0,l = locals.list.length;i<l;i++){\r\n		var item = locals.list[i];\r\n%>\r\n<div class="file2 file2-2 <%-item.styles%>" data-path="<%-item.filepath%>" data-id="<%-item.id%>" data-folder="<%-item.folderpath%>" data-name="<%-item.filename%>" <%if(item.styleStatus === \'complete\'){%>data-action="task.openFolder"<%}%>>\r\n	<div class="file-icon">\r\n		<div class="filesmall-<%-item.icon%>"></div>\r\n		<i></i>\r\n	</div>\r\n	<div class="file-info">\r\n		<div class="filename">\r\n			<div class="name"><%-item.name%></div>\r\n			<%if(item.orcType === 1){%>\r\n				<div class="suffix"><%-item.suf%></div>\r\n			<%}%>\r\n		</div>\r\n		<div class="loading">\r\n			<div class="bar" style="width:<%-item.cPercent%>%;"></div>\r\n		</div>\r\n		<%if(item.failedFileList && item.failedFileList.length > 0){%>\r\n			<div class="wording"  data-action="task.openfail">\r\n				<i class=\'warn\'></i>有<%-item.failedFileList.length%>个文件下载失败<i class="arrow"></i>\r\n					<ul class="fail-list">\r\n						<%for(var j = 0,m = item.failedFileList.length;j<m;j++){%> \r\n							<li><%=item.failedFileList[j].filename%></li>\r\n						<%}%>\r\n					</ul>\r\n			</div>\r\n		<%}else{%>\r\n			<div class="wording"><%-item.wording%></div>		\r\n		<%}%>\r\n	</div>\r\n	<div class="file-action">\r\n		<div class="aria-hide">\r\n			<a class="aria-tips" tabindex="-1">\r\n				<%if(item.orcType === 1){%>\r\n					文件<%=item.name%><%-item.suf%>\r\n				<%}else{%>\r\n					文件夹<%=item.name%>\r\n				<%}%>\r\n				 状态:<%-item.wording%> 任务进度<%-item.cPercent%>% \r\n			</a>\r\n		</div>\r\n		<a href="javascript:void(0)" class="seat"  tabindex="-1"></a>\r\n		<a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 <%=item.name%>" tabindex="-1"></a>\r\n		<a class="ok-upload"></a>\r\n		<a class="ok-download"></a>\r\n		<a class="go-folder" data-action="task.openFolderIco" title="打开该文件所在的文件夹" arir-label="打开<%=item.name%>所在的文件夹" tabindex="3"></a>\r\n	</div>\r\n	<div></div>\r\n</div>\r\n<%}%> ', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\taskNew.ejs";
        try {
            var c = [], u = c.push.bind(c);
            for (var p = 0, v = e.list.length; p < v; p++) {
                var m = e.list[p];
                s = 4;
                u('\r\n<div class="file2 file2-2 ');
                s = 5;
                u(m.styles);
                u('" data-path="');
                u(m.filepath);
                u('" data-id="');
                u(m.id);
                u('" data-folder="');
                u(m.folderpath);
                u('" data-name="');
                u(m.filename);
                u('" ');
                if (m.styleStatus === "complete") {
                    u('data-action="task.openFolder"');
                }
                u('>\r\n	<div class="file-icon">\r\n		<div class="filesmall-');
                s = 7;
                u(m.icon);
                u('"></div>\r\n		<i></i>\r\n	</div>\r\n	<div class="file-info">\r\n		<div class="filename">\r\n			<div class="name">');
                s = 12;
                u(m.name);
                u("</div>\r\n			");
                s = 13;
                if (m.orcType === 1) {
                    u('\r\n				<div class="suffix">');
                    s = 14;
                    u(m.suf);
                    u("</div>\r\n			");
                    s = 15;
                }
                u('\r\n		</div>\r\n		<div class="loading">\r\n			<div class="bar" style="width:');
                s = 18;
                u(m.cPercent);
                u('%;"></div>\r\n		</div>\r\n		');
                s = 20;
                if (m.failedFileList && m.failedFileList.length > 0) {
                    u('\r\n			<div class="wording"  data-action="task.openfail">\r\n				<i class=\'warn\'></i>有');
                    s = 22;
                    u(m.failedFileList.length);
                    u('个文件下载失败<i class="arrow"></i>\r\n					<ul class="fail-list">\r\n						');
                    s = 24;
                    for (var h = 0, g = m.failedFileList.length; h < g; h++) {
                        u(" \r\n							<li>");
                        s = 25;
                        u(t(m.failedFileList[h].filename));
                        u("</li>\r\n						");
                        s = 26;
                    }
                    u("\r\n					</ul>\r\n			</div>\r\n		");
                    s = 29;
                } else {
                    u('\r\n			<div class="wording">');
                    s = 30;
                    u(m.wording);
                    u("</div>		\r\n		");
                    s = 31;
                }
                u('\r\n	</div>\r\n	<div class="file-action">\r\n		<div class="aria-hide">\r\n			<a class="aria-tips" tabindex="-1">\r\n				');
                s = 36;
                if (m.orcType === 1) {
                    u("\r\n					文件");
                    s = 37;
                    u(t(m.name));
                    u(m.suf);
                    u("\r\n				");
                    s = 38;
                } else {
                    u("\r\n					文件夹");
                    s = 39;
                    u(t(m.name));
                    u("\r\n				");
                    s = 40;
                }
                u("\r\n				 状态:");
                s = 41;
                u(m.wording);
                u(" 任务进度");
                u(m.cPercent);
                u('% \r\n			</a>\r\n		</div>\r\n		<a href="javascript:void(0)" class="seat"  tabindex="-1"></a>\r\n		<a class="pause" data-action="task.pause" title="暂停" aria-label="暂停任务 ');
                s = 45;
                u(t(m.name));
                u('" tabindex="-1"></a>\r\n		<a class="resume" data-action="task.resume" title="启动" aria-label="启动任务 ');
                s = 46;
                u(t(m.name));
                u('" tabindex="-1"></a>\r\n		<a class="continue" data-action="task.continue" title="续传" aria-label="续传任务 ');
                s = 47;
                u(t(m.name));
                u('" tabindex="-1"></a>\r\n		<a class="remove" data-action="task.remove" title="删除"  aria-label="删除任务 ');
                s = 48;
                u(t(m.name));
                u('" tabindex="-1"></a>\r\n		<a class="ok-upload"></a>\r\n		<a class="ok-download"></a>\r\n		<a class="go-folder" data-action="task.openFolderIco" title="打开该文件所在的文件夹" arir-label="打开');
                s = 51;
                u(t(m.name));
                u('所在的文件夹" tabindex="3"></a>\r\n	</div>\r\n	<div></div>\r\n</div>\r\n');
                s = 55;
            }
            u(" ");
            return c.join("");
        } catch (w) {
            n(w, d, f, s);
        }
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        var t = {
            fLen: 3
        };
        if (typeof e != "number") return "";
        var a;
        var i = e;
        var n = [ "B", "KB", "MB", "GB", "TB", "PB" ];
        while (i > 1024) {
            i = i / 1024;
            n.shift();
        }
        if (i >= 1e3) {
            i = i / 1024;
            n.shift();
        }
        var r = ("" + i).length;
        var o = 2;
        var l = 100;
        if (t && t.len) o = t.len;
        if (o < 0) o = 0;
        l = Math.pow(10, o);
        i = Math.floor(i * l) / l;
        if (t && t.fLen) {
            var s = i.toString().indexOf(".");
            if (i.toString().length <= t.fLen) {
                var d = parseInt(i, 10).toString().length;
                i = i.toFixed(t.fLen - d);
            } else if (t.fLen < i.toString().length) {
                i = i.toString();
                if (s > 0 && s < 3) i = i.substr(0, 4); else i = i.substr(0, 3);
            }
        }
        a = i.toString().replace(/\.0+$/, "");
        a = a + n[0];
        if (i === 0) a = 0;
        return a;
    }
    function n(e) {
        var t = {
            fLen: 3
        };
        if (typeof e != "number") return "";
        var a;
        var i = e;
        var n = [ "B", "KB", "MB", "GB", "TB", "PB" ];
        while (i > 1024) {
            i = i / 1024;
            n.shift();
        }
        if (i >= 1e3) {
            i = 1;
            n.shift();
        }
        var r = ("" + i).length;
        var o = 2;
        var l = 100;
        if (t && t.len) o = t.len;
        if (o < 0) o = 0;
        l = Math.pow(10, o);
        var s = Math.round(i * l) / l;
        if (s >= 1e3) i = Math.floor(i * l) / l; else i = s;
        if (t && t.fLen) {
            var d = i.toString().indexOf(".");
            if (i.toString().length <= t.fLen) {
                var f = parseInt(i, 10).toString().length;
                i = i.toFixed(t.fLen - f);
            } else if (t.fLen < i.toString().length) {
                i = i.toString();
                if (d > 0 && d < 3) i = i.substr(0, 4); else i = i.substr(0, 3);
            }
        }
        a = i.toString().replace(/\.0+$/, "");
        a = a + n[0];
        if (i === 0) a = 0;
        return a;
    }
    function r(e) {
        var t = "unknow";
        var a = {
            excel: /xls|xlsx/i,
            pdf: /pdf/i,
            ppt: /ppt|pptx/i,
            word: /doc|docx|wps/i,
            text: /txt/i,
            pic: /jpg|jpeg|jpgx|gif|bmp|png|ico|webp|raw|tiff/i,
            music: /mp3|wma|midi|aac|ape|flac|wav|mid|ogg|aac/i,
            video: /mp4|rm|rmvb|mpeg|mov|avi|3gp|amv|dmv|flv|wmv|qsed|asf|mkv/i,
            zip: /rar|zip|tar|cab|uue|jar|iso|7z|ace|lzh|arj|gzip|bz2/i,
            code: /ink|torrent|url|vbs|tif|w3g|vbe|ssf|dll|mht|rcd|bat|sav|dat|cmd|ttf|xml|vob|sgs|mhw|js|html|htm|css/i,
            exe: /exe|msi/i,
            ipa: /ipa/i,
            dmg: /dmg/i,
            apk: /apk/i
        };
        for (var i in a) {
            var n = a[i];
            if (n.test(e)) {
                t = i;
                break;
            }
        }
        return t;
    }
    function o(e) {
        var t = "其他";
        var a = {
            "文档": /doc|docx|ppt|pptx|xsl|xslx|xls|xlsx|pdf|txt|wps/i,
            "图片": /jpg|jpeg|jpgx|gif|bmp|png/i,
            "音乐": /mp3|wma|midi|aac/i,
            "视频": /mp4|rm|rmvb|mpeg|mov|avi|3gp|amv|dmv|flv|wmv|qsed/i,
            "压缩包": /rar|zip|tar|cab|uue|jar|iso|7z|ace|lzh|arj|gzip|bz2/i,
            "应用": /dmg/i
        };
        for (var i in a) {
            var n = a[i];
            if (n.test(e)) {
                t = i;
                break;
            }
        }
        return t;
    }
    var l = 5485;
    function s(e, t) {
        return false;
    }
    function d(e) {
        var t = e.lastIndexOf("."), a = {};
        if (t >= 0) {
            a.filename_name = e.substr(0, t);
            a.filename_suf = e.substr(t);
        } else {
            a.filename_name = e;
            a.filename_suf = "";
        }
        return a;
    }
    function f(e) {
        var t = e.lastIndexOf("\\"), a = e.substr(t + 1);
        return a;
    }
    e.exports = {
        getSize: i,
        getIcon: r,
        getType: o,
        canEdit: s,
        getFileName: d,
        getFolderName: f
    };
}, function(e, t, a) {
    "use strict";
    var i = a(111);
    function n(e) {
        var t = i.errorCfgPrefix[e.type] + "-" + e.status;
        if (t in i.errorCfg && i.errorCfg) {
            return true;
        }
        return false;
    }
    function r(e) {
        if (!e || !e.type || !e.status) {
            return "";
        }
        var t = i.errorCfgPrefix[e.type] + "-" + e.status;
        if (t in i.errorCfg) {
            if (t === "upload-uploadsecurityfail" && i.securityattriMap[e.securityattri]) {
                return i.securityattriMap[e.securityattri];
            }
            return i.errorCfg[t];
        }
        return;
    }
    function o(e, t) {
        return i.wordingMap[e][t];
    }
    function l(e, t) {
        return i.styleMap[e][t];
    }
    function s(e) {
        return i.typeMap[e];
    }
    function d(e, t) {
        if (!e) {
            return false;
        }
        if (!i.wordingMap[e]) {
            console.warn("设置wording 未知任务类型=[" + e + "]");
        }
        if (!i.wordingMap[e][t]) {
            console.warn("设置wording 未知任务状态=[" + t + "]");
        }
        if (!i.styleMap[e][t]) {
            console.warn("设置样式 未知任务状态=[" + t + "]");
        }
    }
    e.exports = {
        check: d,
        getType: s,
        getWord: o,
        getClass: l,
        ifError: n,
        getErrorWord: r
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        upload: "upload",
        continueupload: "continueupload",
        download: "download"
    };
    var n = {};
    n.upload = {
        scanning: "扫描中...&nbsp;&nbsp;",
        scanfail: "扫描失败&nbsp;&nbsp;",
        scanend: "扫描完成...&nbsp;&nbsp;",
        uploadgeturl: "准备上传...&nbsp;&nbsp;",
        uploadgeturlend: "上传中...&nbsp;&nbsp;",
        uploadadminonlyfail: "无法上传，已限制成员上传文件",
        uploadgeturlfail: "申请上传地址失败",
        uploadlimit: "文件个数达到上限，无法上传",
        uploadsecurityfail: "安全扫描失败",
        cancel: "空间不足,已取消上传",
        uploadprogress: "上传中:&nbsp;&nbsp;",
        uploadfail: "上传失败",
        uploadcomplete: "上传完成&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        pause: "暂停&nbsp;&nbsp;",
        "continue": "待续传&nbsp;&nbsp;"
    };
    n.download = {
        wait: "等待下载...&nbsp;&nbsp;",
        downloadready: "准备下载...&nbsp;&nbsp;",
        downloadgeturl: "准备下载...&nbsp;&nbsp;",
        downloadgeturlfail: "获取下载地址失败",
        cancel: "已取消下载&nbsp;&nbsp;",
        downloadgeturlend: "下载中...",
        downloadprogress: "下载中:&nbsp;&nbsp;",
        downloadfail: "下载失败&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        downloadcomplete: "下载完成&nbsp;&nbsp;",
        pause: "暂停&nbsp;&nbsp;"
    };
    n.continueupload = {
        scanning: "扫描中...&nbsp;&nbsp;",
        scanfail: "扫描失败&nbsp;&nbsp;",
        scanend: "扫描完成...&nbsp;&nbsp;",
        uploadgeturl: "准备续传...&nbsp;&nbsp;",
        uploadgeturlend: "续传中...&nbsp;&nbsp;",
        uploadgeturlfail: "申请续传地址失败",
        uploadlimit: "文件个数达到上限，无法上传",
        uploadsecurityfail: "安全扫描失败",
        cancel: "空间不足,已取消续传",
        uploadprogress: "续传中:&nbsp;&nbsp;",
        uploadfail: "续传失败",
        uploadcomplete: "续传完成&nbsp;&nbsp;",
        pause: "暂停&nbsp;&nbsp;",
        filenotexsit: "文件不存在",
        "continue": "待续传&nbsp;&nbsp;"
    };
    var r = {};
    r.upload = {
        scanning: "scan",
        scanfail: "err",
        scanend: "scan",
        uploadgeturl: "pre",
        uploadgeturlend: "pre",
        uploadgeturlfail: "err",
        uploadsecurityfail: "err",
        cancel: "err",
        uploadprogress: "progress",
        uploadfail: "err",
        uploadcomplete: "complete",
        pause: "pause",
        filenotexsit: "err",
        "continue": "continue",
        remove: ""
    };
    r.download = {
        wait: "pre",
        downloadready: "pre",
        downloadgeturl: "pre",
        downloadgeturlfail: "err",
        cancel: "err",
        downloadgeturlend: "pre",
        downloadprogress: "progress",
        downloadfail: "err",
        filenotexsit: "err",
        downloadcomplete: "complete",
        pause: "pause"
    };
    r.continueupload = {
        scanning: "scan",
        scanfail: "err",
        scanend: "scan",
        uploadgeturl: "pre",
        uploadgeturlend: "pre",
        uploadgeturlfail: "err",
        uploadsecurityfail: "err",
        cancel: "err",
        uploadprogress: "progress",
        uploadfail: "err",
        uploadcomplete: "complete",
        pause: "pause",
        filenotexsit: "err",
        "continue": "continue",
        remove: ""
    };
    var o = {
        upload: "upload",
        download: "download",
        continueupload: "upload"
    };
    var l = [ "安全", "扫描到病毒，已取消上传", "扫描到未知风险", "扫描到安全风险", "扫描到安全风险", "扫描到安全风险", "文件包含敏感词" ];
    var s = {
        "download-downloadgeturlfail": "下载失败,请稍候再试",
        "download-cancel": "",
        "download-downloadfail": "下载失败",
        "upload-scanfail": "扫描失败,请稍候再试",
        "upload-uploadgeturlfail": "上传失败",
        "upload-uploadsecurityfail": "上传安全扫描失败",
        "upload-cancel": "空间不足,已取消上传",
        "upload-uploadfail": "上传失败,请稍候再试",
        folderLimit: "文件夹个数以达上限"
    };
    var d = 300;
    e.exports = {
        errorCfg: s,
        errorCfgPrefix: o,
        securityattriMap: l,
        styleMap: r,
        wordingMap: n,
        typeMap: i,
        refreshTime: d
    };
}, function(e, t, a) {
    "use strict";
    var i = new Date();
    var n = i.getFullYear();
    function r(e) {
        var t = Math.ceil(e / 86400);
        return t;
    }
    function o(e) {
        e = G(e);
        if (e.getFullYear() != i.getFullYear()) return false;
        if (e.getMonth() != i.getMonth()) return false;
        if (e.getDate() != i.getDate()) return false;
        return true;
    }
    function l(e) {
        e = G(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n > 0 && n < 864e5;
        }
        return a;
    }
    function s(e) {
        e = G(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n > 0 && n < 864e5 * 2;
        }
        return a;
    }
    function d(e) {
        e = G(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n >= 0 && n <= 864e5;
        }
        if (a) return "昨天"; else return "前天";
    }
    function f(e) {
        e = G(e);
        var t = o(e);
        var a = false;
        if (!t) {
            var n = new Date(i.getFullYear(), i.getMonth(), i.getDate()) - e;
            a = n > 0 && n < 864e5 * 2;
        }
        return a;
    }
    function c(e) {
        e = G(e);
        var t = m(i);
        if (e > t) return true;
        return false;
    }
    function u(e) {
        e = G(e);
        if (e.getYear() != i.getYear()) return false;
        return true;
    }
    function p(e) {
        if (!e) e = i.getFullYear();
        var t = new Date(e, 0, 1);
        var a = undefined;
        var n = t.getDay();
        if (n === 0) n = 7;
        var r = [ null, "一", "二", "三", "四", "五", "六", "日" ];
        var o = "周" + r[n];
        if (n != 1) t.setDate(1 + 8 - n);
        return t;
    }
    function v(e) {
        var t = new Date(e);
        var a = p(t.getFullYear());
        var i = 0;
        var n = undefined;
        if (a.getDate() > 1) i = 1;
        if (t < a) n = 1; else {
            n = Math.floor((t - a) / 7 / 864e5) + i;
        }
        return n;
    }
    function m(e) {
        var t = G(e);
        var a = t.getDay();
        if (a === 0) a = 7;
        var i = a - 1;
        var n = undefined;
        n = new Date(t.getTime() - i * 864e5);
        return n;
    }
    function h(e) {
        var t = G(e);
        var a = t.getDay();
        if (a === 0) a = 7;
        return a;
    }
    function g() {}
    function w(e) {
        if (!e) {
            return;
        }
        var t = G(e);
        var a = t.getFullYear();
        var i = t.getMonth() + 1;
        var n = t.getDate();
        var r = t.getHours();
        var o = t.getMinutes();
        if (i < 10) i = "0" + i;
        if (n < 10) n = "0" + n;
        if (o < 10) {
            o = "0" + o;
        }
        return a + "-" + i + "-" + n + " " + r + ":" + o;
    }
    function b(e) {
        if (!e) {
            return;
        }
        var t = G(e);
        var a = t.getFullYear();
        var i = t.getMonth() + 1;
        var n = t.getDate();
        var r = t.getHours();
        var o = t.getMinutes();
        if (i < 10) i = "0" + i;
        if (n < 10) n = "0" + n;
        if (o < 10) {
            o = "0" + o;
        }
        return a + "-" + i + "-" + n + " " + r + ":" + o;
    }
    function y(e) {
        var t = G(e);
        var a = new Date();
        var i = a.getTime() - t.getTime();
        var n = parseInt(i / 36e5, 10);
        if (n < 1) n = "刚刚"; else n = n + "小时前";
        return n;
    }
    function G(e) {
        var t = e;
        if (typeof e === "string") t = new Date(e);
        if (typeof e === "number") t = new Date(e * 1e3);
        return t;
    }
    function x(e) {
        if (!e) {
            return;
        }
        var t = 60, a = 3600, i = 86400, n = "";
        if (e >= i) {
            n = Math.ceil(e / i) + "天";
        } else if (e >= a) {
            n = Math.ceil(e / a) + "小时";
        } else if (e >= t) {
            n = Math.ceil(e / t) + "分钟";
        } else if (e > 0) {
            n = e + "秒";
        } else {
            n = "已过期";
        }
        return n;
    }
    function k(e) {
        var t = undefined;
        var a = undefined;
        if (typeof e == "number") {
            t = new Date(e * 1e3);
        } else if (e instanceof Date) {
            t = e;
        }
        if (o(t)) {
            a = y(t);
        } else if (s(t)) {
            a = d(t);
        } else {
            a = w(t);
        }
        return a;
    }
    function F(e) {
        var t = e.createtime;
        e.day_str = k(t);
        e.createtime_str = w(t);
        if (e.day_str === "今天") {
            e.createtime_str = y(t);
        }
        if (e.day_str === "最近三天") {
            e.createtime_str = d(t);
        }
    }
    e.exports = {
        dayStr: k,
        genTimeStr: F,
        getValidity: x,
        toDate: G,
        getHourStr: y,
        getExpriesDayNum: r,
        isToday: o,
        isYesterday: l,
        strYesterdayOrPre: d,
        isLast3days: f,
        isThisWeek: c,
        isThisYear: u,
        getMonOY: p,
        getWOY: v,
        getMOW: m,
        getDayOfWeek: h,
        getDayOfYear: g,
        getDateStr: k,
        getorcDateStr: w
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.doClearFile = t.clickClearFile = undefined;
    var i = a(78);
    var n = l(i);
    var r = a(133);
    var o = l(r);
    function l(e) {
        return e && e.__esModule ? e : {
            "default": e
        };
    }
    var s = $("#cleanFile");
    var d = $("#cleanProg");
    var f = t.clickClearFile = function u() {
        if (!G.info.isMaster) {
            return;
        }
        reportNew("cleanEntry");
        o.default.showBatchPanel(s, {
            title: "提示",
            action: "file.doClearFile",
            text: '将为你保留最近的1500个文件和文件夹，并删除之前的所有文件<div class="warming">注意:本操作不可恢复，请自行备份</div>',
            okBtnText: "确定删除"
        });
    };
    var c = t.doClearFile = function p() {
        if (!G.info.isMaster) {
            return;
        }
        o.default.hide(s);
        o.default.show(d);
        n.default.cleanFile().done(function(e) {}).fail(function(e) {
            o.default.hide(d);
        });
        reportNew("clickClean", {
            ver1: 0
        });
        var e = 0;
        var t = function a() {
            n.default.getFileCount().done(function(t) {
                if (t.ec === 0 && !t.is_too_many) {
                    o.default.hide(d);
                    clearTimeout(e);
                    location.reload();
                } else {
                    e = setTimeout(a, 2e3);
                }
            }).fail(function(t) {
                e = setTimeout(a, 2e3);
            });
        };
        t();
    };
}, function(e, t, a) {
    "use strict";
    var i = a(109);
    var n = a(50);
    var r = $("#upload-panel");
    var o = {
        folderTree: a(186),
        showFolderTreePanel: a(133).showFolderTreePanel,
        panel: a(133)
    };
    var l = a(19);
    var s = G.folderVersion;
    var d = a(149);
    var f = a(54);
    var c = a(17);
    var u = undefined;
    function p() {
        if (l.getTips()) {
            n.addUploadTask();
        } else {
            report("showOldVersion");
            $("#updateQQ").addClass("open");
            $("#updateQQTips").text("当前版本仅支持将文件上传至群文件首页，升级至QQ最新版本可上传文件至文件夹内。");
            $("#updateQQ").find("input.btn-notips").attr("data-action", "upload.cUpload");
        }
    }
    function v() {
        if (this.checked) {
            l.setTips(1);
            G.oldVersion = true;
            $("#headerBatch .store").addClass("disabled");
            report("clkNotRemind");
        } else {
            l.setTips(0);
        }
    }
    function m() {
        $("#updateQQ").removeClass("open");
        n.addUploadTask();
    }
    function h() {
        if (G.file.isFull) {
            reportNew("limitTip", {
                ver1: 0
            });
            return c.show("alert", "文件数已达到上限");
        }
        if (this.nodeName === "LI") {
            reportNew("blankRightMenuClick", {
                ver1: G.customMenuLength ? 1 : 2,
                ver2: G.info.isAdmin ? 1 : 2,
                ver3: 1
            });
        }
        if (G.info.version < s) {
            p();
        } else {
            if (G.folderMap() && Object.keys(G.folderMap()).length > 0 || G.nowFolder !== "/") {
                n.getBatchFiles();
            } else {
                report("clkUpload", G.module());
                n.addUploadTask();
            }
        }
    }
    function g(e) {
        if (!u) {
            return;
        }
        var t = undefined;
        if (typeof e === "string") {
            report("clkUpload", 1);
            t = e;
        } else {
            t = G.folderTree && G.folderTree.selected && G.folderTree.selected.id || "/";
        }
        if ($("#inputFolderNameInFolderTree").length > 0) {
            d["folderTree.create"](null, function() {
                t = G.folderTree.selected && G.folderTree.selected.id || "/";
                var e = n.batchUpload(t, JSON.stringify(u));
                u = null;
                o.panel.hideAll();
            });
        } else {
            var a = n.batchUpload(t, JSON.stringify(u));
            u = null;
            o.panel.hideAll();
        }
    }
    function w(e, t) {
        if (G.file.isFull) {
            reportNew("limitTip", {
                ver1: 0
            });
            return c.show("alert", "文件数已达到上限");
        }
        if (!t || t.length === 0) {
            return;
        }
        var a = undefined;
        a = e;
        var i = "上传到群文件？";
        if (a !== "/") {
            var r = f.getData(a);
            i = "上传到文件夹：" + r.fnameEsc + "？";
        }
        var l = n.confirm(1, "提示", i);
        if (l.errorCode === 0 && l.ret) {
            report("clkUpload", 1);
            var s = n.batchUpload(a, JSON.stringify(t));
            o.panel.hideAll();
        }
    }
    function b() {
        r.addClass("open");
    }
    function y(e) {
        var t = e[0];
        var a = e.length;
        var n = t.lastIndexOf("\\");
        var r = t.substr(n + 1);
        if (G.mac) {
            n = t.lastIndexOf("/");
            r = t.substr(n + 1);
        }
        console.log(t);
        var o = i.getFileName(r);
        if (a > 1) {
            return '<span class="name">' + o.filename_name + "</span><span>" + o.filename_suf + '</span>等<span class="blue">' + a + "</span>个文件";
        } else {
            return '<span class="name">' + o.filename_name + "</span><span>" + o.filename_suf + "</span>";
        }
    }
    function x(e) {
        u = e;
        if (G.nowFolder !== "/") {
            g(G.nowFolder);
            return;
        }
        var t = {
            title: "上传文件",
            firstFileName: y(e),
            action: "上传到：",
            destFolder: "群文件",
            okAction: "file.batchUpload"
        };
        o.showFolderTreePanel(t);
        var a = $("#containerFolderTreePanel");
        a.find("#folderTreePanel").addClass("open");
        report("folderTree", 0);
        return;
    }
    function k() {
        report("clkUpdateQQ");
    }
    e.exports = {
        batchuploadInFolder: w,
        upload: h,
        bupload: g,
        showUpload: x,
        noTips: v,
        cupload: m,
        update: k
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(50);
    var r = a(59);
    var o = a(53);
    var l = a(19);
    var s = $(G.handler);
    function d(e) {
        delete e.status;
        e.isDown = false;
        e.isDowning = false;
        e.succ = false;
        r.updateRow(e);
        o.removeOpenFolder(e);
        l.remove(e);
    }
    function f(e) {
        s.trigger("menu.hide");
        if (window.external && window.external.isFileExist) {
            var t = window.external.isFileExist(e);
            if (t == "false" || t === false) {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                var a = i.getFile(e);
                d(a);
                return false;
            }
        } else {}
        if (window.external && window.external.openFile) {
            var r = window.external.openFile(e);
            if (r == "success") {
                return true;
            } else if (r !== "file cannot open") {
                return false;
            }
        }
        if (window.external && window.external.openFolder) {
            var r = window.external.openFolder(e);
            if (r == "success") {} else {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                return false;
            }
        } else {}
    }
    function c() {
        var e = G.selectRow;
        var t = e.localpath;
        s.trigger("menu.hide");
        if (typeof t === "string" && t.indexOf("OSRoot") < 0) {
            t = "OSRoot:\\" + t;
        }
        report("clkOpenFile", G.module());
        var a = G.getReportInfo(e);
        a.ver3 = 1;
        reportNew("folderRightMenuClick", a);
        if (window.external && window.external.isFileExist) {
            var i = window.external.isFileExist(t);
            if (i == "false" || i === false) {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                d(e);
                return false;
            }
        } else {}
        if (window.external && window.external.openFolder) {
            var r = window.external.openFolder(t);
            if (r == "success") {} else {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                return false;
            }
        } else {}
    }
    function u(e) {
        if (!e) {
            var t = $(this).parents(".file");
            var a = t.data("path");
            e = i.getData(a);
            console.debug("path:", e);
        }
        var r = e.localpath;
        s.trigger("menu.hide");
        if (typeof r === "string" && r.indexOf("OSRoot") < 0) {
            r = "OSRoot:\\" + r;
        }
        report("clkOpenFile", G.module());
        if (window.external && window.external.isFileExist) {
            var o = window.external.isFileExist(r);
            if (o == "false" || o === false) {
                n.alert(2, "提示", "此文件不存在，可能已被删除或被移动到其他位置");
                d(e);
                return false;
            }
        } else {}
        if (window.external && window.external.openFile) {
            var l = window.external.openFile(r);
            console.log("open file", l);
            if (l == "success") {
                return true;
            } else if (l === "file cannot open") {
                var f = n.confirm(2, "提示", "此文件无法识别并打开，是否在文件夹中查看该文件？");
                if (f.errorCode === 0 && f.ret) {} else {
                    return false;
                }
            }
        }
        if (window.external && window.external.openFolder) {
            var l = window.external.openFolder(r);
            if (l == "success") {} else {
                n.alert(2, "提示", "此文件夹不存在，可能已被删除或被移动到其他位置");
                d(e);
                return false;
            }
        } else {}
    }
    function p() {
        var e = this;
        s.trigger("menu.hide");
        report("clkShowInFolder", G.module());
        while (!e.classList.contains("complete")) {
            e = e.parentNode;
        }
        var t = $(e);
        var a = t.data("path");
        var n = i.getData(a);
        var r = n._localpath || n.localpath || n.localname;
        if (r && r.indexOf("OSRoot:\\") != 0) {
            r = "OSRoot:\\" + r;
        }
        var o = f(r);
        if (o == false) {}
    }
    function v() {
        var e = this;
        s.trigger("menu.hide");
        while (!e.classList.contains("complete")) {
            e = e.parentNode;
        }
        var t = $(e);
        var a = t.data("path");
        var r = i.getData(a);
        $("#boxTitle a").focus();
        if (r) {
            var o = r._localpath || r.localpath || r.localname;
            if (o) {
                if (typeof o === "string" && o.indexOf("OSRoot:\\") != 0) {
                    o = "OSRoot:\\" + o;
                }
                var l = false;
                if (window.external && window.external.openFolder) {
                    var f = window.external.openFolder(o);
                    if (f == "success") {
                        l = true;
                    } else {
                        n.alert(2, "提示", "此文件夹不存在，可能被删除或被移动到其他位置");
                    }
                } else {}
                if (l == false) {
                    d(r);
                }
            } else {
                d(r);
            }
        }
    }
    function m() {
        var e = G.selectRow;
        s.trigger("menu.hide");
        var t = G.getReportInfo(e);
        t.ver3 = 3;
        reportNew("fileRightMenuClick", t);
        if (e) {
            report("clkShowInFolder", G.module());
            var a = e.localpath;
            if (a) {
                if (typeof a === "string" && a.indexOf("OSRoot:\\") != 0) {
                    a = "OSRoot:\\" + a;
                }
                var i = false;
                if (window.external && window.external.openFolder) {
                    var r = window.external.openFolder(a);
                    console.log(r);
                    if (r == "success") {
                        i = true;
                    } else {
                        n.alert(2, "提示", "此文件夹不存在，可能被删除或被移动到其他位置");
                    }
                } else {}
                if (i == false) {
                    d(e);
                }
            } else {
                d(e);
            }
        }
    }
    e.exports = {
        openByFolder: c,
        openByPath: u,
        openByBox: p,
        openByMenu: m,
        openFolderByBoxIco: v,
        changeOpenFolder2Download: d
    };
}, function(e, t, a) {
    "use strict";
    var i = a(133);
    var n = a(54);
    var r = a(59);
    var o = a(78);
    var l = a(153);
    var s = a(184);
    var d = a(50);
    var f = a(133);
    var c = $("#folderPanel");
    var u = $(G.handler);
    function p() {
        console.debug("111111111111111111");
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkRenameFile", G.module());
        var e = G.selectRow;
        var t = G.getReportInfo(e);
        t.ver3 = 7;
        reportNew("fileRightMenuClick", t);
        i.show(c, {
            title: "重命名",
            tips: "请为文件输入新名称",
            action: "file.renameFile",
            showValue: G.selectRow.nameEsc
        });
    }
    function v() {
        var e = c.find(".new-name").val();
        var t = G.selectRow;
        var a = {
            file_id: t.fp,
            app_id: G.appid,
            new_file_name: e + t.suf,
            bus_id: t.busid,
            parent_folder_id: G.nowFolder
        };
        o.renameFile(a).done(function(a) {
            if (a.ec === 0) {
                t.name = e;
                t.nameEsc = l.decode(e);
                t.fname = e + t.suf;
                t.fnameEsc = l.decode(t.fname);
                n.updateFile(t, "rename");
                r.updateRow(t, "rename");
                u.trigger("file.thumbUpdate", t);
            }
            f.hideAll();
        }).fail(function(e) {
            s.showError(e.ec, c);
            report("renameFileError");
        });
    }
    e.exports = {
        showFileRename: p,
        renameFile: v
    };
}, function(e, t, a) {
    "use strict";
    var i = a(185);
    var n = r(i);
    function r(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    function o(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var l = a(54);
    var s = a(78);
    var d = a(59);
    var f = a(50);
    var c = $(G.handler);
    var u = 5485;
    function p(e) {
        var t = document.createElement("div");
        var a = this.getBoundingClientRect();
        var i = function r() {
            var e = document.height;
            var t = G.getDomPanel();
            var a = t[0].scrollHeight;
            if (a + 52 > e) {
                return true;
            }
            return false;
        };
        t.innerHTML = '<div class="img"></div>';
        t.className = "file-animate files-" + e.icon;
        var n = window.innerWidth - a.left - 3;
        if (G.info.isAdmin && G.nowFolder === "/") {
            n += 37;
        }
        if (!i()) {
            n += 10;
        }
        if (G.mac) {
            n = 177;
        }
        t.style.right = n + "px";
        t.style.top = a.top - 20 + "px";
        document.body.appendChild(t);
        setTimeout(function() {
            document.body.removeChild(t);
        }, 1500);
    }
    function v(e, t) {
        var a = this;
        if (e) {
            var i = function() {
                var i = G.getReportInfo(e);
                if (t === 1) {
                    i.ver7 = G.module() === 3 ? 2 : 1;
                    reportNew("doubleClickFile", i);
                } else if (t === 2) {
                    i.ver3 = 1;
                    reportNew("fileRightMenuClick", i);
                }
                if (e.isDown && t !== 0) {
                    n.edit(e);
                    return {
                        v: undefined
                    };
                }
                var r = i;
                r.ver1 = G.module();
                r.ver2 = 1;
                r.ver3 = i.ver4;
                r.ver4 = i.ver5;
                r.ver5 = t;
                r.ver7 = G.info.role;
                reportNew("fileDownload", r);
                var o = e.filepath;
                var l = e.fnameEsc;
                var c = e.size;
                e.isDowning = true;
                var u = {
                    bs: e.t,
                    fp: e.fp
                };
                var p = a;
                s.checkOneFile(u).done(function(t) {
                    if (t.ec === 0) {
                        d.updateRow(e);
                        f.addDownloadTask(o, l, c, true, false);
                    } else if (t.ec === 0 && t.audit === 3) {
                        f.alert("该文件因多次被举报为色情文件，已被删除");
                    }
                }).fail(function(e) {});
            }();
            if ((typeof i === "undefined" ? "undefined" : o(i)) === "object") return i.v;
        }
    }
    function m() {
        var e = G.selectRow;
        v(e, 2);
    }
    function h() {
        var e = $(this);
        var t = e.data("path");
        var a = l.getData(t);
        if (a.safeType) {
            var i = G.getReportInfo(a);
            i.ver3 = i.ver4;
            i.ver4 = i.ver5;
            i.ver5 = a.isDown ? 2 : 1;
            reportNew("blackTips", i);
            f.alert(2, "提示", "该文件存在安全风险，无法正常使用");
        } else {
            v(a, 1);
        }
    }
    function g() {
        var e = $(this).closest(".list-item");
        var t = e.data("path");
        var a = l.getData(t);
        G.saveasList[a.filepath] = 1;
        v(a, 0);
    }
    function w() {
        var e = this;
        var t = G.selectRow;
        var a = this;
        report("clkDownloadBtn", G.module());
        if (t) {
            (function() {
                var a = t.filepath;
                var i = t.fnameEsc;
                var n = t.size;
                t.isDowning = true;
                var r = {
                    bs: t.t,
                    fp: t.fp
                };
                var o = e;
                s.checkOneFile(r).done(function(e) {
                    if (e.ec === 0) {
                        p.call(o, t);
                        d.updateRow(t);
                        f.addDownloadTask(a, i, n, true);
                    } else if (e.ec === 0 && e.audit === 3) {
                        f.alert("该文件因多次被举报为色情文件，已被删除");
                    }
                }).fail(function(e) {});
            })();
        }
    }
    function b(e) {
        var t = function r(e) {
            var t = e.filepath;
            var a = e.fnameEsc;
            var i = e.size;
            var n = {
                bs: e.t,
                fp: e.fp
            };
            s.checkOneFile(n).done(function(e) {
                if (e.ec === 0) {
                    f.addDownloadTask(t, a, i, true);
                } else if (e.ec === 0 && e.audit === 3) {
                    f.alert("该文件因多次被举报为色情文件，已被删除");
                }
            }).fail(function(e) {});
        };
        for (var a = 0, i = e.length; a < i; a++) {
            var n = e[a];
            G.saveasList[n.filepath] = 1;
            t(n);
        }
    }
    e.exports = {
        download: w,
        downloadByDom: h,
        downloadByMenu: m,
        downloadByBtn: g,
        downloadBatch: b
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(50);
    var r = a(148);
    var o = $(G.handler);
    function l() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkRepost", G.module());
        var e = G.selectRow;
        var t = G.getReportInfo(e);
        t.ver3 = 4;
        reportNew("fileRightMenuClick", t);
        if (e) {
            var a = e.filepath;
            var i = e.fnameEsc;
            var r = e.size;
            n.forwardFile(i, a, r);
            o.trigger("menu.hide");
        } else {}
    }
    function s(e) {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkPhone", G.module());
        var t = G.selectRow;
        var a = G.getReportInfo(t);
        a.ver3 = 5;
        reportNew("fileRightMenuClick", a);
        if (t) {
            var i = t.filepath;
            var r = t.fnameEsc;
            var l = t.size;
            var s = n.forwardFileToDataLine(r, i, l);
            console.log(s);
            o.trigger("menu.hide");
        } else {}
    }
    e.exports = {
        forward: l,
        toMobile: s
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(78);
    var r = a(50);
    var o = a(59);
    var l = a(109);
    var s = a(59);
    var d = a(148);
    var f = 2;
    var c = a(19);
    var u = a(24);
    var p = $(G.handler);
    function v() {
        p.trigger("menu.hide");
        report("clkDeleteFile", G.module());
        var e = G.selectRow;
        if (e) {
            var t = G.getReportInfo(e);
            t.ver3 = 8;
            reportNew("fileRightMenuClick", t);
            var a = r.confirm(2, "提示", "你确定要删除文件" + e.fnameEsc + "吗?");
            if (a.errorCode === 0 && a.ret) {
                var d = {
                    bus_id: parseInt(e.busid),
                    file_id: e.fp,
                    app_id: 4,
                    parent_folder_id: G.nowFolder || "/"
                };
                n.deleteFile(d).done(function(t) {
                    i.remove(e.filepath);
                    o.removeRow(e);
                    c.setClist(e, "delete");
                    i.updateAllNum({
                        files: [ e ],
                        action: "remove"
                    });
                    G.file.capacityused = l.getSize(G.file.cu);
                    s.renderSpace();
                    p.trigger("toast.show", {
                        type: "suc",
                        text: "删除成功"
                    });
                    u.init(G.file.isTooMany || G.file.isFull);
                    if (e.safeType) {
                        var a = G.getReportInfo(e);
                        a.ver6 = a.ver3;
                        a.ver3 = a.ver4;
                        a.ver4 = a.ver5;
                        a.ver5 = e.size;
                        reportNew("blackDelete", a);
                    }
                }).fail(function(e) {
                    r.alert(2, "提示", "删除失败");
                    report("delFileError");
                });
            }
        }
    }
    function m(e, t) {
        p.trigger("menu.hide");
        var a = [];
        var d = {};
        var v = 1;
        var m = 0;
        var h = 0;
        var g = function x() {
            m++;
            if (m === v) {
                G.scrollHandler && G.scrollHandler();
            }
        };
        var w = function k() {
            var e = arguments.length <= 0 || arguments[0] === undefined ? [] : arguments[0];
            if (e.length === 0) {
                return;
            }
            var a = {};
            var d = [];
            for (var f = 0, p = e.length; f < p; f++) {
                d[f] = {
                    gc: parseInt(G.info.gc),
                    app_id: G.appid,
                    bus_id: e[f].busid,
                    file_id: e[f].fp,
                    parent_folder_id: G.nowFolder || "/"
                };
            }
            a.file_list = JSON.stringify({
                file_list: d
            });
            n.deleteFile(a).done(function(a) {
                var n = [];
                if (a.fail) {
                    n = a.fail;
                    for (var r = e.length - 1; r >= 0; r--) {
                        if ($.inArray(e[r].fp, n)) {
                            e.splice(r, 1);
                        }
                    }
                }
                report("batchDeleteSuc");
                var d = e.length;
                h += d;
                e.forEach(function(e) {
                    o.removeRow(e);
                    i.remove(e.filepath);
                    c.setClist(e, "delete");
                    if (e.safeType) {
                        var t = G.getReportInfo(e);
                        t.ver6 = t.ver3;
                        t.ver3 = t.ver4;
                        t.ver4 = t.ver5;
                        t.ver5 = e.size;
                        reportNew("blackDelete", t);
                    }
                });
                i.updateAllNum({
                    files: e,
                    action: "remove"
                });
                G.file.capacityused = l.getSize(G.file.cu);
                s.renderSpace();
                g(h);
                if (m === v) {
                    t(h);
                }
                u.init(G.file.isTooMany || G.file.isFull, "delete");
            }).fail(function(e) {
                r.alert(2, "提示", "删除失败");
                $(G.handler).trigger("panel.hideAll");
                report("delFileError");
            });
        };
        e.forEach(function(e) {
            if (e.remove) {
                a.push(e);
                d[e.fp] = e;
            }
        });
        v = Math.ceil(a.length / f);
        if (v === 1) {
            w(a);
        } else {
            for (var b = 0; b < v; b++) {
                var y = a.slice(b * f, (b + 1) * f);
                w(y);
            }
        }
        return true;
    }
    e.exports = {
        removeOne: v,
        removeBatch: m
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(50);
    var r = a(154);
    var o = $(G.handler);
    var l = [ "图片" ];
    function s(e) {
        e.usedTime++;
        o.trigger("toast.hide");
        n.preview(e.previewObj.url);
    }
    function d() {
        var e = arguments.length <= 0 || arguments[0] === undefined ? false : arguments[0];
        var t = undefined;
        var a = $(this);
        var d = undefined;
        if (e) {
            t = e;
        } else {
            var f = a.data("path");
            t = i.getFile(f);
            if (!t) {
                var c = G.selectRow.path;
                t = i.getFile(c);
            }
            if (!t) {
                var u = G.selectRow.path;
                t = i.getFile(u);
            }
        }
        if (!t) {
            return;
        }
        if (t.safeType) {
            var p = G.getReportInfo(t);
            p.ver3 = p.ver4;
            p.ver4 = p.ver5;
            p.ver5 = t.isDown ? 2 : 1;
            reportNew("blackTips", p);
            n.alert(2, "提示", "该文件存在安全风险，无法正常使用");
            return;
        }
        var v = t.filepath;
        var m = t.remotetype;
        var h = t.fnameEsc || t.fname;
        var g = t.size;
        var w = t.filetype;
        if ($.inArray(w, l) >= 0) {
            if (g > 20 * 1024 * 1024) {
                n.alert(2, "提示", "图片太大不支持预览，请直接下载");
            } else {
                t.usedTime++;
                o.trigger("toast.show", {
                    type: "wait",
                    text: "正在加载预览图…"
                });
                r.getOneThumb(t, s);
            }
        } else {
            try {
                n.previewFile(v, h);
            } catch (b) {
                console.log(b);
            }
        }
    }
    function f() {
        if (this.classList && this.classList.contains("disable")) {
            return;
        }
        o.trigger("menu.hide");
        var e = G.selectRow;
        if (e) {
            d(e);
        }
    }
    e.exports = {
        preview: d,
        menupreview: f
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        folderTree: a(186),
        showFolderTreePanel: a(133).showFolderTreePanel
    };
    var n = a(78);
    var r = a(59);
    var o = a(184);
    var l = a(148);
    var s = a(149);
    var d = a(123);
    var f = a(50);
    var c = $(G.handler);
    var u = a(54);
    var p = a(112);
    var v = a(17);
    var m = 10;
    function h(e) {
        if (e) {
            var t = +new Date();
            e.mt = Math.floor(t / 1e3);
            e.mtStr = p.getDateStr(e.mt);
            e.mtoStr = p.getorcDateStr(e.mt);
            r.removeFold(e);
            r.appendFold(e);
        }
        l["panel.close"]();
    }
    function g() {
        if (G.file.isFull) {
            return v.show("alert", "文件数已达到上限");
        }
        if (this.classList && this.classList.contains("disable")) {
            return;
        }
        var e = G.selectRows;
        if (!e) {
            badjsReport.info("无选择目标");
            return;
        }
        var t = e[0];
        var a = G.getReportInfo(t);
        if (e.length > 1) {
            reportNew("chooseRightMenuClick", a);
        } else {
            a.ver3 = 5;
            reportNew("fileRightMenuClick", a);
        }
        var n = G.folderMap()[G.nowFolder];
        var r = {
            title: "移动文件",
            firstFileName: e[0].fname,
            fileNum: e.length,
            action: "移动到：",
            destFolder: G.nowFolder === "/" ? "群文件" : n.fname,
            okAction: "file.move"
        };
        i.showFolderTreePanel(r);
        var o = $("#containerFolderTreePanel");
        o.find(".active .aria-hide").eq(0).focus();
        report("folderTree", 1);
        report("clkFolderMove");
    }
    function w(e, t, a) {
        var i = [];
        var s = {};
        if (e.length === 1) {
            var p = u.getData(e[0].filepath);
            if (p && p.safeType) {
                f.alert(2, "提示", "该文件存在安全风险，无法正常使用");
                return;
            }
        } else {
            for (var v = e.length; v--; ) {
                var p = u.getData(e[v].filepath);
                if (p && p.safeType) {
                    e.splice(v, 1);
                }
            }
        }
        for (var g = e.length - 1; g >= 0; g--) {
            var w = e[g];
            if (G.info.isAdmin || G.info.uin === w.uin) {
                i.push({
                    file_id: w.fp,
                    bus_id: parseInt(w.busid),
                    parent_folder_id: w.parentId,
                    dest_folder_id: t,
                    app_id: G.appid,
                    gc: G.info.gc
                });
                s[e[g].fp] = e[g];
            }
        }
        d.exit();
        if (e.length !== i.length) {
            try {
                f.alert(2, "提示", "没有管理该文件的权限，操作失败");
            } catch (b) {
                console.log(b);
            }
            return;
        }
        var y = function _() {
            T++;
            if (T >= F) {
                c.trigger("toast.hide");
            }
        };
        var x = function C() {
            var e = arguments.length <= 0 || arguments[0] === undefined ? [] : arguments[0];
            if (e.length === 0) {
                return;
            }
            n.moveFile(e).done(function(i) {
                y();
                var n = e;
                if (i.fail) {
                    var o = [];
                    try {
                        o = JSON.parse(i.fail).fail;
                    } catch (l) {}
                    for (var d = o.length - 1; d >= 0; d--) {
                        if (s[o[d]]) {
                            n.splice(d, 1);
                        }
                    }
                }
                if (e.length > 1) {
                    report("batchMoveSuc");
                    if (a) {
                        reportNew("chooseDrag", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 1
                        });
                    }
                } else {
                    report("moveFileSuc");
                    if (a) {
                        reportNew("chooseDragSinge", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 1
                        });
                    }
                }
                for (var d = n.length - 1; d >= 0; d--) {
                    var f = n[d];
                    var c = "/" + f.bus_id + f.file_id;
                    f = G.fileMap()[c];
                    f.parentId = t;
                    u.updateFile(f, "rename");
                    r.removeRow(f);
                }
                var p = undefined;
                if (p = G.folderMap()[t]) {
                    p.filenum += n.length;
                    $('[id="' + p.domid + '"]').find(".file-size").html(p.filenum + "个文件");
                }
                h(p);
                return;
            }).fail(function(t) {
                y();
                o.showError(t.ec);
                report("showMoveFail");
                report("moveFileError");
                if (a) {
                    if (e.length > 1) {
                        reportNew("chooseDrag", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 2
                        });
                    } else {
                        reportNew("chooseDragSinge", {
                            ver1: 1,
                            ver2: G.info.isAdmin ? 1 : 2,
                            ver5: 2
                        });
                    }
                }
                console.log("fail", t);
            });
        };
        var k = i.length;
        var F = Math.ceil(k / m);
        var T = 0;
        c.trigger("toast.show", {
            type: "wait",
            text: "正在移动文件",
            autoHide: false
        });
        if (F) {
            for (var v = 0; v < F; v++) {
                var S = i.slice(v * m, (v + 1) * m);
                x(S);
            }
        } else {
            y();
            l["panel.close"]();
        }
        return true;
    }
    function b() {
        s["folderTree.create"](null, function() {
            if (!G.selectRows) {
                return;
            }
            var e = G.folderTree.selected.id;
            if (e === G.nowFolder) {
                console.log("can not move to the same folder");
                c.trigger("toast.show", {
                    type: "alert",
                    text: "文件已在目标位置"
                });
                return;
            }
            w(G.selectRows, e);
        });
    }
    function y(e, t, a) {
        w(e, t, a);
    }
    e.exports = {
        showMove: g,
        move: b,
        movelist: y
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(163);
    var r = $(G.handler);
    function o() {
        var e = G.selectRow;
        report("clkJubao");
        if (e) {
            var t = G.getReportInfo(e);
            t.ver3 = 9;
            reportNew("fileRightMenuClick", t);
            var a = "http://jubao.qq.com/cn/jubao?appname=im&subapp=group_file&jubaotype=article";
            if (G.checkHttps()) {
                a = "https://proxy.qun.qq.com/tx_tls_gate=jubao.qq.com/cn/jubao?appname=im&subapp=group_file&jubaotype=article";
            }
            a += "&impeachuin=" + G.info.uin;
            a += "&uin=" + e.uin;
            a += "&fid=" + e.fp;
            a += "&fname=" + encodeURIComponent(e.fnameEsc);
            a += "&ut=" + e.ct;
            a += "&fs=" + e.size;
            a += "&dt=" + e.down;
            a += "&t=" + e.t;
            a += "&mt=" + e.mt;
            a += "&exp=" + e.exp;
            a += "&gid=" + G.info.gc;
            n.show(encodeURI(a));
        }
        r.trigger("menu.hide");
    }
    e.exports = o;
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = $("#selectFileNum");
    function r(e) {
        n.text(e);
    }
    function o(e) {
        var t = false;
        var a = false;
        for (var n = 0, r = e.length; n < r; n++) {
            var o = e[n];
            var l = o.value;
            var s = i.getData(l);
            if (s.admin) {
                t = true;
            }
            if (!s.succ) {
                a = true;
            }
        }
        if (!t) {
            $("#batchDel").addClass("disabled");
            $("#batchMove").addClass("disabled");
        } else {
            $("#batchDel").removeClass("disabled");
            $("#batchMove").removeClass("disabled");
        }
        if (a) {
            $("#batchDown").removeClass("disabled");
        } else {
            $("#batchDown").addClass("disabled");
        }
    }
    function l() {
        if (G.mac) {
            return;
        }
        var e = G.getDomPanel()[0];
        var t = e.querySelectorAll(".cbox:checked");
        if (t.length) {
            report("showSelectAll");
            report("showBatch");
            $(".nav").removeClass("hide");
            $("body").addClass("batch-mode");
            $(".file.list-item").attr("data-action", "file.select");
            o(t);
            r(t.length);
        } else {
            $("body").removeClass("batch-mode");
            $(".file.list-item").attr("data-action", "");
        }
    }
    function s() {
        $("body").removeClass("batch-mode");
        $(".cbox").prop("checked", false);
        r(0);
    }
    function d() {
        var e = G.getDomPanel()[0];
        if (this.checked) {
            report("clkSelectAll");
            report("clkBatch");
            G.getDomPanel().find(".cbox").prop("checked", true);
            var t = e.querySelectorAll(".cbox:checked");
            r(t.length);
        } else {
            s();
        }
    }
    function f() {
        var e = G.getDomPanel()[0];
        var t = $(this).find(".cbox");
        if (!t.prop("checked")) {
            t.prop("checked", true);
        } else {
            t.prop("checked", false);
        }
        var a = e.querySelectorAll(".cbox:checked");
        r(a.length);
    }
    var c = $("#downloadFile button");
    function u(e) {
        if (e) {
            c.attr("class", "icons-download-batch");
        } else {
            c.attr("class", "icons-download-batch-disabled disabled");
        }
    }
    e.exports = {
        check: l,
        exit: s,
        selectAll: d,
        select: f,
        changeDownLoadBtn: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(121);
    var n = a(117);
    var r = a(119);
    var o = a(125);
    var l = a(54);
    var s = a(133);
    var d = a(123);
    var f = $("#batchPanel");
    var c = a(19);
    var u = G.folderVersion;
    var p = 0;
    var v = 0;
    var m = 0;
    var h = 0;
    var g = [];
    function w(e) {
        if (c.getTips()) {} else {
            report("showOldVersion");
            b();
        }
    }
    function b() {
        $("#updateQQ").addClass("open");
        $("#updateQQTips").text("当前版本不支持批量另存功能，请升级QQ至最新版本后体验");
        $("#updateQQ").find("input.btn-notips").attr("data-action", "panel.close");
    }
    function y(e, t) {
        switch (e) {
          case 1:
            return '您选择了<span class="red">' + p + '</span>个文件,其中<span  class="red">' + m + '</span>个文件可以删除<br>您确定要删除这<span  class="red">' + m + "</span>个文件吗?";
            break;

          case 2:
            return "正在删除文件";
            break;

          case 3:
            return '已经成功删除<span class="red">' + t + "</span>个文件";
            break;
        }
    }
    function x() {
        p = 0;
        v = 0;
        m = 0;
        g = [];
    }
    function k() {
        x();
        var e = G.onlyGetDom().find(".selected");
        var t = [];
        p = e.length;
        e.each(function() {
            var e = $(this).data("path");
            var a = l.getData(e);
            if (a) {
                if (a.remove) {
                    m++;
                }
                if (!a.succ) {
                    h++;
                }
                t.push(a);
            }
        });
        return t;
    }
    function F() {
        if (this.classList.contains("disabled")) {
            return;
        }
        g = k();
        var e = G.getReportInfo(g[0]);
        e.ver3 = 3;
        reportNew("chooseRightMenuClick", e);
        s.showBatchPanel(f, {
            title: "批量删除",
            action: "batch.removeAction",
            text: y(1)
        });
    }
    function T() {
        report("batchDelete");
        s.showBatchPanel(f, {
            title: "批量删除",
            hideAll: true,
            text: y(2)
        });
        d.exit();
        r.removeBatch(g, function(e) {
            s.showBatchPanel(f, {
                title: "批量删除",
                action: "batch.removeAction",
                hideOk: true,
                closeText: "关闭",
                text: y(3, e)
            });
            x();
        });
    }
    function S() {
        if (this.classList.contains("disabled")) {
            return;
        }
        report("batchMove");
        g = k();
        i.showMove();
        return;
    }
    function _() {
        report("batchSaveAs");
        var e = function t() {
            k();
            var e = G.selectRows;
            d.exit();
            var t = [];
            for (var a = e.length - 1; a >= 0; a--) {
                var i = e[a];
                t.push({
                    filepath: i.filepath,
                    filename: i.fnameEsc,
                    fname: i.fname,
                    filetype: i.filetype,
                    filesize: i.size,
                    domid: i.domid,
                    orcType: i.orcType
                });
            }
            o.saveBatch(t);
        };
        if (G.info.version < u) {
            w(e);
        } else {
            e();
        }
    }
    e.exports = {
        remove: F,
        removeAction: T,
        move: S,
        save: _
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(54);
    var r = a(78);
    var o = $(G.handler);
    G.saveasList = {};
    function l(e) {
        var t = e || G.selectRow;
        report("clkSaveAs", G.module());
        try {
            var a = G.getReportInfo(t);
            var n = a;
            a.ver3 = 2;
            reportNew("fileRightMenuClick", a);
            n.ver1 = G.module();
            n.ver2 = 1;
            n.ver3 = a.ver4;
            n.ver4 = a.ver5;
            n.ver5 = 3;
            n.ver7 = G.info.role;
            reportNew("fileDownload", n);
        } catch (l) {
            console.info(l);
        }
        if (t && t.orcType === 1) {
            if (t.inDown) {} else {
                (function() {
                    var e = t.filepath;
                    var a = t.fnameEsc;
                    var n = t.size;
                    var l = {
                        bs: t.t || t.busid,
                        fp: t.fp
                    };
                    r.checkOneFile(l).done(function(t) {
                        if (t.ec === 0) {
                            var r = i.addDownloadTask(e, a, n);
                            G.saveasList[e] = 1;
                        } else if (t.ec === 0 && t.audit === 3) {
                            i.alert("该文件因多次被举报为色情文件，已被删除");
                        }
                    }).fail(function(e) {});
                    o.trigger("menu.hide");
                })();
            }
        }
    }
    function s(e) {
        var t = e[0];
        if (t) {
            var a = G.getReportInfo(t);
            a.ver3 = 1 + "";
            reportNew("chooseRightMenuClick", a);
            var n = a;
            n.ver1 = G.module();
            n.ver2 = 1;
            n.ver3 = a.ver4;
            n.ver4 = a.ver5;
            n.ver5 = 5;
            n.ver7 = G.info.role;
            console.log(t, a, n);
            reportNew("fileDownload", n);
        }
        for (var r in e) {
            var o = e[r];
            G.saveasList[o.filepath] = 1;
        }
        var l = {
            files: e,
            save2default: 0
        };
        i.addMultiDownloadTasks(JSON.stringify(l));
    }
    e.exports = {
        save: l,
        saveBatch: s
    };
}, function(e, t, a) {
    "use strict";
    var i = a(59);
    var n = {};
    n.byUin = function() {
        var e = $(this).data("uin");
        var t = this.innerHTML;
        var a = function n() {
            G.module(2);
            $("#navTopFolder").addClass("selected");
            $("#createFolder").hide();
            $("#fileNum").addClass("hide").attr("data-action", "menu.filenum");
            $("#headerLine").text(">");
            $("#folderName").html('<div style="display: -webkit-box;"><div class="uploader-name">' + t + "</div><div>上传的文件</div></div>").removeClass("hide");
            $("#normalNav").removeClass("hide");
            if (G.mac) {
                $(".mac-file-top").addClass("user-module");
            }
        };
        G.module(2);
        i.getList({
            paramsFilter: {
                filterUin: e,
                filterCode: 3
            },
            succ: a,
            renderParams: {
                getByUinHide: true,
                uploaderHide: true
            }
        })();
    };
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(78);
    var r = a(184);
    var o = $(G.handler);
    var l = {
        "1": "没有登陆或登陆态失效",
        "2": "系统内部错误",
        "7": "没有群权限",
        "21": "不是上传者或群主不能转永久",
        "22": "不能跨群转永久文件",
        "23": "登录态校验失败",
        "24": "群成员关系校验失败",
        "25": "容量满，可以升级",
        "26": "容量满，不能再升级",
        "27": "要转存的文件不存在",
        "28": "永久空间容量超限"
    };
    function s() {
        if (this.classList.contains("disable")) {
            return;
        }
        report("clkForever");
        var e = G.selectRow;
        if (e && e.remoteType === 2) {
            var t = e.filepath;
            var a = {
                fp: t
            };
            n.setPermanent(a).done(function(t) {
                if (t.ec === 0) {
                    var a = "/102" + t.fp;
                    e.newFilePath = a;
                    e.remoteType = 1;
                    e.fp = t.fp;
                    e.temp = false;
                    i.updateFile(e, "permanent");
                    o.trigger("file.dataUpdate", e);
                    o.trigger("toast.show", {
                        type: "suc",
                        text: "转存成功"
                    });
                }
            }).fail(function(e) {
                console.log(e);
                r.showError(e.ec);
            });
        } else {
            console.log("文件不存在或者不是临时文件");
        }
        o.trigger("menu.hide");
    }
    e.exports = s;
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(78);
    var r = a(158);
    var o = a(54);
    var l = a(15);
    G.renderOtherGroupResultFuncSingtons = {};
    var s = undefined;
    function d() {
        var e = true;
        return function(e, t) {
            var a = G.getDomPanel();
            if (!e) {
                return;
            }
            var i = [ t ];
            var n = e.file[0];
            var r = n.domid;
        };
    }
    function f(e, t) {
        e = e || {};
        var a = e.busId;
        var r = e.fileId;
        n.getFileAttr({
            bus_id: a,
            file_id: r
        }).done(function(e) {
            var a = [];
            if (i(e.file_info) === "object") {
                e.file_info.upload_size = e.file_info.size;
            } else {
                return;
            }
            var n = e.file_info;
            n.proId = n.id;
            n.id = r;
            a.push(n);
            a = o.setFileList(a);
            d()(a, t);
        }).fail(function(e) {
            console.log("fail", e);
        });
    }
    window.getFileAttr = f;
    e.exports = f;
}, function(e, t, a) {
    "use strict";
    var i = {};
    var n = a(78);
    var r = a(54);
    var o = a(15);
    e.exports = i;
    G.searchFuncSingtons = {};
    i.search = function l(e) {
        var e = e || {};
        var t = e.succ;
        var a = e.fail;
        var i = e.beforeRequest;
        var r = e.isNew;
        var l = o.extend({
            key_word: "",
            search_type: 0,
            app_id: 4
        }, e.searchParams);
        if (G.mac) {
            l.app_id = 7;
        }
        var s = false;
        var d = JSON.stringify(l);
        if (r || G.searchFuncSingtons[d] == undefined) {
            G.searchFuncSingtons[d] = function() {
                var e = 25;
                var t = undefined;
                var a = 0;
                return function(o, f) {
                    if (a) {
                        console.log("no more items");
                        return;
                    }
                    if (s === true) {
                        return;
                    }
                    l["cookie"] = t;
                    l["count"] = e;
                    i && i();
                    s = true;
                    n.search(l).done(function(e) {
                        if (r) {
                            $("#searchReasult").text(e.total);
                            $(".nav").addClass("hide");
                            $("#searchNav").removeClass("hide");
                        }
                        a = e.is_end;
                        t = e.cookie;
                        o && o(e, d);
                        s = false;
                        $("#fileNum").addClass("hide");
                        $("#searchDom").css("display", "flex");
                        $("#folderName").addClass("hide");
                    }).fail(function(e) {
                        f && f(e);
                        s = false;
                        $("#searchReasult").text(0);
                        $("#searchDom").css("disolay", "none");
                        $("#folderName").addClass("hide");
                    });
                };
            }();
        }
        G.searchFuncSingtons[d](t, a);
    };
    window.search = i.search;
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function w(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '<%\n		var group = locals.data;\n		if(group.first){\n%>\n	<div class="group-title" data-gc="<%=group.gc%>">\n		<% if(group.self){ %>\n			<span class="group-name">本群搜索结果</span> <span>(<%=group.total%>)</span>\n		<% }else{%>\n			<span class="group-name"><%=group.name%></span> <span>(<%=group.total%>)</span>\n		<% } %>\n	</div>\n<%}%>\n	<div class="group-result group<%=group.gc%>">\n<%\n		for(var i = 0,l = group.list.length;i<l;i++){\n			var item = group.list[i];\n%>\n	<div class="file list-item <%=item.icon%> <%if(item.remoteType===2){%>temp<%}%> <%if(item.succ){%>succ<%}%>" id="search<%=item.domid%>" data-path="<%=item.filepath%>" <%if(!locals.renderParams){%>id="<%=item.domid%>"<%}%> <%if(!group.self){%> data-dbaction="openGroupFile" data-uin="<%- item.gc %>"<%}else if(item.preview){%>data-dbaction="file.preview"<%}else{%>data-dbaction="file.downloadByDom"<%}%> data-action="list.select" >\n		<div class="item-name-wrap item-name-adjust" title="<%- item.fname %>&#10;创建时间：<%=item.ctoStr%>">\n			<div class="item-name" tabindex="-1" >\n				<div class="file-icons" data-path="<%=item.filepath%>" <%if(item.preview){%>data-dbaction="file.preview"<%}%>>\n					<div class="filesmall-<%=item.icon%> <%if(item.previewObj){%>thumb<%}%> drag-dom" <%if(item.previewObj){%>style="background-image:url(<%=item.previewObj.url%>);"<%}%>></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom"><%- item.name %><%-item.suf%></span>\n			</div>\n			<% if(item.canEdit || item.remoteType === 2) { %>\n				<div class="item-tags">\n					<%if(item.canEdit){%><span class="can-edit"></span><%}%>\n					<%if(item.remoteType ===2){%><span class="tmp"></span><%}%>\n					&nbsp;\n				</div>\n			<% } %>\n		</div>\n		<div class="item-time" title="上传时间：<%=item.ctStr%>">\n			<span class="drag-dom">\n			<% if(group.self){ %>\n				<%= item.ctStr %>\n			<%}else{%>\n				<%= item.ctStr %>\n			<%}%>\n			</span>\n		</div>\n		<div class="item-size" title="文件大小：<%= item.sizeStr%>">\n			<span class="drag-dom"><%= item.sizeStr%></span>\n		</div>\n		<div class="item-user" title="上传者：<%-item.nick%> (<%=item.uin%>)"><span class="drag-dom"><%- item.nick%></span></div>\n		<div class="aria-hide">\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件<%=item.fname%>" data-action="file.forward" tabindex="3">转发</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件到手机<%=item.fname%>" data-action="file.forwardMobile" tabindex="3">转发文件到手机</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="在文件夹中显示<%=item.fname%>" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="重命名文件<%=item.fname%>" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="转存为永久文件<%=item.fname%>" data-action="file.permanent" tabindex="3">转存为永久文件</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="移动文件<%=item.fname%>" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="举报文件<%=item.fname%>" data-action="file.jubao" tabindex="3">举报文件</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="删除文件<%=item.fname%>" data-action="file.delete" tabindex="3">删除</a>\n		</div>\n		<div class="item-source">\n			<span>\n			<% if(group.self){ %>\n				&nbsp;\n			<%}else{%>\n				<span class="group-code" title="来源:<%-item.gname%>" data-action="openGroupInfoCard" data-uin="<%- item.gc %>"><%-item.gname%></span>\n			<%}%>\n			</span>\n		</div>\n	</div>\n<%\n	}\n%>\n	</div>\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\searchRow.ejs";
        try {
            var c = [], u = c.push.bind(c);
            var p = e.data;
            if (p.first) {
                s = 4;
                u('\n	<div class="group-title" data-gc="');
                s = 5;
                u(t(p.gc));
                u('">\n		');
                s = 6;
                if (p.self) {
                    u('\n			<span class="group-name">本群搜索结果</span> <span>(');
                    s = 7;
                    u(t(p.total));
                    u(")</span>\n		");
                    s = 8;
                } else {
                    u('\n			<span class="group-name">');
                    s = 9;
                    u(t(p.name));
                    u("</span> <span>(");
                    u(t(p.total));
                    u(")</span>\n		");
                    s = 10;
                }
                u("\n	</div>\n");
                s = 12;
            }
            u('\n	<div class="group-result group');
            s = 13;
            u(t(p.gc));
            u('">\n');
            s = 14;
            for (var v = 0, m = p.list.length; v < m; v++) {
                var h = p.list[v];
                s = 17;
                u('\n	<div class="file list-item ');
                s = 18;
                u(t(h.icon));
                u(" ");
                if (h.remoteType === 2) {
                    u("temp");
                }
                u(" ");
                if (h.succ) {
                    u("succ");
                }
                u('" id="search');
                u(t(h.domid));
                u('" data-path="');
                u(t(h.filepath));
                u('" ');
                if (!e.renderParams) {
                    u('id="');
                    u(t(h.domid));
                    u('"');
                }
                u(" ");
                if (!p.self) {
                    u(' data-dbaction="openGroupFile" data-uin="');
                    u(h.gc);
                    u('"');
                } else if (h.preview) {
                    u('data-dbaction="file.preview"');
                } else {
                    u('data-dbaction="file.downloadByDom"');
                }
                u(' data-action="list.select" >\n		<div class="item-name-wrap item-name-adjust" title="');
                s = 19;
                u(h.fname);
                u("&#10;创建时间：");
                u(t(h.ctoStr));
                u('">\n			<div class="item-name" tabindex="-1" >\n				<div class="file-icons" data-path="');
                s = 21;
                u(t(h.filepath));
                u('" ');
                if (h.preview) {
                    u('data-dbaction="file.preview"');
                }
                u('>\n					<div class="filesmall-');
                s = 22;
                u(t(h.icon));
                u(" ");
                if (h.previewObj) {
                    u("thumb");
                }
                u(' drag-dom" ');
                if (h.previewObj) {
                    u('style="background-image:url(');
                    u(t(h.previewObj.url));
                    u(');"');
                }
                u('></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom">');
                s = 25;
                u(h.name);
                u(h.suf);
                u("</span>\n			</div>\n			");
                s = 27;
                if (h.canEdit || h.remoteType === 2) {
                    u('\n				<div class="item-tags">\n					');
                    s = 29;
                    if (h.canEdit) {
                        u('<span class="can-edit"></span>');
                    }
                    u("\n					");
                    s = 30;
                    if (h.remoteType === 2) {
                        u('<span class="tmp"></span>');
                    }
                    u("\n					&nbsp;\n				</div>\n			");
                    s = 33;
                }
                u('\n		</div>\n		<div class="item-time" title="上传时间：');
                s = 35;
                u(t(h.ctStr));
                u('">\n			<span class="drag-dom">\n			');
                s = 37;
                if (p.self) {
                    u("\n				");
                    s = 38;
                    u(t(h.ctStr));
                    u("\n			");
                    s = 39;
                } else {
                    u("\n				");
                    s = 40;
                    u(t(h.ctStr));
                    u("\n			");
                    s = 41;
                }
                u('\n			</span>\n		</div>\n		<div class="item-size" title="文件大小：');
                s = 44;
                u(t(h.sizeStr));
                u('">\n			<span class="drag-dom">');
                s = 45;
                u(t(h.sizeStr));
                u('</span>\n		</div>\n		<div class="item-user" title="上传者：');
                s = 47;
                u(h.nick);
                u(" (");
                u(t(h.uin));
                u(')"><span class="drag-dom">');
                u(h.nick);
                u('</span></div>\n		<div class="aria-hide">\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件');
                s = 49;
                u(t(h.fname));
                u('" data-action="file.forward" tabindex="3">转发</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="转发文件到手机');
                s = 50;
                u(t(h.fname));
                u('" data-action="file.forwardMobile" tabindex="3">转发文件到手机</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="在文件夹中显示');
                s = 51;
                u(t(h.fname));
                u('" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="重命名文件');
                s = 52;
                u(t(h.fname));
                u('" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="转存为永久文件');
                s = 53;
                u(t(h.fname));
                u('" data-action="file.permanent" tabindex="3">转存为永久文件</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="移动文件');
                s = 54;
                u(t(h.fname));
                u('" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="举报文件');
                s = 55;
                u(t(h.fname));
                u('" data-action="file.jubao" tabindex="3">举报文件</a>\n			<a href="javascript:void(0)" data-focus="file.aria" aria-label="删除文件');
                s = 56;
                u(t(h.fname));
                u('" data-action="file.delete" tabindex="3">删除</a>\n		</div>\n		<div class="item-source">\n			<span>\n			');
                s = 60;
                if (p.self) {
                    u("\n				&nbsp;\n			");
                    s = 62;
                } else {
                    u('\n				<span class="group-code" title="来源:');
                    s = 63;
                    u(h.gname);
                    u('" data-action="openGroupInfoCard" data-uin="');
                    u(h.gc);
                    u('">');
                    u(h.gname);
                    u("</span>\n			");
                    s = 64;
                }
                u("\n			</span>\n		</div>\n	</div>\n");
                s = 68;
            }
            s = 70;
            u("\n	</div>\n");
            s = 72;
            return c.join("");
        } catch (g) {
            n(g, d, f, s);
        }
    };
}, , , function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = {
        folderTreePanel: a(164)
    };
    var r = a(186);
    var o = $(G.handler);
    function l(e, t) {
        o.trigger("menu.hide");
        if ((typeof t === "undefined" ? "undefined" : i(t)) === "object") {
            e.find(".panel-title span").text(t.title);
            e.find(".rename-hint").text(t.tips);
            e.find(".btn-ok").attr("data-action", t.action);
            var a = e.find(".new-name");
            if (t.showValue) {
                a.val(t.showValue);
            }
        }
        e.find(".error-message").removeClass("show");
        e.addClass("open").focus();
        if (t && t.showValue) {
            inputDom[0].inputStart = true;
            inputDom[0].focus();
            inputDom[0].select();
            setTimeout(function() {
                inputDom[0].inputStart = false;
            }, 200);
        }
    }
    function s(e) {
        e.removeClass("open");
    }
    function d(e) {
        o.trigger("menu.hide");
        var t = $("#containerFolderTreePanel");
        t.html(n.folderTreePanel(e));
        r.render(t.find(".folder-tree-box"));
        t.find("#folderTreePanel").addClass("open");
    }
    function f(e, t) {
        o.trigger("menu.hide");
        e.addClass("open").focus();
        if (t) {
            if (t.hideAll) {
                e.find(".panel-footer").addClass("hide");
            } else {
                e.find(".panel-footer").removeClass("hide");
            }
            if (t.hideOk) {
                e.find(".btn-ok").addClass("hide");
            } else {
                e.find(".btn-ok").removeClass("hide");
            }
            if (t.closeText) {
                e.find(".btn-no").text("确定").val("确定");
            } else {
                e.find(".btn-no").text("取消").val("取消");
            }
            if (t.okBtnText) {
                e.find(".btn-ok").text(t.okBtnText).val(t.okBtnText);
            }
            if (t.module === 2) {
                e.find(".icons-new-alert").addClass("icons-fail-alert");
            } else {
                e.find("icons-new-alert").removeClass("icons-fail-alert");
            }
            e.find(".panel-title span").text(t.title);
            e.find(".panel-content").html(t.text);
            e.find(".btn-ok").attr("data-action", t.action);
        }
    }
    function c() {
        $(".panel-overlay").removeClass("open");
    }
    o.bind("panel.hideAll", c);
    e.exports = {
        show: l,
        hide: s,
        hideAll: c,
        showFolderTreePanel: d,
        showBatchPanel: f
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPanel");
    var n = a(59);
    var r = a(184);
    var o = a(78);
    var l = a(133);
    var s = a(54);
    var d = a(24);
    var f = $(G.handler);
    function c() {
        var e = $.trim(i.find(".new-name").val());
        var t = {
            parent_id: "/",
            name: e
        };
        o.createFolder(t).done(function(e) {
            var t = s.filterFolder(e.folder_info);
            G.folderNum++;
            report("createFolderSuc");
            s.addData(t);
            n.appendFold(t);
            l.hideAll();
            f.trigger("toast.show", {
                type: "suc",
                text: "新建文件夹成功"
            });
            d.init();
        }).fail(function(e) {
            if (e.ec === 405) {
                G.canCreateFolder = false;
            }
            r.showError(e.ec, i);
            report("newFolderError");
        });
    }
    e.exports = {
        createFolder: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(59);
    var n = a(78);
    var r = a(54);
    var o = $(G.handler);
    var l = a(19);
    var s = a(24);
    function d(e) {
        if (e.errorCode === 0 && e.ret) {
            var t = {
                id: G.selectRow.id
            };
            n.deleteFolder(t).done(function(e) {
                if (e.ec) {
                    client.alert(2, "提示", "删除文件夹失败");
                    return;
                }
                G.canCreateFolder = true;
                var t = G.folderMap()[G.selectRow.id];
                G.folderNum--;
                if (G.folderNum < 0) {
                    G.folderNum = 0;
                }
                r.remove(t.id);
                i.removeRow(t);
                l.setClist(t, "delete");
                o.trigger("toast.show", {
                    type: "suc",
                    text: "删除文件夹成功"
                });
                s.init(G.file.isTooMany || G.file.isFull, "delete");
                report("delFolderSuc");
            }).fail(function(e) {
                client.alert(2, "提示", e && e.ec === -317 ? "该文件夹不可删除" : "删除文件夹失败");
                report("delFolderError");
            });
        }
    }
    function f() {
        o.trigger("menu.hide");
        if (!G.selectRow) {
            return;
        }
        var e = G.getReportInfo(G.selectRow);
        e.ver3 = 6;
        reportNew("folderRightMenuClick", e);
        report("deleteFolder", G.module());
        var t = client.confirm(2, "提示", "你确定要删除" + G.selectRow.fnameEsc + "以及文件夹内的所有文件吗？");
        if (t) {
            d(t);
        }
    }
    e.exports = {
        showDeleteFolder: f,
        deleteFolder: d
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPanel");
    var n = a(59);
    var r = a(184);
    var o = a(78);
    var l = a(133);
    var s = a(54);
    var d = a(112);
    var f = $(G.handler);
    function c() {
        f.trigger("menu.hide");
        if (!G.selectRow) {
            return;
        }
        var e = $.trim(i.find(".new-name").val());
        var t = G.selectRow.id;
        var a = {
            folder_id: t,
            new_name: e
        };
        o.renameFolder(a).done(function(a) {
            var i = G.folderMap()[t];
            i.fname = e;
            i.fnameEsc = e;
            i.name = e;
            i.modify_time = Math.ceil(new Date().getTime() / 1e3);
            i = s.updateFolder(i);
            $("[data-path='" + t + "']").find(".name").html(e);
            f.trigger("toast.show", {
                type: "suc",
                text: "重命名文件夹成功"
            });
            n.updateRow(i);
            l.hideAll();
        }).fail(function(e) {
            var t = e.ec;
            if (t === -317) {
                t = 317.2;
            }
            r.showError(t, i);
            report("renameFolderError");
        });
        return true;
    }
    e.exports = {
        renameFolder: c
    };
}, function(e, t, a) {
    "use strict";
    var i = a(54);
    var n = a(19);
    var r = $(G.handler);
    var o = G.folderVersion;
    function l() {
        if (n.getTips()) {} else {
            report("showOldVersion");
            s();
        }
    }
    function s() {
        $("#updateQQ").addClass("open");
        $("#updateQQTips").text("当前版本不支持文件夹下载功能，请升级QQ至最新版本后体验");
        $("#updateQQ").find("input.btn-notips").attr("data-action", "panel.close");
    }
    function d(e) {
        var t = document.createElement("div");
        var a = this.getBoundingClientRect();
        var i = function r() {
            var e = document.height;
            var t = G.getDomPanel();
            var a = t[0].scrollHeight;
            if (a + 52 > e) {
                return true;
            }
            return false;
        };
        t.innerHTML = '<div class="img"></div>';
        t.className = "file-animate files-" + e.icon;
        var n = window.innerWidth - a.left - 76;
        if (G.info.isAdmin) {
            n += 47;
        }
        if (i()) {
            n -= 20;
        }
        if (G.mac) {
            n = 177;
        }
        t.style.right = n + "px";
        t.style.top = a.top - 20 + "px";
        document.body.appendChild(t);
        setTimeout(function() {
            document.body.removeChild(t);
        }, 1500);
    }
    function f(e) {
        if (G.info.version < o) {
            l();
            return;
        }
        report("downloadFolder");
        if (e) {
            d.call(this, e);
            var t = e.id;
            var a = e.fnameEsc;
            console.log(e, t, a);
            client.addDownloadTask(t, a, 0, true, true);
        }
        r.trigger("menu.hide");
    }
    function c() {
        f.bind(this)(G.selectRow);
    }
    function u() {
        var e = $(this).closest(".list-item");
        var t = e.data("path");
        var a = i.getData(t);
        f.bind(this)(a);
    }
    e.exports = {
        download: c,
        downloadByBtn: u
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#folderPropertyPanel");
    var n = a(156);
    var r = $(G.handler);
    function o() {
        report("propFolder");
        n.render(i, G.selectRow);
        i.addClass("open");
        r.trigger("menu.hide");
        i.find(".aria-hide")[0].focus();
        var e = G.getReportInfo(G.selectRow);
        e.ver3 = 5;
        reportNew("folderRightMenuClick", e);
    }
    e.exports = {
        show: o
    };
}, function(e, t, a) {
    "use strict";
    var i = a(59);
    var n = a(54);
    var r = a(156);
    function o(e, t) {
        e = e || $(this).data("path");
        report("clkFolder", G.module());
        if (G.mac) {
            $(".mac-file-top").removeClass("user-module");
        }
        if ((G.module() == 0 || G.module() == 1) && e === G.nowFolder) {
            console.log("open folder return!!!!!", G.module(), G.nowFolder, e);
            return;
        }
        G.module(e === "/" ? 0 : 1);
        G.nowFolder = e;
        var a = undefined;
        if (e === "/") {
            a = Math.random();
        }
        var o = n.getData(e);
        var l = G.getReportInfo(o);
        reportNew("doubleClickFolder", l);
        var s = true;
        function d(e) {
            if (s) {
                $(".scroll-dom")[0].scrollTop = 0;
                s = false;
            }
            if (t) {
                o = {
                    fnameEsc: t
                };
            }
            r.updataFolderHeader(o);
            var a = location.hash;
            a = decodeURIComponent(a);
            var i = {
                action: "fileList",
                params: {
                    folderId: G.nowFolder,
                    fname: o.fnameEsc
                }
            };
            location.hash = a.replace(/&webParams={.+}/, "") + "&webParams=" + encodeURIComponent(JSON.stringify(i));
            if (!G.isHistory) {
                G.setHistory(i);
            }
            G.isHistory = false;
        }
        var f = {
            folderId: e,
            random: a
        };
        if (t) {
            f.folder = {
                fnameEsc: t
            };
        }
        i.getList({
            paramsFilter: f,
            succ: d
        })();
    }
    function l(e, t) {
        o.call(this, e, t);
        reportNew("wayRoot");
    }
    e.exports = {
        renderFolder: o,
        renderRootFolder: l
    };
}, function(e, t, a) {
    "use strict";
    var i = $("#move-file-panel");
    function n() {
        i.addClass("open");
    }
    function r() {
        i.removeClass("open");
    }
    function o() {
        i.removeClass("open");
    }
    function l() {
        console.log("ok move file");
    }
    function s() {
        console.log("move file create folder");
    }
    function d(e, t) {
        var a = $(e.target).closest(".folder-list-item");
        $(".folder-list-item").removeClass("active");
        a.addClass("active");
    }
    e.exports = {
        oveFileOpen: n,
        moveFileClose: r,
        moveFileCancel: o,
        moveFileOk: l,
        moveFileCreateFolder: s,
        fileActive: d
    };
}, function(e, t, a) {
    "use strict";
    var i = a(15);
    var n = 48;
    var r = a(134);
    function o(e) {
        var t = false;
        var a = new RegExp('^[^/\\\\:?*"<>|]+$');
        t = a.test(e);
        console.log("reg", a.test(e));
        return t;
    }
    function l() {
        var e = $.trim(this.value);
        if (e.length > n && !input) {
            this.value = e.substr(0, n);
        }
        return;
    }
    function s(e) {
        var t = this.inputStart;
        var a = this.value;
        var r = $(this).parents(".panel-overlay");
        var l = $(this).parent().find(".bubble");
        var s = $("#folderPanel .btn-ok").data("action");
        if ($.trim(a) === "") {
            $(this).parent().find(".error-message").removeClass("show");
            r.find(".btn-ok").prop("disabled", true);
            l.hide();
            return;
        }
        if (!o(a)) {
            var d = '文件夹名称不能包含 \\ / : * ? " < > |';
            if (s === "file.renameFile") {
                d = '文件名称不能包含 \\ / : * ? " < > |';
            }
            $(this).parent().find(".error-message").text(d).addClass("show");
            l.html('<span class="bot"></span><span class="top"></span>' + d).show();
            r.find(".btn-ok").prop("disabled", true);
        } else {
            $(this).parent().find(".error-message").removeClass("show");
            l.hide();
        }
        if (a.length === 0) {
            r.find(".btn-ok").prop("disabled", true);
        } else if (a.length !== 0 && o(a)) {
            r.find(".btn-ok").prop("disabled", false);
        }
        if (a.length > n && !t) {
            this.value = a.substr(0, n);
        }
        if ($("#folderPanel [data-action]").length) {
            if (e && e.keyCode == 13 && !t) {
                $("#folderPanel [data-action]").click();
            }
        }
        return;
        if (i.getLen(a) > n && !t) {
            this.value = i.subString(a, 16);
        }
    }
    function d() {
        $("#folderPanel .error-message").removeClass("show");
    }
    e.exports = {
        "input.keyup": s,
        "input.focus": d,
        "input.blur": l,
        folderName: o
    };
}, , , function(e, t, a) {
    "use strict";
    var i = a(15);
    var n = window.performance;
    var r = {};
    e.exports = r;
    var o = i.getParameter("gc");
    function l() {
        d = i.getCookie("skey");
        var e = 5381;
        for (var t = 0, a = d.length; t < a; ++t) {
            e += (e << 5) + d.charCodeAt(t);
        }
        var n = e & 2147483647;
        return n;
    }
    function s() {
        var e = i.getCookie("uin");
        if (!e) {
            return 0;
        }
        e += "";
        return e.replace(/^[\D0]+/g, "");
    }
    var d = i.getCookie("skey");
    var f = s();
    var c = i.getParameter("groupuin");
    var u = l();
    function p(e) {
        return false;
    }
    var v = [ "http://pan.qun.qq.com/cgi-bin/checkAuditFlag" ];
    var m = [];
    var h = [];
    var g = {
        get_vip_info: 3,
        checkAuditFlag: 4,
        get_file_lsit: 5,
        get_group_space: 6,
        move_file: 7,
        rename_file: 8,
        create_folder: 9,
        rename_folder: 10,
        delete_folder: 11,
        thumbnail: 12
    };
    function w(e) {
        var t;
        if (e < 500) {
            t = 2220106;
        } else if (e < 2e3) {
            t = 2220107;
        } else if (e < 4e3) {
            t = 2220108;
        } else if (e < 6e3) {
            t = 2220109;
        } else if (e < 8e3) {
            t = 2220110;
        } else if (e < 1e4) {
            t = 2220111;
        } else if (e < 12e3) {
            t = 2220112;
        } else if (e < 15e3) {
            t = 2220113;
        } else if (e < 2e4) {
            t = 2220114;
        } else if (e < 25e3) {
            t = 2220115;
        } else if (e < 3e4) {
            t = 2220116;
        } else if (e < 4e4) {
            t = 2220117;
        } else if (e < 5e4) {
            t = 2220118;
        } else if (e < 6e4) {
            t = 2220119;
        } else {
            t = 2220120;
        }
        QReport.monitor(t);
    }
    function b(e, t) {
        var a = {
            get_vip_info: 3,
            checkAuditFlag: 4,
            get_file_list: 5,
            get_group_space: 6,
            move_file: 7,
            rename_file: 8,
            create_folder: 9,
            rename_folder: 10,
            delete_folder: 11,
            thumbnail: 12
        };
        var i = e.split("/");
        var n = a[i[i.length - 1]];
        if (n) {
            QReport.huatuo({
                appid: 10016,
                flag1: 1772,
                flag2: 1,
                flag3: n,
                speedTime: t
            });
        }
    }
    function y(e, t) {
        if (!n) {
            return;
        }
        if (e.indexOf("//") === 0) {
            if (G.checkHttps()) {
                e = "https:" + e;
            } else {
                e = "http:" + e;
            }
        }
        var a = e.substr(0, e.indexOf("?"));
        if (e.indexOf("?") < 0) {
            a = e;
        }
        if ($.inArray(e, h) < 0) {
            var i = n.getEntriesByName(e)[0];
            if (!i) {
                return;
            }
            h.push(e);
            var r = {
                1: i.redirectEnd - i.redirectStart,
                2: i.domainLookupStart - i.fetchStart,
                3: i.domainLookupEnd - i.domainLookupStart,
                4: i.connectEnd - i.connectStart,
                5: i.responseStart - i.requestStart,
                6: i.responseEnd - i.responseStart,
                7: i.responseEnd - i.startTime,
                8: i.fetchStart,
                9: i.domainLookupStart
            };
            b(a, r);
            r.url = e;
            w(r[2]);
            if (r[2] > 5e3) {
                QReport.monitor(2220299);
                badjsReport.info(JSON.stringify({
                    "重定向": r[1],
                    appcache: r[2],
                    dns: r[3],
                    tcp: r[4],
                    "接收": r[5],
                    "完成": r[6],
                    "总时间": r[7],
                    fetchStart: i.fetchStart,
                    dnsstart: i.domainLookupStart,
                    header: t.getAllResponseHeaders && t.getAllResponseHeaders() || false,
                    status: t.status,
                    t: "0427",
                    url: e,
                    "离线包": localVersion === "isLocal" ? "离线包请求" : "非离线包请求"
                }));
            }
        }
    }
    function x(e, t) {
        var a = Date.now();
        t = t || e.responseURL;
        e.done(function(i) {
            QReport.retcode({
                url: t,
                type: 1,
                code: i.ec,
                time: Date.now() - a,
                rate: 1
            });
            setTimeout(function() {
                y(t, e);
            }, 100);
            if (i.ec == 1) console.log("1", "缺少登录态");
        }).fail(function(e, i) {
            y(t);
            var n = {
                status: e.status,
                statusText: e.statusText
            };
            if (i == "timeout") {
                n.status = 999;
                n.statusText = "timeout";
            }
            QReport.retcode({
                url: t,
                type: 2,
                code: n.status,
                time: Date.now() - a,
                rate: 1
            });
        });
    }
    r.ajax = function(e) {
        var t = {
            type: "GET",
            dataType: "json",
            data: {
                src: "qpan",
                gc: e && e.data && e.data.gc || i.getParameter("groupuin")
            },
            xhrFields: {
                withCredentials: true
            },
            success: function r(e, t, a) {}
        };
        u && (t.data.bkn = l());
        $.extend(true, t, e);
        t.headers = {
            "Cache-Control": "no-cache,no-store"
        };
        if (t.type === "GET") {
            if (t.url.indexOf("?") < 0) {
                t.url += "?" + $.param(t.data);
            } else {
                t.url += "&" + $.param(t.data);
            }
            t.url += "&_ti=" + new Date().getTime();
            delete t.data;
        }
        var a = $.ajax(t);
        x(a, t.url);
        var n = {
            done: function o(e) {
                var i = 0;
                (function n(e, a) {
                    e.done(function(e) {
                        if (e.ec == 0) a(e);
                    });
                    e.fail(function() {
                        if (i >= 1 || p(t.url)) return;
                        i++;
                        e = $.ajax(t);
                        x(e, t.url);
                        n(e, a);
                    });
                })(a, e);
                return this;
            },
            fail: function s(e) {
                var i = 0;
                (function n(e, a) {
                    e.done(function(e) {
                        if (e.ec != 0) a(e);
                    });
                    e.fail(function(r, o) {
                        if (i >= 0) {
                            if (o == "timeout") {
                                report("cgiTimeout");
                                return a({
                                    ec: 504,
                                    msg: o
                                });
                            }
                            return a({
                                ec: r.status
                            });
                        }
                        i++;
                        e = $.ajax(t);
                        x(e, t.url);
                        n(e, a);
                    });
                })(a, e);
                return this;
            },
            timeout: function d(e) {
                a.fail(function(t, a) {
                    if (a == "timeout") e({
                        ec: 504,
                        msg: a
                    });
                });
                return this;
            },
            always: function f(e) {
                a.always(e);
                return this;
            },
            then: function c() {
                a.then.apply(a, arguments);
                return this;
            }
        };
        return n;
    };
    r.bkn = u;
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.next = d;
    t.pref = f;
    var i = a(139);
    var n = a(58);
    var r = -1;
    var o = [];
    G.historyList = o;
    G.historyIdx = r;
    if (G.webParams) {
        o.push(G.webParams);
    }
    G.setHistory = function(e) {
        r++;
        if (o.length - r >= 1) {
            o = o.slice(0, r);
        }
        o.push(e);
        l();
    };
    var l = function c() {
        if (r > 0) {
            $(".history .left").removeClass("disable");
        } else {
            $(".history .left").addClass("disable");
        }
        if (r < o.length - 1) {
            $(".history .right").removeClass("disable");
        } else {
            $(".history .right").addClass("disable");
        }
    };
    G.isHistory = false;
    var s = function u() {
        G.isHistory = true;
        l();
        var e = o[r];
        if (e.action === "fileList") {
            i.renderFolder(e.params.folderId, e.params.fname);
        } else if (typeof e.key_word !== "undefined") {
            $("#inputSearch").val(e.key_word);
            n.search();
        }
    };
    function d() {
        if (G.isHistory) {
            return;
        }
        r++;
        if (r > o.length - 1) {
            r = o.length - 1;
            return;
        }
        s();
        reportNew("wayNext");
    }
    function f() {
        if (G.isHistory) {
            return;
        }
        r--;
        if (r < 0) {
            r = 0;
            return;
        }
        s();
        reportNew("wayPref");
    }
}, function(e, t, a) {
    "use strict";
    var i = a(193);
    var n = a(194);
    var r = a(195);
    var o = a(196);
    var l = a(197);
    var s = a(198);
    var d = a(199);
    var f = a(115);
    var c = a(200);
    var u = a(201);
    e.exports = {
        "box.toggle": i.toggle,
        "task.continue": n.continueUpload,
        "task.pause": o.pause,
        "task.remove": l.remove,
        "task.resume": s.resume,
        "task.clear": r.clear,
        "task.openFolder": f.openByBox,
        "task.openFolderIco": f.openFolderByBoxIco,
        "tips.close": u.closeTips,
        "tips.refesh": u.refeshVip,
        "tips.con": u.conVip,
        "tips.vipOk": u.vipTipsOk,
        "tips.vipCancel": u.vipTipsCancel,
        "tips.open": u.openVip,
        "task.clearHistory": r.clear,
        "task.openfail": c.toggle
    };
}, function(e, t, a) {
    "use strict";
    function i() {}
    e.exports = {
        "input.edit": i
    };
}, function(e, t, a) {
    "use strict";
    var i = a(133);
    var n = function r() {
        i.hideAll();
        if (G.activeElement) {
            G.activeElement.focus();
        }
    };
    e.exports = {
        "panel.close": n
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        folderTree: a(186),
        list: a(59)
    };
    var n = {
        folder: a(177)
    };
    var r = a(141);
    var o = a(202);
    var l = a(78);
    var s = a(54);
    var d = a(186);
    var f = a(15);
    var c = false;
    var u = false;
    function p() {
        if ($('[data-keyup="folderTree.create"]').length) {
            console.log("can not try to create more than one folder at the same time");
            return;
        }
        report("createFolderInTree");
        i.folderTree.newFolder();
        i.folderTree.select("new");
        $("#inputFolderNameInFolderTree").val(f.getFolderNameDefault());
        $("#inputFolderNameInFolderTree")[0].focus();
        $("#inputFolderNameInFolderTree")[0].select();
    }
    function v(e) {
        e.keyCode = 13;
        m.call(this, e);
    }
    function m(e, t) {
        if (e && e.keyCode !== 13 && $("#inputFolderNameInFolderTree").length) {
            r["input.keyup"].call(this, e);
            return;
        }
        var a = $('[data-keyup="folderTree.create"]');
        if (!a.length) {
            t && t();
            return;
        }
        if (t) {
            u = t;
        }
        if (c) {
            return;
        }
        var o = $.trim(a.val());
        var f = r.folderName(o);
        if (!f) {
            return;
        }
        var p = {
            parent_id: "/",
            name: o
        };
        var v = this;
        c = true;
        l.createFolder(p).done(function(e) {
            var t = s.filterFolder(e.folder_info);
            s.addData(t);
            i.list.appendFold(t);
            var a = $(".folder-tree-box").find('[data-id="new"].folder-list-item');
            a.html(n.folder({
                item: t
            })).attr("data-id", t.id);
            if (G.folderTree.selected.id === "new") {
                d.select(t.id);
            }
            report("createFolderInTreeSuc");
            c = false;
            u && u();
            u = false;
        }).fail(function(e) {
            console.log("fail", e);
            c = false;
            var t = {
                134: "文件夹名称包含违禁词",
                313: "文件夹名已经存在",
                314: "创建文件夹失败",
                405: "文件夹个数已达上限",
                "default": "创建失败"
            };
            var a = Math.abs(e.ec);
            var i = $(".folder-tree-box").find(".bubble");
            i.html('<span class="bot"></span><span class="top"></span>' + (t[a] || t["default"])).show();
            setTimeout(function() {
                i.hide();
            }, 3e3);
        });
    }
    e.exports = {
        "folderTree.select": d.select,
        "folderTree.new": p,
        "folderTree.create": m,
        createInputBlur: v
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    function n(e) {
        if (e.action === "offline") {} else if (e.action === "online") {}
    }
    var r = function l() {
        var e = parseInt($(this).data("uin"));
        i.openGroupInfoCard(e);
    };
    var o = function s() {
        var e = parseInt($(this).data("uin"));
        var t = G.fileMap()[$(this).data("path")] || {};
        var a = {
            action: "search",
            params: {
                keyword: G.searchKeyword,
                files: [ {
                    fileId: t.fp,
                    busId: t.busid
                } ]
            }
        };
        localStorage.setItem("notifyOtherGroup", encodeURIComponent(JSON.stringify({
            gc: e,
            webParams: JSON.stringify(a),
            random: Math.random()
        })));
        i.openGroupFile(e, encodeURIComponent(JSON.stringify(a)));
    };
    e.exports = {
        groupEvent: n,
        openGroupFile: o,
        openGroupInfoCard: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(57);
    var n = a(56);
    var r = a(54);
    var o = function S() {
        G.activeElement = this;
    };
    var l = [ 65, 68, 0, 72, 74, 76, 77, 78, 79, 80, 82, 85, 89 ];
    var s = function _() {
        var e = $(document.activeElement).parents(".list-item");
        if (e.length === 0) {
            return false;
        }
        var t = e.data("path");
        var a = undefined;
        var i = r.getData(t);
        if (i.orcType === 2) {
            a = "fold";
        } else if (i.orcType == 1) {
            a = "file";
        }
        G.selectRow = i || {};
        G.selectRow.path = t;
        G.selectRow.type = a;
        G.selectRows = [ G.selectRow ];
        return true;
    };
    var d = function C() {
        if (s()) {
            if (G.selectRow.orcType === 2) {
                n["folder.open"](G.selectRow.id);
                console.debug("ddddddddddd");
            }
        }
    };
    var f = function M() {
        if (s()) {
            if (G.selectRow.type === "file") {
                i["file.showRename"]();
            } else if (G.selectRow.type === "fold") {
                n["folder.showRenameFolder"]();
            }
        }
    };
    var c = function D() {
        if (s()) {
            if (G.selectRow.type === "file") {
                i["file.download"]();
            } else if (G.selectRow.type === "fold") {
                n["folder.download"]();
            }
        }
    };
    var u = function R() {
        if (s()) {
            if (G.selectRow.type === "fold") {
                n["folder.property"]();
            }
        }
    };
    var p = function j() {
        if (s()) {
            if (G.selectRow.type === "file") {
                i["file.showRename"]();
            } else if (G.selectRow.type === "fold") {
                n["folder.showRenameFolder"]();
            }
        }
    };
    var v = function I() {
        if (s()) {
            if (G.selectRow.type === "file") {
                i["file.preview"]();
            }
        }
    };
    var m = function N() {
        if (s()) {
            if (G.selectRow.type === "file") {
                i["file.showMove"]();
            }
        }
    };
    var h = function O() {
        var e = arguments.length <= 0 || arguments[0] === undefined ? false : arguments[0];
        if (s()) {
            if (G.selectRow.type === "file") {
                if (e) {
                    i["file.forwardMobile"]();
                } else {
                    i["file.forward"]();
                }
            }
        }
    };
    var g = function L() {
        if (s()) {
            if (G.selectRow.type === "file") {
                i["file.jubao"]();
            }
        }
    };
    G.nowIdx = 0;
    var w = function E(e) {
        var t = G.onlyGetDom().find(".item-name");
        if (!e) {
            G.nowIdx--;
        } else {
            G.nowIdx++;
        }
        var a = G.nowIdx;
        if (a < 0) {
            a = t.length - 1;
        } else if (a > t.length - 1) {
            a = 0;
        }
        t.eq(a).focus();
    };
    G.nowSelectMoveFolder = 0;
    var b = function P(e) {
        if ($("#folderTreePanel").hasClass("open")) {
            var t = $("#folderTreePanel").find(".aria-hide");
            if (!e) {
                G.nowSelectMoveFolder--;
            } else {
                G.nowSelectMoveFolder++;
            }
            var a = G.nowSelectMoveFolder;
            if (a < 0) {
                a = t.length - 1;
            } else if (a > t.length - 1) {
                a = 0;
            }
            console.log(t.eq(a));
            t.eq(a).focus();
            G.nowSelectMoveFolder = a;
        }
    };
    var y = function A(e) {
        console.debug(e);
        switch (e) {
          case 37:
            b(0);
            break;

          case 39:
            b(1);
            break;

          case 38:
            w(0);
            break;

          case 40:
            w(1);
            break;

          case 65:
            $("#selectAllFile").click();
            break;

          case 66:
            $("#openBoxBtn").click();
            break;

          case 68:
            f();
            break;

          case 70:
            h();
            break;

          case 71:
            n["folder.open"]("/");
            break;

          case 72:
            h(true);
            break;

          case 74:
            g();
            break;

          case 76:
            doDownLoad();
            break;

          case 77:
            m();
            break;

          case 78:
            $("#createFolder button").click();
            break;

          case 79:
            d();
            break;

          case 80:
            u();
            break;

          case 82:
            p();
            break;

          case 85:
            $(".icons-upload-1").click();
            break;

          case 88:
            $(G.handler).trigger("panel.hideAll");
            break;

          case 89:
            v();
            break;
        }
    };
    var x = function B(e) {
        switch (e) {
          case 81:
            console.log($("#ariaQuickTipsDom"));
            $("#ariaQuickTipsDom").focus();
            break;
        }
    };
    var k = function q(e) {
        console.debug(e.keyCode);
        if (e.altKey && e.shiftKey) {
            y.call(this, e.keyCode);
        } else if (e.ctrlKey) {
            x.call(this, e.keyCode);
        }
    };
    var F = function z() {
        var e = $("#boxListDom").find(".file2");
        e.each(function() {
            $(this).find(".aria-tips").attr("tabindex", 1);
            if (this.classList.contains("continue")) {
                $(this).find(".remove").attr("tabindex", 1);
                $(this).find(".continue").attr("tabindex", 1);
            } else if (this.classList.contains("pause")) {
                $(this).find(".resume").attr("tabindex", 1);
                $(this).find(".remove").attr("tabindex", 1);
            } else if (this.classList.contains("err")) {
                $(this).find(".pause").attr("tabindex", 1);
                $(this).find(".remove").attr("tabindex", 1);
            } else if (this.classList.contains("progress")) {
                $(this).find(".remove").attr("tabindex", 1);
            } else if (this.classList.contains("complete")) {}
        });
    };
    var T = function U() {
        $("#boxListDom .file-action a").attr("tabindex", "-1");
    };
    e.exports = {
        "aria.fmg": o,
        changeBoxTabIndex: F,
        removeBoxTabIndex: T,
        "aria.quick": k
    };
}, function(e, t, a) {
    "use strict";
    var i = a(166);
    var n = a(167);
    var r = a(203);
    var o = $("#fileMoreMenu");
    function l() {
        var e = n(G.info);
        o.html(e);
    }
    function s() {
        var e = i({
            mac: G.mac
        });
        o.html(e);
    }
    function d(e, t) {
        var a = {
            data: false,
            list: false,
            isUploader: true
        };
        if (typeof t !== "undefined") {
            if (t.hasOwnProperty("length")) {
                a.list = t;
                a.list.every(function(e) {
                    if (G.info.uin !== e.uin) {
                        return a.isUploader = false;
                    }
                    return true;
                });
            } else {
                a.data = t;
                G.info.uin !== t.uin && (a.isUploader = false);
            }
        }
        var i = r(a);
        e.html(i);
    }
    e.exports = {
        renderFolder: l,
        renderFile: s,
        renderCustomMenu: d
    };
}, function(e, t, a) {
    "use strict";
    var i = function() {
        var e = /"|&|'|<|>|[\x00-\x20]|[\x7F-\xFF]|[\u0100-\u2700]/g;
        var t = /&\w+;|&#(\d+);/g;
        var a = /(^\s*)|(\s*$)/g;
        var i = {
            "&lt;": "<",
            "&gt;": ">",
            "&amp;": "&",
            "&nbsp;": " ",
            "&quot;": '"',
            "&copy;": ""
        };
        var n = function o(t) {
            t = t != undefined ? t : "";
            return typeof t != "string" ? t : t.replace(e, function(e) {
                var t = e.charCodeAt(0), a = [ "&#" ];
                t = t == 32 ? 160 : t;
                a.push(t);
                a.push(";");
                return a.join("");
            });
        };
        var r = function l(e) {
            e = e != undefined ? e : "";
            var a = typeof e != "string" ? e : e.replace(t, function(e, t) {
                var a = i[e];
                if (a == undefined) {
                    if (!isNaN(t)) {
                        a = String.fromCharCode(t == 160 ? 32 : t);
                    } else {
                        a = e;
                    }
                }
                return a;
            });
            a = a.replace(/&#x2028;/g, "\u2028");
            a = a.replace(/&#x2029;/g, "\u2029");
            return a;
        };
        return {
            encodeHtml: n,
            decodeHtml: r
        };
    }();
    e.exports = {
        encode: i.encodeHtml,
        decode: i.decodeHtml
    };
}, function(e, t, a) {
    "use strict";
    var i = a(78), n = {}, r = $(G.handler);
    e.exports = n;
    var o = 10, l = 3 * 60 * 1e3;
    function s(e) {
        var t = e.filepath;
        var a = e.remoteType;
        var i = e.fname;
        var n = e.fp;
        if (!n) {
            n = t.substr(4);
        }
        var r = a == 1 ? 0 : 1;
        var n = r + "<" + n + "<" + escape(i);
        return n;
    }
    function d(e) {
        var t = "";
        for (var a = 0; a < e.length; a++) {
            if (a > 0) {
                t += ":";
            }
            t += s(e[a]);
        }
        return t;
    }
    n.getThumb = function(e, t) {
        if (!G.flagThumb) {
            return;
        }
        var a = d(e);
        var n = {
            id: Math.floor(new Date().getTime() / 1e3),
            fp_list: a
        };
        i.getPreview(n).done(function(t) {
            if (t.ec === 0) {
                if (!t.address_list) {
                    t.address_list = [];
                }
                for (var a = 0, i = e.length; a < i; a++) {
                    var n = e[a], o = t.address_list[a];
                    o.t = new Date().getTime();
                    if (n) {
                        n.usedTime = 0;
                        G.previewCache[n.filepath] = o;
                        n.previewObj = o;
                        r.trigger("file.thumbUpdate", n);
                    }
                }
            }
        }).fail(function(e) {});
    };
    n.getOneThumb = function(e, t) {
        var a = new Date().getTime();
        try {
            if (a - e.previewObj.t < l && e.usedTime <= 3) {
                t(e);
                return;
            }
        } catch (n) {
            console.log(n);
        }
        var r = {
            id: Math.floor(new Date().getTime() / 1e3),
            fp_list: s(e)
        };
        i.getPreview(r).done(function(a) {
            if (a.ec === 0) {
                if (!a.address_list) {
                    a.address_list = [];
                }
                var i = a.address_list[0];
                i.t = new Date().getTime();
                e.usedTime = 0;
                e.previewObj = i;
                t(e);
            }
        }).fail(function(e) {});
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(78);
    var r = a(54);
    var o = {};
    e.exports = o;
    function l(e, t) {
        if (typeof e.total === "number") {
            r.setAllNum(e);
        }
        r.setRole(e);
        return r.setFileList(e.list);
    }
    o.getList = function(e) {
        e = e || {};
        var t = e.folderId || "/";
        var a = e.filterUin || undefined;
        var r = 0;
        var o = 25;
        var s = e.filterCode || 0;
        var d = false;
        var f = undefined;
        var c = false;
        var u = false;
        return function(e, p, v) {
            if (u) {
                return;
            }
            u = true;
            if (d) {
                p({
                    ec: 1e3,
                    em: "no more items"
                });
                return;
            }
            var m = {
                folder_id: t,
                start_index: r,
                cnt: o,
                filter_code: s,
                filter_uin: a
            };
            var h = JSON.stringify(m) === f;
            f = JSON.stringify(m);
            if (c && h) {
                console.info("same params will be ignored");
                return;
            }
            v && v();
            var g = function w(a) {
                u = false;
                c = true;
                var i = {
                    list: a.file_list,
                    total: a.total_cnt,
                    totalSpace: a.total_space,
                    usedSpace: a.used_space,
                    userRole: a.user_role,
                    openFlag: a.open_flag
                };
                var n = r;
                G.nowFolder = t;
                if (a.file_list && a.file_list.length) {
                    r = r + a.file_list.length;
                }
                if (a.next_index === 0) {
                    d = true;
                }
                e(l(i, s));
                if (n === 0 || n === 1) {
                    G.tab.resetTab();
                }
            };
            if ((typeof nodeData === "undefined" ? "undefined" : i(nodeData)) === "object") {
                g(nodeData);
                nodeData = false;
            } else {
                n.getFileList(m).done(function(e) {
                    g(e);
                }).fail(function(e) {
                    report("getListError");
                    u = false;
                    c = false;
                    p(e);
                });
            }
        };
    };
    o.getFileList = function(e) {
        n.getFileList(e).done(function(e) {
            if (e.total_cnt === 0 && folderId === "/") {
                suc(false);
                return;
            }
            var t = {
                list: e.file_list,
                total: e.total_cnt,
                totalSpace: e.total_space,
                usedSpace: e.used_space,
                userRole: e.user_role,
                openFlag: e.open_flag
            };
            G.nowFolder = folderId;
            if (e.file_list && e.file_list.length) {
                startIndex = startIndex + e.file_list.length;
            }
            if (e.next_index === 0) {
                isEnd = true;
            }
            suc(l(t));
        }).fail(function(e) {
            if (e.fc && e.fc === 1) {
                return;
            }
        });
    };
    o.setAllSpace = function(e, t) {
        n.getSpace().done(function(t) {
            var a = {
                totalSpace: t.total_space,
                usedSpace: t.used_space
            };
            r.setAllSpace(a);
            e(t);
        }).fail(function(e) {
            console.log(e);
        });
    };
}, function(e, t, a) {
    "use strict";
    var i = a(182), n = a(183);
    function r(e, t) {
        var a = i(t);
        e.html(a);
    }
    function o(e) {
        var t = G.getDomPanel().find(".fold");
        var a = t.length ? t : G.getDomPanel();
        a.after(n({
            id: e
        }));
    }
    function l(e) {
        $("#searchDom").css("display", "none");
        if (e) {
            $("#fileNum").addClass("hide").attr("data-action", "menu.filenum");
            $("#folderName").removeClass("hide");
            $("#headerFolderName").text(e.fnameEsc);
            $("#createFolder").hide();
        } else {
            $("#fileNum").removeClass("hide").attr("data-action", "menu.filenum");
            $("#folderName").addClass("hide");
            if (G.canCreateFolder) {
                $("#createFolder").show();
            }
        }
    }
    e.exports = {
        render: r,
        updataFolderHeader: l
    };
}, function(e, t, a) {
    "use strict";
    var i = {};
    var n = $("#groupSize");
    var r = $("#groupSizeBar");
    i.renderSpace = function o() {
        if (G.nowFolder !== "/") {
            return;
        }
        n.text(G.file.capacityused + "/" + G.file.capacitytotal);
        $("#fileNumText").text(G.file.allnum);
        $("#macFileNums").text("共" + G.file.allnum + "个文件");
        var e = parseInt(G.file.cu / G.file.ct * 100);
        r.css("width", e + "%");
        $("#fileNum").removeClass("hide");
        $(".nav").addClass("hide");
        $("#normalNav").removeClass("hide");
    };
    e.exports = i;
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function g(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '<%\n	for(var i = 0,l=locals.list.length;i<l;i++){\n		var item = locals.list[i];\n		if(item.orcType === 2){\n%>\n	<div class="fold list-item <%if(item.succ){%>succ<%}%>" data-path="<%=item.id%>" id="<%=item.domid%>" data-dbaction="folder.open" data-action="list.select">\n		<div class="item-name item-name-adjust" data-dbaction="folder.open" tabindex="-1" data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>" >\n			<div class="filesmall-folder drag-dom" data-dbaction="folder.open"  data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>" title="<%-item.fname%>&#10;文件个数：<%-item.filenum%>&#10;创建时间：<%=item.ctoStr%>&#10;创建人：<%-item.nick%>"></div>\n			<span class="name drag-dom" title="<%-item.fname%>&#10;文件个数：<%-item.filenum%>&#10;创建时间：<%=item.ctoStr%>&#10;创建人：<%-item.nick%>"><%- item.fname %></span>\n		</div>\n		<div class="item-time drag-dom"  title="更新时间：<%=item.mtoStr%>">\n			<span><%= item.mtStr %></span>\n		</div>\n		<div class="item-size">－</div>\n		<div class="item-user">－</div>\n		<div class="item-download-times">－</div>\n		<div class="aria-hide">\n			<a tabindex="3"><%-item.fname%> 文件个数：<%-item.filenum%> 创建时间：<%=item.ctoStr%> 创建人：<%-item.nick%></a>\n			<button tabindex="3" data-focus="file.aria" data-action="folder.open"  data-path="<%=item.id%>" data-viewcntr="folder<%=item.domid%>" aria-label="打开文件夹:<%- item.fname %> ">文件夹<%- item.fname %> 更新时间：<%=item.mtoStr%></button>		\n		</div>	\n		<div class="item-download"><button role="button" aria-label="下载文件夹<%- item.fname %>" title="下载文件夹" class="icons-download-new" data-action="folder.downloadByBtn" tabindex="3"></button></div>\n	</div>\n<%\n}else{\n%>\n	<div class="file list-item <%=item.icon%> <%if(item.remoteType===2){%>temp<%}%> <%if(item.succ){%>succ<%}%> <%if(item.safeType){%>illegal<%}%>" id="<%=item.domid%>" data-path="<%=item.filepath%>" <%if(!locals.renderParams){%>id="<%=item.domid%>"<%}%> <%if(item.otherGroupName){%> data-dbaction="openGroupFile" data-uin="<%- item.gc %>"<%}%> data-action="list.select" <%if(item.preview){%>data-dbaction="file.preview"<%}else{%>data-dbaction="file.downloadByDom"<%}%> <%if(item.safeType){%>title="该文件存在安全风险，无法正常使用"<%}%>  tabindex="-1">\n		<div class="item-name-wrap item-name-adjust" <%if(!item.safeType){%>title="<%- item.name %><%-item.suf%>&#10;创建时间：<%=item.ctoStr%>"<%}%>>\n			<div class="item-name" tabindex="-1">\n				<div class="file-icons" data-path="<%=item.filepath%>" <%if(item.preview){%>data-dbaction="file.preview"<%}%>>\n					<div class="drag-dom filesmall-<%=item.icon%> <%if(item.previewObj){%>thumb<%}%>" <%if(item.previewObj){%>style="background-image:url(<%=item.previewObj.url%>);"<%}%>></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom">\n					<%- item.name %><%-item.suf%>\n				</span>\n			</div>\n			<% if(item.canEdit || item.remoteType === 2) { %>\n				<div class="item-tags">\n					<div class="overflow">\n						<%if(item.canEdit){%><span class="can-edit"></span><%}%>\n						<%if(item.remoteType ===2){%><span class="tmp"></span><%}%>\n					</div>\n				</div>\n			<% } %>\n		</div>\n		<div class="item-time" <%if(!item.safeType){%>title="更新时间：<%=item.mtoStr%>"<%}%> aria-live="polite" aria-atomic="false" aria-relevant="all">\n			<span class="drag-dom"><%= item.mtStr %></span>\n		</div>\n		<div class="item-size" <%if(!item.safeType){%>title="文件大小：<%= item.sizeStr%>"<%}%>>\n			<span class="drag-dom"><%= item.sizeStr%></span>\n		</div>\n		<div class="item-user" <%if(!item.safeType){%>title="上传者：<%-item.nick%> (<%=item.uin%>)"<%}%>><span><%- item.nick%></span></div>\n		<div class="item-download-times" title="下载次数：<%= item.down %>次"><span><%= item.down %>次</span></div>\n		<div class="item-download">\n			<%if(!item.safeType){%><button tabindex="-1" role="button" aria-label="下载文件<%=item.fname%>" title="下载文件" class="icons-download-new" data-action="file.downloadByBtn"></button><%}%>\n		</div>\n		<div class="aria-hide">\n			<a tabindex="3">名称:<%=item.fname%>,文件类型:<%=item.filetype%>,大小:<%=item.sizeStr%>,下载次数:<%=item.down%>次,上传人:<%=item.nick%>,上传时间:<%=item.ctStr%>,<%if(item.succ){%>该文件已下载<%}%></a>\n			<%if(item.isDown){%>\n				<button role="button" tabindex="3" data-action="file.openFolder" class="file-aria-btn" data-focus="file.aria" aria-label="打开<%=item.fname%>"></button>\n			<%}else{%>\n				<button role="button" tabindex="3" data-action="file.downloadByBtn" class="file-aria-btn" data-focus="file.aria" aria-label="下载文件<%=item.fname%>"></button>\n			<%}%>\n			<%if((item.safeType === 0 && item.admin) || G.info.isAdmin){%>\n				<button data-focus="file.aria" role="button" aria-label="转发文件<%=item.fname%>" data-action="file.forward" tabindex="3">转发<%=item.fname%></button>\n				<button data-focus="file.aria" role="button" aria-label="转发文件到手机<%=item.fname%>" data-action="file.forwardMobile" tabindex="3">转发文件到手机<%=item.fname%></button>\n				<button data-focus="file.aria" role="button" aria-label="在文件夹中显示<%=item.fname%>" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示<%=item.fname%></button>\n				<button data-focus="file.aria" role="button" aria-label="重命名文件<%=item.fname%>" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名<%=item.fname%></button>\n				<%if(item.remoteType===2){%><button data-focus="file.aria" role="button" aria-label="转存为永久文件<%=item.fname%>" data-action="file.permanent" tabindex="3">转存为永久文件<%=item.fname%></button><%}%>\n				<button data-focus="file.aria" role="button" aria-label="移动文件<%=item.fname%>" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件<%=item.fname%></button>\n			<%}%>\n			<%if(item.safeType && item.admin || G.info.isAdmin){%>\n				<button data-focus="file.aria"  role="button" aria-label="删除文件<%=item.fname%>" data-action="file.delete" tabindex="3">删除<%=item.fname%></button>\n			<%}%>\n			<button data-focus="file.aria" role="button" aria-label="举报文件<%=item.fname%>" data-action="file.jubao" tabindex="3">举报文件<%=item.fname%></button>\n		</div>\n	</div>\n<%\n	}\n}\n%>\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\fileRowNew.ejs";
        try {
            var c = [], u = c.push.bind(c);
            for (var p = 0, v = e.list.length; p < v; p++) {
                var m = e.list[p];
                if (m.orcType === 2) {
                    s = 5;
                    u('\n	<div class="fold list-item ');
                    s = 6;
                    if (m.succ) {
                        u("succ");
                    }
                    u('" data-path="');
                    u(t(m.id));
                    u('" id="');
                    u(t(m.domid));
                    u('" data-dbaction="folder.open" data-action="list.select">\n		<div class="item-name item-name-adjust" data-dbaction="folder.open" tabindex="-1" data-path="');
                    s = 7;
                    u(t(m.id));
                    u('" data-viewcntr="folder');
                    u(t(m.domid));
                    u('" >\n			<div class="filesmall-folder drag-dom" data-dbaction="folder.open"  data-path="');
                    s = 8;
                    u(t(m.id));
                    u('" data-viewcntr="folder');
                    u(t(m.domid));
                    u('" title="');
                    u(m.fname);
                    u("&#10;文件个数：");
                    u(m.filenum);
                    u("&#10;创建时间：");
                    u(t(m.ctoStr));
                    u("&#10;创建人：");
                    u(m.nick);
                    u('"></div>\n			<span class="name drag-dom" title="');
                    s = 9;
                    u(m.fname);
                    u("&#10;文件个数：");
                    u(m.filenum);
                    u("&#10;创建时间：");
                    u(t(m.ctoStr));
                    u("&#10;创建人：");
                    u(m.nick);
                    u('">');
                    u(m.fname);
                    u('</span>\n		</div>\n		<div class="item-time drag-dom"  title="更新时间：');
                    s = 11;
                    u(t(m.mtoStr));
                    u('">\n			<span>');
                    s = 12;
                    u(t(m.mtStr));
                    u('</span>\n		</div>\n		<div class="item-size">－</div>\n		<div class="item-user">－</div>\n		<div class="item-download-times">－</div>\n		<div class="aria-hide">\n			<a tabindex="3">');
                    s = 18;
                    u(m.fname);
                    u(" 文件个数：");
                    u(m.filenum);
                    u(" 创建时间：");
                    u(t(m.ctoStr));
                    u(" 创建人：");
                    u(m.nick);
                    u('</a>\n			<button tabindex="3" data-focus="file.aria" data-action="folder.open"  data-path="');
                    s = 19;
                    u(t(m.id));
                    u('" data-viewcntr="folder');
                    u(t(m.domid));
                    u('" aria-label="打开文件夹:');
                    u(m.fname);
                    u(' ">文件夹');
                    u(m.fname);
                    u(" 更新时间：");
                    u(t(m.mtoStr));
                    u('</button>		\n		</div>	\n		<div class="item-download"><button role="button" aria-label="下载文件夹');
                    s = 21;
                    u(m.fname);
                    u('" title="下载文件夹" class="icons-download-new" data-action="folder.downloadByBtn" tabindex="3"></button></div>\n	</div>\n');
                    s = 23;
                } else {
                    s = 25;
                    u('\n	<div class="file list-item ');
                    s = 26;
                    u(t(m.icon));
                    u(" ");
                    if (m.remoteType === 2) {
                        u("temp");
                    }
                    u(" ");
                    if (m.succ) {
                        u("succ");
                    }
                    u(" ");
                    if (m.safeType) {
                        u("illegal");
                    }
                    u('" id="');
                    u(t(m.domid));
                    u('" data-path="');
                    u(t(m.filepath));
                    u('" ');
                    if (!e.renderParams) {
                        u('id="');
                        u(t(m.domid));
                        u('"');
                    }
                    u(" ");
                    if (m.otherGroupName) {
                        u(' data-dbaction="openGroupFile" data-uin="');
                        u(m.gc);
                        u('"');
                    }
                    u(' data-action="list.select" ');
                    if (m.preview) {
                        u('data-dbaction="file.preview"');
                    } else {
                        u('data-dbaction="file.downloadByDom"');
                    }
                    u(" ");
                    if (m.safeType) {
                        u('title="该文件存在安全风险，无法正常使用"');
                    }
                    u('  tabindex="-1">\n		<div class="item-name-wrap item-name-adjust" ');
                    s = 27;
                    if (!m.safeType) {
                        u('title="');
                        u(m.name);
                        u(m.suf);
                        u("&#10;创建时间：");
                        u(t(m.ctoStr));
                        u('"');
                    }
                    u('>\n			<div class="item-name" tabindex="-1">\n				<div class="file-icons" data-path="');
                    s = 29;
                    u(t(m.filepath));
                    u('" ');
                    if (m.preview) {
                        u('data-dbaction="file.preview"');
                    }
                    u('>\n					<div class="drag-dom filesmall-');
                    s = 30;
                    u(t(m.icon));
                    u(" ");
                    if (m.previewObj) {
                        u("thumb");
                    }
                    u('" ');
                    if (m.previewObj) {
                        u('style="background-image:url(');
                        u(t(m.previewObj.url));
                        u(');"');
                    }
                    u('></div>\n					<i class="icons-check"></i>\n				</div>\n				<span class="name drag-dom">\n					');
                    s = 34;
                    u(m.name);
                    u(m.suf);
                    u("\n				</span>\n			</div>\n			");
                    s = 37;
                    if (m.canEdit || m.remoteType === 2) {
                        u('\n				<div class="item-tags">\n					<div class="overflow">\n						');
                        s = 40;
                        if (m.canEdit) {
                            u('<span class="can-edit"></span>');
                        }
                        u("\n						");
                        s = 41;
                        if (m.remoteType === 2) {
                            u('<span class="tmp"></span>');
                        }
                        u("\n					</div>\n				</div>\n			");
                        s = 44;
                    }
                    u('\n		</div>\n		<div class="item-time" ');
                    s = 46;
                    if (!m.safeType) {
                        u('title="更新时间：');
                        u(t(m.mtoStr));
                        u('"');
                    }
                    u(' aria-live="polite" aria-atomic="false" aria-relevant="all">\n			<span class="drag-dom">');
                    s = 47;
                    u(t(m.mtStr));
                    u('</span>\n		</div>\n		<div class="item-size" ');
                    s = 49;
                    if (!m.safeType) {
                        u('title="文件大小：');
                        u(t(m.sizeStr));
                        u('"');
                    }
                    u('>\n			<span class="drag-dom">');
                    s = 50;
                    u(t(m.sizeStr));
                    u('</span>\n		</div>\n		<div class="item-user" ');
                    s = 52;
                    if (!m.safeType) {
                        u('title="上传者：');
                        u(m.nick);
                        u(" (");
                        u(t(m.uin));
                        u(')"');
                    }
                    u("><span>");
                    u(m.nick);
                    u('</span></div>\n		<div class="item-download-times" title="下载次数：');
                    s = 53;
                    u(t(m.down));
                    u('次"><span>');
                    u(t(m.down));
                    u('次</span></div>\n		<div class="item-download">\n			');
                    s = 55;
                    if (!m.safeType) {
                        u('<button tabindex="-1" role="button" aria-label="下载文件');
                        u(t(m.fname));
                        u('" title="下载文件" class="icons-download-new" data-action="file.downloadByBtn"></button>');
                    }
                    u('\n		</div>\n		<div class="aria-hide">\n			<a tabindex="3">名称:');
                    s = 58;
                    u(t(m.fname));
                    u(",文件类型:");
                    u(t(m.filetype));
                    u(",大小:");
                    u(t(m.sizeStr));
                    u(",下载次数:");
                    u(t(m.down));
                    u("次,上传人:");
                    u(t(m.nick));
                    u(",上传时间:");
                    u(t(m.ctStr));
                    u(",");
                    if (m.succ) {
                        u("该文件已下载");
                    }
                    u("</a>\n			");
                    s = 59;
                    if (m.isDown) {
                        u('\n				<button role="button" tabindex="3" data-action="file.openFolder" class="file-aria-btn" data-focus="file.aria" aria-label="打开');
                        s = 60;
                        u(t(m.fname));
                        u('"></button>\n			');
                        s = 61;
                    } else {
                        u('\n				<button role="button" tabindex="3" data-action="file.downloadByBtn" class="file-aria-btn" data-focus="file.aria" aria-label="下载文件');
                        s = 62;
                        u(t(m.fname));
                        u('"></button>\n			');
                        s = 63;
                    }
                    u("\n			");
                    s = 64;
                    if (m.safeType === 0 && m.admin || G.info.isAdmin) {
                        u('\n				<button data-focus="file.aria" role="button" aria-label="转发文件');
                        s = 65;
                        u(t(m.fname));
                        u('" data-action="file.forward" tabindex="3">转发');
                        u(t(m.fname));
                        u('</button>\n				<button data-focus="file.aria" role="button" aria-label="转发文件到手机');
                        s = 66;
                        u(t(m.fname));
                        u('" data-action="file.forwardMobile" tabindex="3">转发文件到手机');
                        u(t(m.fname));
                        u('</button>\n				<button data-focus="file.aria" role="button" aria-label="在文件夹中显示');
                        s = 67;
                        u(t(m.fname));
                        u('" data-action="file.openFolderInBox" tabindex="3">在文件夹中显示');
                        u(t(m.fname));
                        u('</button>\n				<button data-focus="file.aria" role="button" aria-label="重命名文件');
                        s = 68;
                        u(t(m.fname));
                        u('" data-action="file.showRename" data-blur="aria.fmg" tabindex="3">重命名');
                        u(t(m.fname));
                        u("</button>\n				");
                        s = 69;
                        if (m.remoteType === 2) {
                            u('<button data-focus="file.aria" role="button" aria-label="转存为永久文件');
                            u(t(m.fname));
                            u('" data-action="file.permanent" tabindex="3">转存为永久文件');
                            u(t(m.fname));
                            u("</button>");
                        }
                        u('\n				<button data-focus="file.aria" role="button" aria-label="移动文件');
                        s = 70;
                        u(t(m.fname));
                        u('" data-action="file.showMove" data-blur="aria.fmg" tabindex="3">移动文件');
                        u(t(m.fname));
                        u("</button>\n			");
                        s = 71;
                    }
                    u("\n			");
                    s = 72;
                    if (m.safeType && m.admin || G.info.isAdmin) {
                        u('\n				<button data-focus="file.aria"  role="button" aria-label="删除文件');
                        s = 73;
                        u(t(m.fname));
                        u('" data-action="file.delete" tabindex="3">删除');
                        u(t(m.fname));
                        u("</button>\n			");
                        s = 74;
                    }
                    u('\n			<button data-focus="file.aria" role="button" aria-label="举报文件');
                    s = 75;
                    u(t(m.fname));
                    u('" data-action="file.jubao" tabindex="3">举报文件');
                    u(t(m.fname));
                    u("</button>\n		</div>\n	</div>\n");
                    s = 78;
                }
            }
            s = 81;
            u("\n");
            s = 82;
            return c.join("");
        } catch (h) {
            n(h, d, f, s);
        }
    };
}, , function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = function(e) {
        if (e.BJ_REPORT) return e.BJ_REPORT;
        var t = [];
        var a = e.onerror;
        e.onerror = function(t, i, n, o, l) {
            var d = t;
            if (l && l.stack) {
                d = s(l);
            }
            if (r(d, "Event")) {
                d += d.type ? "--" + d.type + "--" + (d.target ? d.target.tagName + "--" + d.target.src : "") : "";
            }
            m.push({
                msg: d,
                target: i,
                rowNum: n,
                colNum: o
            });
            v();
            a && a.apply(e, arguments);
        };
        var n = {
            id: 0,
            uin: 0,
            url: "",
            combo: 1,
            ext: {},
            level: 4,
            ignore: [],
            random: 1,
            delay: 1e3,
            submit: null
        };
        var r = function h(e, t) {
            return Object.prototype.toString.call(e) === "[object " + (t || "Object") + "]";
        };
        var o = function g(e) {
            var t = typeof e === "undefined" ? "undefined" : i(e);
            return t === "object" && !!e;
        };
        var l = function w(e) {
            try {
                if (e.stack) {
                    var t = e.stack.match("http://[^\n]+");
                    t = t ? t[0] : "";
                    var a = t.match(":([0-9]+):([0-9]+)");
                    if (!a) {
                        a = [ 0, 0, 0 ];
                    }
                    var i = s(e);
                    return {
                        msg: i,
                        rowNum: a[1],
                        colNum: a[2],
                        target: t.replace(a[0], "")
                    };
                } else {
                    return e;
                }
            } catch (n) {
                return e;
            }
        };
        var s = function b(e) {
            var t = e.stack.replace(/\n/gi, "").split(/\bat\b/).slice(0, 5).join("@").replace(/\?[^:]+/gi, "");
            var a = e.toString();
            if (t.indexOf(a) < 0) {
                t = a + "@" + t;
            }
            return t;
        };
        var d = function y(e, t) {
            var a = [];
            var i = [];
            var r = [];
            if (o(e)) {
                e.level = e.level || n.level;
                for (var l in e) {
                    var s = e[l] || "";
                    if (s) {
                        if (o(s)) {
                            try {
                                s = JSON.stringify(s);
                            } catch (d) {
                                s = "[BJ_REPORT detect value stringify error] " + d.toString();
                            }
                        }
                        r.push(l + ":" + s);
                        a.push(l + "=" + encodeURIComponent(s));
                        i.push(l + "[" + t + "]=" + encodeURIComponent(s));
                    }
                }
            }
            return [ i.join("&"), r.join(","), a.join("&") ];
        };
        var f = [];
        var c = function G(e) {
            if (n.submit) {
                n.submit(e);
            } else {
                var t = new Image();
                f.push(t);
                t.src = e;
            }
        };
        var u = [];
        var p = 0;
        var v = function x(e) {
            if (!n.report) return;
            while (t.length) {
                var a = false;
                var i = t.shift();
                var o = d(i, u.length);
                for (var l = 0, s = n.ignore.length; l < s; l++) {
                    var f = n.ignore[l];
                    if (r(f, "RegExp") && f.test(o[1]) || r(f, "Function") && f(i, o[1])) {
                        a = true;
                        break;
                    }
                }
                if (!a) {
                    if (n.combo) {
                        u.push(o[0]);
                    } else {
                        c(n.report + o[2] + "&_t=" + +new Date());
                    }
                    n.onReport && n.onReport(n.id, i);
                }
            }
            var v = u.length;
            if (v) {
                var m = function h() {
                    clearTimeout(p);
                    c(n.report + u.join("&") + "&count=" + v + "&_t=" + +new Date());
                    p = 0;
                    u = [];
                };
                if (e) {
                    m();
                } else if (!p) {
                    p = setTimeout(m, n.delay);
                }
            }
        };
        var m = {
            push: function k(e) {
                if (Math.random() >= n.random) {
                    return m;
                }
                t.push(o(e) ? l(e) : {
                    msg: e
                });
                v();
                return m;
            },
            report: function F(e) {
                e && m.push(e);
                v(true);
                return m;
            },
            info: function T(e) {
                if (!e) {
                    return m;
                }
                if (o(e)) {
                    e.level = 2;
                } else {
                    e = {
                        msg: e,
                        level: 2
                    };
                }
                m.push(e);
                return m;
            },
            debug: function $(e) {
                if (!e) {
                    return m;
                }
                if (o(e)) {
                    e.level = 1;
                } else {
                    e = {
                        msg: e,
                        level: 1
                    };
                }
                m.push(e);
                return m;
            },
            init: function S(e) {
                if (o(e)) {
                    for (var t in e) {
                        n[t] = e[t];
                    }
                }
                var a = parseInt(n.id, 10);
                if (a) {
                    n.report = (n.url || "//badjs2.qq.com/badjs") + "?id=" + a + "&uin=" + parseInt(n.uin || (document.cookie.match(/\buin=\D+(\d+)/) || [])[1], 10) + "&from=" + encodeURIComponent(location.href) + "&ext=" + JSON.stringify(n.ext) + "&";
                }
                return m;
            },
            __onerror__: e.onerror
        };
        return m;
    }(window);
    t.createReport = function(e) {
        e = e || {};
        var t = e.id;
        if (!t) throw new Error("id is required");
        n.init({
            id: t
        });
        return n;
    };
}, function(e, t, a) {
    "use strict";
    function i(e) {
        return e && typeof Symbol !== "undefined" && e.constructor === Symbol ? "symbol" : typeof e;
    }
    var n = a(55);
    var r = {
        newtask: a(204),
        taskcomplete: a(205),
        taskpause: a(206),
        taskresume: a(207),
        taskprogress: a(208),
        taskabort: a(209)
    };
    function o(e) {
        if ((typeof e === "undefined" ? "undefined" : i(e)) !== "object") {
            console.error("onFiletransporterEvent param parse error");
            return;
        }
        var t = e.event;
        var a = e.task;
        var o = {
            newtask: "newtask",
            taskcomplete: "taskcomplete",
            taskpause: "taskpause",
            taskresume: "taskresume",
            startprogress: "taskprogress",
            taskabort: "taskabort"
        };
        if (typeof o[t] !== "undefined" && typeof r[o[t]] !== "undefined") {
            a = n.get(a);
            r[o[t]](a);
            $(G.handler).trigger("task.startRefresh");
        }
    }
    e.exports = {
        fileEvent: o
    };
}, function(e, t, a) {
    "use strict";
    var i = a(114);
    function n(e) {
        console.debug(" show upload");
        i.showUpload(e);
    }
    function r(e) {
        console.debug(" show upload files");
        var t = e.fileList;
        var a = [];
        for (var n = 0, r = t.length; n < r; n++) {
            var o = t[n];
            a.push(o.filepath);
        }
        i.batchuploadInFolder(G.nowFolder, a);
    }
    e.exports = {
        uploadEvent: n,
        dropEvent: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(181);
    var n = undefined;
    var r = undefined;
    function o(e) {
        if (!n) {
            var t = i();
            $("body").append(t);
            n = $("#jubaoDom");
            r = $("#jubaoIframe");
        }
        if (e) {
            n.addClass("open");
            r.attr("src", e).addClass("open");
        }
    }
    function l() {
        if (n) {
            n.removeClass("open");
            r.removeClass("open");
        }
    }
    e.exports = {
        show: o,
        hide: l
    };
}, function(e, t, a) {
    var i = a(210);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var n;
        var r = e || {};
        (function(e, a, r, o, l, s, d, f) {
            t.push('<!-- 移动文件/上传文件 公用模态框--><div id="folderTreePanel" role="panel" class="panel-overlay folder-tree-panel"><div class="panel"><div class="panel-title"><i class="icons-qq"></i><span>' + i.escape((n = f) == null ? "" : n) + '</span><div data-action="panel.close" data-dismiss="panel" aria-label="取消" class="close"></div></div><div class="panel-body"><div class="panel-content"><div class="selected-files"><span class="file-name">' + (null == (n = s) ? "" : n) + "</span>");
            if (l > 1) {
                t.push('						等 <span class="file-number">' + (null == (n = l) ? "" : n) + "</span> 个文件");
            }
            t.push('</div><div class="translateTo"><span class="translateTo-label">' + i.escape((n = a) == null ? "" : n) + '</span><span class="little-folder-icon"></span><div data-role="dest" class="selected-folder-name">' + (null == (n = o) ? "" : n) + '</div><div id="targetFolderName" aria-live="assertive" aria-atomic="true" aria-relevant="all" class="aria-hide"><span>已选中文件夹</span><span class="folder-name">' + (null == (n = o) ? "" : n) + '</span></div></div><div class="folder-tree-box"></div></div></div><div class="panel-footer">');
            if (r = e.info.isAdmin) {
                t.push('<input type="submit" value="新建文件夹" data-action="folderTree.new" tabindex="1" class="btn-create btn-common"/>');
            }
            t.push('<input type="submit" value="取消" data-action="panel.close" data-dismiss="panel" aris-label="取消移动文件" tabindex="1" class="btn-no btn-common btn-right"/><input type="submit" value="确定"' + i.attr("data-action", "" + d + "", true, false) + ' aria-label="确定移动文件" tabindex="1" class="btn-ok btn-common btn-right"/></div></div></div>');
        }).call(this, "G" in r ? r.G : typeof G !== "undefined" ? G : undefined, "action" in r ? r.action : typeof action !== "undefined" ? action : undefined, "canCreatFolder" in r ? r.canCreatFolder : typeof canCreatFolder !== "undefined" ? canCreatFolder : undefined, "destFolder" in r ? r.destFolder : typeof destFolder !== "undefined" ? destFolder : undefined, "fileNum" in r ? r.fileNum : typeof fileNum !== "undefined" ? fileNum : undefined, "firstFileName" in r ? r.firstFileName : typeof firstFileName !== "undefined" ? firstFileName : undefined, "okAction" in r ? r.okAction : typeof okAction !== "undefined" ? okAction : undefined, "title" in r ? r.title : typeof title !== "undefined" ? title : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    e.exports = function(e) {
        if (!e.webpackPolyfill) {
            e.deprecate = function() {};
            e.paths = [];
            e.children = [];
            e.webpackPolyfill = 1;
        }
        return e;
    };
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '		<li class="item with-icon-item disable" id="filePreview" data-action="file.menupreview" aria-label="预览"><span class="icons-preview"></span><span class="menu-item-label">预览</span></li>\n		<%if(!G.mac){%>\n			<li class="item" id="fileFoward" data-action="file.forward" aria-label="转发">转发</li>\n			<li class="item" id="fileFowardTo" data-action="file.forwardMobile" aria-label="转发到手机" tabindex="1">转发到手机</li>\n		<%}%>\n		<li class="item save-as open-folder with-icon-item" id="fileOpenFolder" data-action="file.openFolderInBox" aria-label="在文件夹中显示" tabindex="1"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item rename" id="renameFile" data-action="file.showRename" aria-label="重命名" tabindex="1">重命名</li>\n		<li class="item forever disable" id="foreverFile" data-action="file.permanent" aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n		<%if(G.info.isAdmin){%>\n		<li class="item " id="fileMove" data-action="file.showMove" aria-label="移动" tabindex="-1">移动</li>\n		<%}%>\n		<li class="item jubao" id="fileJubao" data-action="file.jubao" aria-label="举报" tabindex="1">举报</li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item delete with-icon-item" data-action="file.delete" id="fileDelete" aria-label="删除" tabindex="1"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\fileMenu.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('		<li class="item with-icon-item disable" id="filePreview" data-action="file.menupreview" aria-label="预览"><span class="icons-preview"></span><span class="menu-item-label">预览</span></li>\n		');
            s = 2;
            if (!G.mac) {
                u('\n			<li class="item" id="fileFoward" data-action="file.forward" aria-label="转发">转发</li>\n			<li class="item" id="fileFowardTo" data-action="file.forwardMobile" aria-label="转发到手机" tabindex="1">转发到手机</li>\n		');
                s = 5;
            }
            u('\n		<li class="item save-as open-folder with-icon-item" id="fileOpenFolder" data-action="file.openFolderInBox" aria-label="在文件夹中显示" tabindex="1"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item rename" id="renameFile" data-action="file.showRename" aria-label="重命名" tabindex="1">重命名</li>\n		<li class="item forever disable" id="foreverFile" data-action="file.permanent" aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n		');
            s = 10;
            if (G.info.isAdmin) {
                u('\n		<li class="item " id="fileMove" data-action="file.showMove" aria-label="移动" tabindex="-1">移动</li>\n		');
                s = 12;
            }
            u('\n		<li class="item jubao" id="fileJubao" data-action="file.jubao" aria-label="举报" tabindex="1">举报</li>\n		<li class="gap" tabindex="1"></li>\n		<li class="item delete with-icon-item" data-action="file.delete" id="fileDelete" aria-label="删除" tabindex="1"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n');
            s = 16;
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '		<li class="download-item with-icon-item download-folder" id="folderDownloadLink" data-action="folder.download"><span class="icons-download"></span><span class="menu-item-label">下载</span></li>\n		<li class="with-icon-item open-in-folder disable" id="showInFolderLink" data-action="folder.openfolder"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		<%if(locals.isAdmin){%>\n		<li class="rename-item" id="folderRenameLink" data-action="folder.showRenameFolder">重命名</li>\n		<%}%>\n		<li class="property-item" id="folderPropLink" data-action="folder.property">文件夹属性</li>\n		<li class="gap"></li>\n		<%if(locals.isAdmin){%>\n		<li class="delete-item with-icon-item" id="folderDeleteLink" data-action="folder.showDeleteFolder"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n		<%}else{%>\n		<li class="item jubao" data-action="file.jubao" id="folderJubaoLink" aria-label="举报" tabindex="1">举报</li>\n		<%}%>\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\folderMenu.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('		<li class="download-item with-icon-item download-folder" id="folderDownloadLink" data-action="folder.download"><span class="icons-download"></span><span class="menu-item-label">下载</span></li>\n		<li class="with-icon-item open-in-folder disable" id="showInFolderLink" data-action="folder.openfolder"><span class="icons-menu-save-as"></span><span class="menu-item-label">在文件夹中显示</span></li>\n		');
            s = 3;
            if (e.isAdmin) {
                u('\n		<li class="rename-item" id="folderRenameLink" data-action="folder.showRenameFolder">重命名</li>\n		');
                s = 5;
            }
            u('\n		<li class="property-item" id="folderPropLink" data-action="folder.property">文件夹属性</li>\n		<li class="gap"></li>\n		');
            s = 8;
            if (e.isAdmin) {
                u('\n		<li class="delete-item with-icon-item" id="folderDeleteLink" data-action="folder.showDeleteFolder"><span class="icons-trash"></span><span class="menu-item-label">删除</span></li>\n		');
                s = 10;
            } else {
                u('\n		<li class="item jubao" data-action="file.jubao" id="folderJubaoLink" aria-label="举报" tabindex="1">举报</li>\n		');
                s = 12;
            }
            u("\n");
            s = 13;
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, , , , , , , , , , function(e, t, a) {
    var i = a(210);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var i;
        var n = e || {};
        (function(e) {
            t.push('<!--文件夹模板--><div class="whole-row"></div><div class="folder-info"><span class="little-folder-icon"></span><span class="folder-name">' + (null == (i = e.fname) ? "" : i) + "</span></div>");
        }).call(this, "item" in n ? n.item : typeof item !== "undefined" ? item : undefined);
        return t.join("");
    };
}, , function(e, t, a) {
    var i = a(210);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var n;
        var r = e || {};
        (function(e, a, r) {
            t.push('<!--文件夹树模板--><ul data-action="file_active" role="tree" class="primary-folder-list"><li' + i.attr("data-id", "" + a.id + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"> </div><div class="folder-info"><span class="little-folder-icon"></span><span class="folder-name">' + (null == (n = a.fname) ? "" : n) + '</span><a href="javascript:void(0)"' + i.attr("data-id", "" + a.id + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + i.attr("aria-label", "选择文件夹:" + a.fname + "", true, false) + ' class="aria-hide"></a></div><ul class="secondary-folder-list">');
            (function() {
                var a = e;
                if ("number" == typeof a.length) {
                    for (var r = 0, o = a.length; r < o; r++) {
                        var l = a[r];
                        t.push("<li" + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><div class="little-folder-icon"></div><div class="folder-name">' + (null == (n = l && l.fname) ? "" : n) + '</div><a href="javascript:void(0)"' + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + i.attr("aria-label", "选择文件夹:" + (l && l.fname) + "", true, false) + ' class="aria-hide"></a></div></li>');
                    }
                } else {
                    var o = 0;
                    for (var r in a) {
                        o++;
                        var l = a[r];
                        t.push("<li" + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><div class="little-folder-icon"></div><div class="folder-name">' + (null == (n = l && l.fname) ? "" : n) + '</div><a href="javascript:void(0)"' + i.attr("data-id", "" + (l && l.id) + "", true, false) + ' data-action="folderTree.select" role="treeitem" tabindex="1"' + i.attr("aria-label", "选择文件夹:" + (l && l.fname) + "", true, false) + ' class="aria-hide"></a></div></li>');
                    }
                }
            }).call(this);
            t.push("</ul></li></ul>");
        }).call(this, "items" in r ? r.items : typeof items !== "undefined" ? items : undefined, "topFolder" in r ? r.topFolder : typeof topFolder !== "undefined" ? topFolder : undefined, "undefined" in r ? r.undefined : typeof undefined !== "undefined" ? undefined : undefined);
        return t.join("");
    };
}, function(e, t, a) {
    var i = a(210);
    e.exports = function n(e) {
        var t = [];
        var a = {};
        var i;
        t.push('<li data-id="new" data-action="folderTree.select" class="folder-list-item"><div class="whole-row"></div><div class="folder-info"><span class="little-folder-icon"></span><input id="inputFolderNameInFolderTree" value="新建文件夹" data-blur="createInputBlur" data-keyup="folderTree.create" autofocus="true" class="folder-name"/><div class="bubble"><span class="bot"></span><span class="top"></span>文件夹名称中含有违禁词</div></div></li>');
        return t.join("");
    };
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '  <div class="panel-con jubao-panel" id="jubaoDom">\r\n    <iframe class="frame-jubao" id="jubaoIframe" frameborder="0" scrolling="no"></iframe>\r\n  </div>', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\jubao.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('  <div class="panel-con jubao-panel" id="jubaoDom">\r\n    <iframe class="frame-jubao" id="jubaoIframe" frameborder="0" scrolling="no"></iframe>\r\n  </div>');
            s = 3;
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '		<div class="panel">\n			<div class="panel-title">\n				<i class="icons-qq"></i>\n				<span>文件夹属性</span>\n				<div class="close" data-action="panel.close"></div>\n			</div>\n			<div class="panel-body">\n				<div class="panel-content">\n					<div class="folder-property-top">\n						<div class="files-folder filesmall-folder"></div>\n						<div class="folder-title">\n							<div class="folder-name"><%-locals.fname%></div>\n							<div class="folder-size">共<%=locals.filenum%>个文件</div>\n						</div>\n					</div>\n					<div class="folder-property-bottom">\n						<div class="created-at">\n							<span class="folder-property-label">创建时间:</span>\n							<span class="folder-property-content"><%=locals.ctStr%></span>\n						</div>\n						<div class="creator">\n							<span class="folder-property-label">创&nbsp;&nbsp;建&nbsp;&nbsp;人:</span>\n							<span class="folder-property-content"><%-locals.nick%></span>\n						</div>\n						<div class="updated-at">\n							<span class="folder-property-label">最后更新时间:</span>\n							<span class="folder-property-content"><%=locals.mtStr%></span>\n						</div>\n						<div class="updater">\n							<span class="folder-property-label">最&nbsp;后&nbsp;更&nbsp;新&nbsp;人:</span>\n							<span class="folder-property-content"><%-locals.mnick%></span>\n						</div>\n					</div>\n				</div>\n			</div>\n			<a href="javascript:void(0);" class="aria-hide" tabindex="3" aria-label="文件夹<%-locals.fname%>共<%=locals.filenum%>个文件 创建时间:<%=locals.ctStr%> 创建人:<%-locals.nick%> 最后更新人:<%-locals.mnick%>"></a>\n			<a href="javascript:void(0);" class="aria-hide" data-action="panel.close" tabindex="3" aria-label="关闭文件夹属性窗口"></a>\n			<%if(G.mac){%>\n				<div class="panel-footer">\n					<input aria-label="确定" type="submit" value="确定" class="btn-ok btn-common btn-right" data-action="panel.close" tabindex="2">\n				</div>\n			<%}%>\n		</div>\n\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\folderproperty.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('		<div class="panel">\n			<div class="panel-title">\n				<i class="icons-qq"></i>\n				<span>文件夹属性</span>\n				<div class="close" data-action="panel.close"></div>\n			</div>\n			<div class="panel-body">\n				<div class="panel-content">\n					<div class="folder-property-top">\n						<div class="files-folder filesmall-folder"></div>\n						<div class="folder-title">\n							<div class="folder-name">');
            s = 12;
            u(e.fname);
            u('</div>\n							<div class="folder-size">共');
            s = 13;
            u(t(e.filenum));
            u('个文件</div>\n						</div>\n					</div>\n					<div class="folder-property-bottom">\n						<div class="created-at">\n							<span class="folder-property-label">创建时间:</span>\n							<span class="folder-property-content">');
            s = 19;
            u(t(e.ctStr));
            u('</span>\n						</div>\n						<div class="creator">\n							<span class="folder-property-label">创&nbsp;&nbsp;建&nbsp;&nbsp;人:</span>\n							<span class="folder-property-content">');
            s = 23;
            u(e.nick);
            u('</span>\n						</div>\n						<div class="updated-at">\n							<span class="folder-property-label">最后更新时间:</span>\n							<span class="folder-property-content">');
            s = 27;
            u(t(e.mtStr));
            u('</span>\n						</div>\n						<div class="updater">\n							<span class="folder-property-label">最&nbsp;后&nbsp;更&nbsp;新&nbsp;人:</span>\n							<span class="folder-property-content">');
            s = 31;
            u(e.mnick);
            u('</span>\n						</div>\n					</div>\n				</div>\n			</div>\n			<a href="javascript:void(0);" class="aria-hide" tabindex="3" aria-label="文件夹');
            s = 36;
            u(e.fname);
            u("共");
            u(t(e.filenum));
            u("个文件 创建时间:");
            u(t(e.ctStr));
            u(" 创建人:");
            u(e.nick);
            u(" 最后更新人:");
            u(e.mnick);
            u('"></a>\n			<a href="javascript:void(0);" class="aria-hide" data-action="panel.close" tabindex="3" aria-label="关闭文件夹属性窗口"></a>\n			');
            s = 38;
            if (G.mac) {
                u('\n				<div class="panel-footer">\n					<input aria-label="确定" type="submit" value="确定" class="btn-ok btn-common btn-right" data-action="panel.close" tabindex="2">\n				</div>\n			');
                s = 42;
            }
            u("\n		</div>\n\n");
            s = 45;
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function v(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '<section class="file-list" id="<%-locals.id%>"></section>', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\folderdom.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u('<section class="file-list" id="');
            u(e.id);
            u('"></section>');
            return c.join("");
        } catch (p) {
            n(p, d, f, s);
        }
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        102: "非群成员",
        103: "该文件不存在或已失效",
        106: "登录态校验失败",
        116: "没有权限",
        117: "没有权限",
        118: "没有权限",
        119: "没有权限",
        120: "没有权限",
        121: "没有权限",
        122: "没有权限",
        123: "没有权限",
        124: "没有权限",
        125: "没有权限",
        126: "没有权限",
        127: "没有权限",
        128: "没有权限",
        129: "没有权限",
        130: "没有权限",
        131: "没有权限",
        132: "文件存在安全风险",
        133: "文件安全性未知",
        134: "名称包含特殊/敏感字符，请重新输入。",
        313: "已存在同名文件夹，请重新命名",
        314: "创建文件夹失败",
        315: "删除文件夹失败",
        402: "文件数量已经超过限制",
        403: "可用空间不够",
        405: "创建失败，文件夹个数已达上限",
        25: "操作失败，空间不足.",
        317.1: "该文件夹不可删除",
        317.2: "无法修改名称"
    };
    var n = {
        deleteSuc: "删除成功",
        moveSuc: "转存成功",
        folderSuc: "新建文件夹成功",
        deleteFolderSuc: "删除文件夹成功"
    };
    var r = $(G.handler), o = a(133);
    var l = [ 134, 313, 405 ];
    function s(e, t) {
        e = Math.abs(e);
        if (i[e] && $.inArray(e, l) >= 0) {
            t.find(".error-message").text(i[e]).addClass("show");
        } else {
            var a = i[e] || "操作失败";
            r.trigger("toast.show", {
                type: "alert",
                text: a
            });
            o.hideAll();
        }
    }
    function d(e) {
        r.trigger("toast.show", {
            type: "alert",
            text: e
        });
    }
    function f(e) {
        r.trigger("toast.show", {
            type: "alert",
            text: e
        });
    }
    e.exports = {
        showError: s,
        showWait: d,
        showSuc: f
    };
}, function(e, t, a) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: true
    });
    t.edit = h;
    var i = a(54);
    var n = a(78);
    var r = a(50);
    var o = a(15);
    var l = a(59);
    var s = a(115);
    var d = $(G.handler);
    var f = 5485;
    G.editFileList = {};
    var c = "canedit" + o.getUin();
    var u = false;
    var p = function g() {
        var e = localStorage.getItem(c);
        if (!e) {
            return false;
        }
        try {
            e = JSON.parse(e);
            var t = +new Date();
            if (t - e.ts < e.t) {
                u = true;
                return true;
            }
        } catch (a) {}
        return false;
    };
    var v = function w(e, t) {
        var a = localStorage.getItem(c);
        try {
            if (a) {
                a = JSON.parse(a);
            } else {
                a = {};
            }
            a.t = 30 * 100;
            a.w = e;
            a.ts = +new Date();
            localStorage.setItem(c, JSON.stringify(a));
        } catch (i) {}
    };
    var m = function b() {
        n.getEditFlag().done(function(e) {
            if (e.ec === 0) {
                var t = e.req_interval;
                var a = e.is_white;
                v(a, t);
                u = e.is_white;
            } else {
                jumpToPage(0);
            }
        }).fail(function() {});
    };
    m();
    function h(e) {
        console.log("edit file:", e, u);
        if (e) {
            if (G.version >= f && e.admin && e.filetype === "文档" && u) {
                console.debug(" input and edit file:", e);
                var t = e.localpath;
                if (typeof t === "string" && t.indexOf("OSRoot") < 0) {
                    t = "OSRoot:\\" + t;
                }
                var a = window.external.isFileExist(t);
                if (a == "false" || a === false) {
                    r.alert(2, "提示", "此文件不存在，可能已被删除或被移动到其他位置");
                    s.changeOpenFolder2Download(e);
                    return false;
                }
                var i = {
                    filepath: e.filepath,
                    name: e.fnameEsc,
                    fp: e.fp,
                    md5: e.md5,
                    localpath: t
                };
                var n = r.onlineEditFile(e.parentId, JSON.stringify(i));
                console.debug("start online edit", n, " param is ", i);
                if (n == "success") {
                    G.editFileList[e.filepath] = 1;
                    return true;
                } else if (n === "file cannot open") {
                    var o = r.confirm(2, "提示", "此文件无法识别并打开，是否在文件夹中查看该文件？");
                    if (o.errorCode === 0 && o.ret) {
                        s.openByPath(e);
                    } else {
                        return false;
                    }
                }
            } else {
                s.openByPath(e);
            }
        }
    }
}, function(e, t, a) {
    "use strict";
    var i = {
        folderTree: a(179),
        newFloder: a(180)
    };
    var n = $("#containerFolderTreePanel");
    var r = a(15);
    function o(e, t) {
        G.folderTree = G.folderTree || {};
        var a = G.nowFolder === "/" ? {
            fname: "群文件",
            id: "/"
        } : G.folderMap()[G.nowFolder];
        if (G.folderTree && G.folderTree.selected) {
            G.folderTree.selected = a;
        }
        G.folderTree.container = $(e);
        var n = [];
        var o = Object.keys(G.folderMap());
        for (var s = o.length - 1; s >= 0; s--) {
            n.push(G.folderMap()[o[s]]);
        }
        n = r.quickSortByObjectAttr(n, "mt");
        $(e).html(i.folderTree({
            topFolder: G.topFolder,
            items: n
        }));
        l(a.id);
    }
    function l(e) {
        e = e || $(this).data("id");
        if (!e) {
            return;
        }
        if (!G.folderTree) {
            G.folderTree = {};
        }
        n.find(".active").removeClass("active").attr("aria-checked", false);
        var t = {};
        if (e === "/") {
            t = G.folderTree.selected = G.topFolder;
        } else if (e !== "new") {
            t = G.folderTree.selected = G.folderMap()[e];
        } else {
            t = {
                id: e
            };
            G.folderTree.selected = t;
        }
        $('.folder-list-item[data-id="' + t.id + '"]').addClass("active").attr("aria-checked", true);
        t.fname !== undefined && n.find('[data-role="dest"]').html(t.fname);
        n.find("span.folder-name").text(t.fname);
        n.find("input.btn-ok").focus();
    }
    function s() {
        var e = G.folderTree.container.find(".secondary-folder-list li");
        if (e.length) {
            e.first().before(i.newFloder());
        } else {
            G.folderTree.container.find(".secondary-folder-list").append(i.newFloder());
        }
    }
    e.exports = {
        render: o,
        newFolder: s,
        select: l
    };
}, , , , , , , function(e, t, a) {
    "use strict";
    var i = a(53);
    var n = a(151);
    var r = 299;
    var o = $("#box");
    var l = $(G.handler);
    var s = false;
    var d = false;
    function f() {
        report("clkTask");
        if (s) {
            u();
        } else {
            c();
            i.removePoint();
        }
    }
    function c() {
        report("showTask");
        if (!d) {
            i.firstRender();
        }
        d = true;
        s = true;
        o.addClass("open");
        $("#boxTitle a").focus();
        n.changeBoxTabIndex();
    }
    function u() {
        s = false;
        o.removeClass("open");
        n.removeBoxTabIndex();
        if (G.activeElement) {
            G.activeElement.focus();
        }
    }
    l.bind("box.hide", u);
    e.exports = {
        toggle: f
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(54);
    function r(e) {
        var t = $(this.parentNode.parentNode);
        var a = t.data("path");
        var r = n.getTask(a);
        a = r.filepath;
        var o = r.remoteType;
        var l = r.localpath;
        var s = r.fnameEsc || r.fname;
        console.log("调用续传接口:", r, a);
        var d = i.addContinueUploadTask(a, l, s, o);
        $("#boxTitle a").focus();
        console.log("continueUpload ret:", d);
    }
    e.exports = {
        continueUpload: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(53);
    var r = a(54);
    var o = a(19);
    function l() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = r.getFile(t);
        r.clearComplete();
        n.clearComplete();
        i.clearClist();
        o.clearClist();
    }
    e.exports = {
        clear: l
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(54);
    function r() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = e.data("id");
        var r = n.getTask(a, t);
        var o = i.pauseTask(a);
        $("#boxTitle a").focus();
        report("clkTaskPause", typeof r.downloadtasktype === "undefined" ? 0 : 1);
    }
    e.exports = {
        pause: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(15);
    var r = a(78);
    var o = a(54);
    var l = a(53);
    var s = a(59);
    var d = $(G.handler);
    var f = function p(e) {
        var t = e.type;
        var a = true;
        var n = e.filepath;
        report("clkTaskDelete");
        $("#boxTitle a").focus();
        if (e.id) {
            var l = i.removeTask(e.id);
            a = true;
        }
        if (a) {
            if (e.id) {
                o.remove(e.id);
            }
            if (e.type !== "download") {
                o.remove(e.filepath);
            }
            e.status = "remove";
            d.trigger("client.updateTask", e);
            if (t && t.indexOf("upload") >= 0) {
                if (n) {
                    var f = {
                        app_id: G.appid,
                        bus_id: e.busid,
                        file_id: e.fp,
                        parent_folder_id: G.nowFolder
                    };
                    r.deleteFile(f).done(function(t) {
                        console.log(t);
                        o.remove(e);
                    }).fail(function(e) {
                        if (e.fc && e.fc === 1) {
                            return;
                        }
                    });
                }
            } else if (t === "download") {
                i.removeTask(e.id);
                i.removeCompleteTask(e.id);
            }
            i.clearClist();
            var c = o.getData(n);
            if (c) {
                c.isDowning = false;
            }
            s.updateRow(c);
        }
    };
    function c() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("id");
        var a = e.data("path");
        var i = o.getTask(t);
        if (!i) {
            i = o.getTask(a);
        }
        f(i);
    }
    function u(e, t) {
        var a = o.getTask(e);
        if (!a) {
            a = o.getTask(t);
        }
        f(a);
    }
    G.removeTaskInDownLoad = u;
    d.bind("task.removeOne", function(e, t) {
        var a = i.removeTask(t);
        console.log(a, t);
    });
    e.exports = {
        remove: c,
        removeByDownLoad: u
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(54);
    function r() {
        var e = $(this.parentNode.parentNode);
        var t = e.data("path");
        var a = n.getTask(t);
        var r = a.id;
        var o = i.resumeTask(r);
        report("clkTaskPause");
        $("#boxTitle a").focus();
    }
    e.exports = {
        resume: r
    };
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = a(111).refreshTime;
    var r = a(55);
    var o = $(G.handler);
    var l = 0;
    function s() {
        if (!l) {
            return;
        }
        clearTimeout(l);
        l = 0;
    }
    function d() {
        if (l) {
            return;
        }
        f();
    }
    function f() {
        var e = i.getTaskListAdv();
        var t = false;
        if (e.empty && e.status === "ok") {
            s();
        } else {
            var a = /progress|ready|scan|geturl/gi;
            var d = r.cleanMap(e.map);
            for (var c = 0, u = d.length; c < u; c++) {
                var p = d[c];
                o.trigger("client.updateTask", p);
                if (a.test(p.status)) {
                    t = true;
                }
            }
        }
        if (t) {
            l = setTimeout(f, n);
        } else {
            console.log("do stop refresh!");
            s();
        }
    }
    $(G.handler).bind("task.startRefresh", d);
    $(G.handler).bind("task.stopRefresh", s);
}, function(e, t, a) {
    "use strict";
    function i() {
        if (this.classList.contains("open")) {
            this.classList.remove("open");
        } else {
            report("clkTaskExp");
            this.classList.add("open");
        }
    }
    e.exports = {
        toggle: i
    };
}, function(e, t, a) {
    "use strict";
    var i = a(78), n = a(50), r = a(54), o = {};
    e.exports = o;
    o.closeTips = function() {};
    o.refeshVip = function() {
        i.checkVip().done(function(e) {
            console.log(e);
        }).fail(function(e) {});
    };
    o.conVip = function() {
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    o.vipTipsOk = function() {
        window.open("http://pay.qq.com/ipay/index.shtml?c=cjclub&aid=vip.gongneng.client.qunwenjian_openvip&ADTAG=CLIENT.QQ.GroupFile_OpenSVIP");
    };
    o.vipTipsCancel = function() {};
    o.openVip = function() {};
}, function(e, t, a) {
    "use strict";
    var i = a(78), n = a(54), r = {};
    e.exports = r;
    r.createFolder = function(e, t) {
        i.createFolder(e).done(function(e) {
            t(e);
        }).fail(function(e) {});
    };
    r.renameFolder = function(e, t) {};
    r.deleteFolder = function(e, t) {};
}, function(e, t, a) {
    e.exports = function i(e, t, a, n) {
        n = n || function g(e, t, a, i) {
            var n = t.split("\n"), r = Math.max(i - 3, 0), o = Math.min(n.length, i + 3);
            var l = n.slice(r, o).map(function(e, t) {
                var a = t + r + 1;
                return (a == i ? " >> " : "    ") + a + "| " + e;
            }).join("\n");
            e.path = a;
            e.message = (a || "ejs") + ":" + i + "\n" + l + "\n\n" + e.message;
            throw e;
        };
        t = t || function(e) {
            return e == undefined ? "" : String(e).replace(o, l);
        };
        var r = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&#34;",
            "'": "&#39;"
        }, o = /[&<>'"]/g;
        function l(e) {
            return r[e] || e;
        }
        var s = 1, d = '<ul>\n<%\n	//todo 文件打开需要加个接口.\n	var data = locals.data,\n		list = locals.list,\n		isUploader = locals.isUploader;\n	if(!data && !list){\n%>\n	<li <%if(G.file.isTooMany){%>class="disabled"<%}else{%> data-action="file.upload"<%}%>>上传</li>\n	<%if(G.canCreateFolder && G.nowFolder === \'/\'){%>\n	<li <%if(G.file.isTooMany){%>class="disabled"<%}else{%> data-action="folder.create"<%}%> title="新建文件夹">新建文件夹</li>\n	<%}%>\n	<li data-action="menu.refresh" onclick="window.location.reload();">刷新</li>\n<%}else if(data){%>\n	<%if(typeof data.othergroup !== \'undefined\'){%>\n		<li data-action="openGroupFile" data-uin="<%-data.gc%>">打开所在群</li>\n	<%}else{%>\n		<%if(data.orcType === 1){%>\n			<%if(data.icon !== \'pic\'){%>\n				<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.downloadByMenu"<%}%> aria-label="打开" data-path="<%=data.filepath%>">打开</li>\n			<%}else{%>\n				<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.menupreview"<%}%> aria-label="预览">预览</li>\n			<%}%>\n\n			<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.saveAs"<%}%> title="另存为" tabindex="3" aria-label="下载文件">另存为</li>\n			<li <%if(data.safeType || !data.isDown){%>class="disabled"<%}else{%>data-action="file.openFolderInBox"<%}%> title="在文件夹中显示" tabindex="3" aria-label="在文件夹中显示">在文件夹中显示</li>\n			<%if(!G.mac){%>\n			  <li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.forward"<%}%> aria-label="转发">转发</li>\n			  <li class="line <%if(data.safeType){%>disabled<%}%>" <%if(!data.safeType){%>data-action="file.forwardMobile"<%}%> aria-label="转发到手机">发送到手机</li>\n			<%}%>\n			<%if(G.info.isAdmin && typeof data.issearch === \'undefined\'){%>\n				<li <%if(data.safeType || G.file.isTooMany){%>class="disabled"<%}else{%>data-action="file.showMove"<%}%> aria-label="移动">移动到</li>\n			<%}%>\n			<%if(G.info.isAdmin && data.temp){%>\n				<li <%if(data.safeType){%>class="disabled"<%}else{%>data-action="file.permanent"<%}%> aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n			<%}%>\n			<li <%if(data.safeType || (!G.info.isAdmin && !isUploader)){%>class="disabled"<%}else{%>data-action="file.showRename"<%}%> aria-label="重命名" >重命名</li>\n			<li <%if(!G.info.isAdmin && !isUploader){%>class="disabled"<%}else{%>data-action="file.delete"<%}%> id="fileDelete" aria-label="删除">删除</li>\n			<li data-action="file.jubao" aria-label="举报">举报</li>\n		<%}else if(data.orcType === 2){%>\n			<li class="line" data-action="folder.open" data-path="<%=data.id%>">打开</li>\n			<li <%if(!G.info.isAdmin){%>class="disabled"<%}else{%>data-action="folder.showRenameFolder"<%}%>>重命名</li>\n			<li class="line" data-action="folder.property">文件夹属性</li>\n			<li <%if(!G.info.isAdmin){%>class="disabled"<%}else{%>data-action="folder.showDeleteFolder"<%}%>>删除</li>\n		<%}%>\n	<%}%>\n<%}else if(list){%>\n	<li class="line" data-action="file.batchSaveAs">另存为</li>\n	<li class="line" data-action="file.batchMove">移动到</li>\n	<li <%if(!G.info.isAdmin && !isUploader){%>class="disabled"<%}else{%>data-action="file.batchDelete"<%}%>>删除</li>\n<%}%>\n</ul>\n', f = "I:\\works\\pan.qun.qq.com\\trunk\\src\\tpl\\customMenu.ejs";
        try {
            var c = [], u = c.push.bind(c);
            u("<ul>\n");
            s = 2;
            var p = e.data, v = e.list, m = e.isUploader;
            if (!p && !v) {
                s = 8;
                u("\n	<li ");
                s = 9;
                if (G.file.isTooMany) {
                    u('class="disabled"');
                } else {
                    u(' data-action="file.upload"');
                }
                u(">上传</li>\n	");
                s = 10;
                if (G.canCreateFolder && G.nowFolder === "/") {
                    u("\n	<li ");
                    s = 11;
                    if (G.file.isTooMany) {
                        u('class="disabled"');
                    } else {
                        u(' data-action="folder.create"');
                    }
                    u(' title="新建文件夹">新建文件夹</li>\n	');
                    s = 12;
                }
                u('\n	<li data-action="menu.refresh" onclick="window.location.reload();">刷新</li>\n');
                s = 14;
            } else if (p) {
                u("\n	");
                s = 15;
                if (typeof p.othergroup !== "undefined") {
                    u('\n		<li data-action="openGroupFile" data-uin="');
                    s = 16;
                    u(p.gc);
                    u('">打开所在群</li>\n	');
                    s = 17;
                } else {
                    u("\n		");
                    s = 18;
                    if (p.orcType === 1) {
                        u("\n			");
                        s = 19;
                        if (p.icon !== "pic") {
                            u("\n				<li ");
                            s = 20;
                            if (p.safeType) {
                                u('class="disabled"');
                            } else {
                                u('data-action="file.downloadByMenu"');
                            }
                            u(' aria-label="打开" data-path="');
                            u(t(p.filepath));
                            u('">打开</li>\n			');
                            s = 21;
                        } else {
                            u("\n				<li ");
                            s = 22;
                            if (p.safeType) {
                                u('class="disabled"');
                            } else {
                                u('data-action="file.menupreview"');
                            }
                            u(' aria-label="预览">预览</li>\n			');
                            s = 23;
                        }
                        u("\n\n			<li ");
                        s = 25;
                        if (p.safeType) {
                            u('class="disabled"');
                        } else {
                            u('data-action="file.saveAs"');
                        }
                        u(' title="另存为" tabindex="3" aria-label="下载文件">另存为</li>\n			<li ');
                        s = 26;
                        if (p.safeType || !p.isDown) {
                            u('class="disabled"');
                        } else {
                            u('data-action="file.openFolderInBox"');
                        }
                        u(' title="在文件夹中显示" tabindex="3" aria-label="在文件夹中显示">在文件夹中显示</li>\n			');
                        s = 27;
                        if (!G.mac) {
                            u("\n			  <li ");
                            s = 28;
                            if (p.safeType) {
                                u('class="disabled"');
                            } else {
                                u('data-action="file.forward"');
                            }
                            u(' aria-label="转发">转发</li>\n			  <li class="line ');
                            s = 29;
                            if (p.safeType) {
                                u("disabled");
                            }
                            u('" ');
                            if (!p.safeType) {
                                u('data-action="file.forwardMobile"');
                            }
                            u(' aria-label="转发到手机">发送到手机</li>\n			');
                            s = 30;
                        }
                        u("\n			");
                        s = 31;
                        if (G.info.isAdmin && typeof p.issearch === "undefined") {
                            u("\n				<li ");
                            s = 32;
                            if (p.safeType || G.file.isTooMany) {
                                u('class="disabled"');
                            } else {
                                u('data-action="file.showMove"');
                            }
                            u(' aria-label="移动">移动到</li>\n			');
                            s = 33;
                        }
                        u("\n			");
                        s = 34;
                        if (G.info.isAdmin && p.temp) {
                            u("\n				<li ");
                            s = 35;
                            if (p.safeType) {
                                u('class="disabled"');
                            } else {
                                u('data-action="file.permanent"');
                            }
                            u(' aria-label="转存为永久文件" tabindex="-1">转存为永久文件</li>\n			');
                            s = 36;
                        }
                        u("\n			<li ");
                        s = 37;
                        if (p.safeType || !G.info.isAdmin && !m) {
                            u('class="disabled"');
                        } else {
                            u('data-action="file.showRename"');
                        }
                        u(' aria-label="重命名" >重命名</li>\n			<li ');
                        s = 38;
                        if (!G.info.isAdmin && !m) {
                            u('class="disabled"');
                        } else {
                            u('data-action="file.delete"');
                        }
                        u(' id="fileDelete" aria-label="删除">删除</li>\n			<li data-action="file.jubao" aria-label="举报">举报</li>\n		');
                        s = 40;
                    } else if (p.orcType === 2) {
                        u('\n			<li class="line" data-action="folder.open" data-path="');
                        s = 41;
                        u(t(p.id));
                        u('">打开</li>\n			<li ');
                        s = 42;
                        if (!G.info.isAdmin) {
                            u('class="disabled"');
                        } else {
                            u('data-action="folder.showRenameFolder"');
                        }
                        u('>重命名</li>\n			<li class="line" data-action="folder.property">文件夹属性</li>\n			<li ');
                        s = 44;
                        if (!G.info.isAdmin) {
                            u('class="disabled"');
                        } else {
                            u('data-action="folder.showDeleteFolder"');
                        }
                        u(">删除</li>\n		");
                        s = 45;
                    }
                    u("\n	");
                    s = 46;
                }
                u("\n");
                s = 47;
            } else if (v) {
                u('\n	<li class="line" data-action="file.batchSaveAs">另存为</li>\n	<li class="line" data-action="file.batchMove">移动到</li>\n	<li ');
                s = 50;
                if (!G.info.isAdmin && !m) {
                    u('class="disabled"');
                } else {
                    u('data-action="file.batchDelete"');
                }
                u(">删除</li>\n");
                s = 51;
            }
            u("\n</ul>\n");
            s = 53;
            return c.join("");
        } catch (h) {
            n(h, d, f, s);
        }
    };
}, function(e, t, a) {
    "use strict";
    var i = {
        upload: 2186487,
        continueupload: 2186489,
        download: 2186490
    };
    var n = a(55);
    var r = a(59);
    function o(e) {
        console.debug("------新任务" + e.type + "---------", e);
        e.taskStarttime = parseInt(new Date().getTime() / 1e3, 10);
        if (!(e.type === "download" && e.downloadtasktype === 2)) {
            if (e.onlineedit === 1) {
                console.debug("start edit file");
                r.fileInEditRow(e);
            } else {}
            $(G.handler).trigger("client.addTask", e);
        } else {
            var t = e.foldertaskid;
            var a = n.getOneTask(t);
            if (a) {
                if (!a.fileTaskList) {
                    a.fileTaskList = [];
                }
                a.fileTaskList.push(e.id);
            }
        }
        QReport.monitor(i[e.type]);
    }
    e.exports = o;
}, function(e, t, a) {
    "use strict";
    var i = a(185);
    var n = r(i);
    function r(e) {
        if (e && e.__esModule) {
            return e;
        } else {
            var t = {};
            if (e != null) {
                for (var a in e) {
                    if (Object.prototype.hasOwnProperty.call(e, a)) t[a] = e[a];
                }
            }
            t.default = e;
            return t;
        }
    }
    var o = a(54);
    var l = a(59);
    var s = a(24);
    var d = a(19);
    var f = $(G.handler);
    var c = a(112);
    var u = a(109);
    var p = a(115);
    var v = 5485;
    function m(e) {
        var t = o.task2file(e);
        if (!G.file) {
            G.file = {};
        }
        if (G.file && typeof G.file.cu === "undefined") {
            G.file.cu = 0;
        }
        if (e.status === "downloadcomplete") {
            if (e.downloadtasktype !== 2) {
                l.updateRow(t);
                if (!G.saveasList[t.filepath]) {
                    if (G.version < v) {
                        p.openByPath(t);
                    } else {
                        n.edit(t);
                    }
                } else {
                    delete G.saveasList[t.filepath];
                }
            }
            if (t.parentId && t.parentId !== "/") {
                var a = o.getData(t.parentId);
                if (a) {
                    a.downNum++;
                    if (a.downNum === a.filenum) {
                        a.isDown = true;
                        a.succ = true;
                        l.updateRow(a);
                    }
                }
            }
        } else {
            G.file.cu += t.size;
            G.file.capacityused = u.getSize(G.file.cu);
            l.renderSpace();
            if (t.folderpath === G.nowFolder || !t.folderpath) {
                if (e.onlineedit === 1) {
                    var i = o.getData(t.oldfilepath);
                    console.debug("upload complete and update old file:", e, t, i);
                    if (e.delete_file_id !== "") {
                        console.debug("update old file");
                        t.md5 = t.newMd5;
                        t.localpath = i.localpath;
                        t.down = i.down;
                        l.removeRow(i);
                        l.appendFile(t);
                    } else {
                        i.isDown = false;
                        t.localpath = i.localpath;
                        delete i.localpath;
                        delete i.lp;
                        console.debug("no need delete old file!", i, t);
                        l.updateEditFileRow(t);
                        d.remove(i);
                        l.appendFile(t);
                        o.updateAllNum({
                            files: [ t ],
                            action: "add"
                        });
                    }
                } else {
                    l.appendFile(t);
                }
            } else {
                var a = o.getData(e.folderpath);
                a.filenum++;
                var r = parseInt(new Date().getTime() / 1e3, 10);
                a.mt = r;
                a.mtStr = c.dayStr(r);
                a.toFirst = true;
                l.updateRow(a);
            }
            s.init(G.file.isTooMany || G.file.isFull, e.status);
            o.updateAllNum({
                files: [ t ],
                action: "add"
            });
        }
        d.set(t);
        report("showTaskShow");
        f.trigger("client.updateTask", e);
    }
    e.exports = m;
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    function n(e) {
        i.trigger("client.updateTask", e);
    }
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    function n(e) {
        i.trigger("client.updateTask", e);
    }
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = $(G.handler);
    function n(e) {
        e.createtime = parseInt(new Date().getTime() / 1e3, 10);
        if (e.status === "uploadprogress") {
            setTimeout(function() {
                $(G.handler).trigger("box.show", e);
            }, 20);
        }
        if (e.remotetype === 1) {}
        if (e.type === "download") {}
        i.trigger("client.updateTask", e);
    }
    e.exports = n;
}, function(e, t, a) {
    "use strict";
    var i = a(50);
    var n = $(G.handler);
    var r = {
        upload: {
            cancel: 2186633,
            remove: 2186634,
            scanfail: 2186635,
            uploadsecurityfail: 2186636,
            uploadgeturlfail: 2186637,
            uploadfail: 2186491,
            _default: 2186638
        },
        continueupload: {
            cancel: 2186639,
            remove: 2186640,
            scanfail: 2186641,
            uploadsecurityfail: 2186642,
            uploadgeturlfail: 2186643,
            uploadfail: 2186491,
            _default: 2186644
        },
        download: {
            cancel: 2186645,
            remove: 2186646,
            downloadgeturlfail: 2186647,
            downloadfail: 386331,
            _default: 2186648
        }
    };
    function o(e) {
        var t = e.filepath;
        var a = e.localpath;
        var n = e.filename_esc || e.filename;
        var r = e.remotetype;
        i.addContinueUploadTask(t, a, n, r);
    }
    function l(e) {
        n.trigger("client.updateTask", e);
        if (e.onlineedit === 1) {}
        var t = r[e.type];
        var a = t[e.status];
        if (a) {
            QReport.monitor(a);
        }
        if (e.errorcode || e.securityattri) {
            var i = e.errorcode;
            if (i === 32221991) {
                o(e);
                return;
            } else if (i === 12029) {}
        }
    }
    e.exports = l;
}, function(e, t, a) {
    "use strict";
    t.merge = function r(e, t) {
        if (arguments.length === 1) {
            var a = e[0];
            for (var n = 1; n < e.length; n++) {
                a = r(a, e[n]);
            }
            return a;
        }
        var o = e["class"];
        var l = t["class"];
        if (o || l) {
            o = o || [];
            l = l || [];
            if (!Array.isArray(o)) o = [ o ];
            if (!Array.isArray(l)) l = [ l ];
            e["class"] = o.concat(l).filter(i);
        }
        for (var s in t) {
            if (s != "class") {
                e[s] = t[s];
            }
        }
        return e;
    };
    function i(e) {
        return e != null && e !== "";
    }
    t.joinClasses = n;
    function n(e) {
        return (Array.isArray(e) ? e.map(n) : e && typeof e === "object" ? Object.keys(e).filter(function(t) {
            return e[t];
        }) : [ e ]).filter(i).join(" ");
    }
    t.cls = function o(e, a) {
        var i = [];
        for (var r = 0; r < e.length; r++) {
            if (a && a[r]) {
                i.push(t.escape(n([ e[r] ])));
            } else {
                i.push(n(e[r]));
            }
        }
        var o = n(i);
        if (o.length) {
            return ' class="' + o + '"';
        } else {
            return "";
        }
    };
    t.style = function(e) {
        if (e && typeof e === "object") {
            return Object.keys(e).map(function(t) {
                return t + ":" + e[t];
            }).join(";");
        } else {
            return e;
        }
    };
    t.attr = function l(e, a, i, n) {
        if (e === "style") {
            a = t.style(a);
        }
        if ("boolean" == typeof a || null == a) {
            if (a) {
                return " " + (n ? e : e + '="' + e + '"');
            } else {
                return "";
            }
        } else if (0 == e.indexOf("data") && "string" != typeof a) {
            if (JSON.stringify(a).indexOf("&") !== -1) {
                console.warn("Since Jade 2.0.0, ampersands (`&`) in data attributes " + "will be escaped to `&amp;`");
            }
            if (a && typeof a.toISOString === "function") {
                console.warn("Jade will eliminate the double quotes around dates in " + "ISO form after 2.0.0");
            }
            return " " + e + "='" + JSON.stringify(a).replace(/'/g, "&apos;") + "'";
        } else if (i) {
            if (a && typeof a.toISOString === "function") {
                console.warn("Jade will stringify dates in ISO form after 2.0.0");
            }
            return " " + e + '="' + t.escape(a) + '"';
        } else {
            if (a && typeof a.toISOString === "function") {
                console.warn("Jade will stringify dates in ISO form after 2.0.0");
            }
            return " " + e + '="' + a + '"';
        }
    };
    t.attrs = function s(e, a) {
        var i = [];
        var r = Object.keys(e);
        if (r.length) {
            for (var o = 0; o < r.length; ++o) {
                var l = r[o], s = e[l];
                if ("class" == l) {
                    if (s = n(s)) {
                        i.push(" " + l + '="' + s + '"');
                    }
                } else {
                    i.push(t.attr(l, s, false, a));
                }
            }
        }
        return i.join("");
    };
    t.escape = function d(e) {
        var t = String(e).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
        if (t === "" + e) return e; else return t;
    };
    t.rethrow = function f(e, t, i, n) {
        if (!(e instanceof Error)) throw e;
        if ((typeof window != "undefined" || !t) && !n) {
            e.message += " on line " + i;
            throw e;
        }
        try {
            n = n || a(211).readFileSync(t, "utf8");
        } catch (r) {
            f(e, null, i);
        }
        var o = 3, l = n.split("\n"), s = Math.max(i - o, 0), d = Math.min(l.length, i + o);
        var o = l.slice(s, d).map(function(e, t) {
            var a = t + s + 1;
            return (a == i ? "  > " : "    ") + a + "| " + e;
        }).join("\n");
        e.path = t;
        e.message = (t || "Jade") + ":" + i + "\n" + o + "\n\n" + e.message;
        throw e;
    };
}, function(e, t, a) {} ]);